# FUNCTION INDEX - Digital Detective v2.0.3

> **Arquitetura:** Chrome Extension Manifest V3 (popup + content script + service worker + pÃ¡ginas de relatÃ³rio)
> **ObservaÃ§Ã£o de versÃ£o:** alinhado em `v2.0.3` (manifest, popup, relatÃ³rios e docs principais)
> **Atualizado:** 2026-03-23

---

## ðŸ” BUSCA RÃPIDA

**Precisa mexer em:**
- **PermissÃµes MV3 / recursos expostos?** â†’ `manifest.json`
- **Mensageria e aÃ§Ãµes globais (service worker)?** â†’ `background.js`
- **UI do popup (14 ferramentas + painÃ©is)?** â†’ `popup.html`, `popup.js`
- **Picker de elemento / color picker / screenshot / DS extraction na pÃ¡gina?** â†’ `content.js`
- **Design system visual compartilhado de relatÃ³rios?** â†’ `report_utils.js`, `template_ds.html`
- **Abrir relatÃ³rio salvo em aba nova?** â†’ `report_viewer.html`, `report_viewer.js`
- **DS Extractor (fluxo page/element)?** â†’ `ds_extractor.html`, `ds_extractor.js`
- **Component Blueprinter?** â†’ `blueprinter.html`, `blueprinter.js`
- **Match Analysis (comparaÃ§Ã£o visual/estrutura)?** â†’ `match_analysis.html`, `match_analysis.js`
- **Script Match (scripts em comum/faltantes/extras)?** â†’ `script_match.html`, `script_match.js`
- **Static Builder (HTML estÃ¡tico com CSS inlined + URLs absolutas)?** â†’ `static_builder.html`, `static_builder.js`
- **Quick Updater (ediÃ§Ã£o visual side-by-side de HTML local)?** â†’ `quick_updater.html`, `quick_updater.js`
- **Lighthouse (PageSpeed API)?** â†’ `lighthouse_report.html`, `lighthouse_report.js`
- **SEO report (40 checks em 5 pilares)?** â†’ `seo_report.html`, `seo_report.js`
- **AEO report (5 pilares de answer readiness)?** â†’ `aeo_report.html`, `aeo_report.js`
- **GeraÃ§Ã£o de Ã­cones PNG a partir de SVG?** â†’ `create_icons.py`, `icon.svg`, `icons/*`

---

## ðŸ—‚ï¸ ESTRUTURA GERAL

```text
Digital Detective v2.0/
  manifest.json
  popup.html
  popup.js
  content.js
  background.js

  report_utils.js
  report_viewer.html
  report_viewer.js
  template_ds.html

  ds_extractor.html
  ds_extractor.js
  blueprinter.html
  blueprinter.js
  match_analysis.html
  match_analysis.js
  script_match.html
  script_match.js
  static_builder.html
  static_builder.js
  quick_updater.html
  quick_updater.js
  lighthouse_report.html
  lighthouse_report.js
  seo_report.html
  seo_report.js
  aeo_report.html
  aeo_report.js

  create_icons.py
  icon.svg
  icons/icon16.png
  icons/icon48.png
  icons/icon128.png

  README.md
  CLAUDE.md
  .claude/settings.local.json
```

---

## ðŸ“‚ CORE DA EXTENSÃƒO

### manifest.json
**FunÃ§Ã£o:** configuraÃ§Ã£o MV3, permissÃµes e mapeamento dos recursos.
- `background.service_worker` â†’ `background.js`
- `action.default_popup` â†’ `popup.html`
- `content_scripts` â†’ injeta `content.js` em `http/https`
- `web_accessible_resources` â†’ expÃµe pÃ¡ginas/scripts de relatÃ³rio para abrir em abas

### background.js
**FunÃ§Ã£o:** service worker central de mensageria, fetch, downloads, bloqueio de script e abertura de relatÃ³rios.

**FunÃ§Ãµes-chave:**
- `safeFetch(url)` - fetch resiliente para HTML/CSS/script _(codigo: `background.js` linha 4)_
- `getBlockedMap(cb)` / `setBlockedMap(map, cb)` - persistÃªncia de scripts bloqueados _(codigo: `background.js` linhas 18, 25)_
- `ruleIdFor(url, tabId)` - gera id estÃ¡vel para DNR _(codigo: `background.js` linha 42)_
- `normalizeBaseUrl(url)` - remove query/hash para bloqueio consistente _(codigo: `background.js` linha 49)_

**AÃ§Ãµes recebidas via `chrome.runtime.onMessage`:**
- `event_tracker_inject` - injeta hooks de analytics (Segment/Rudder/dataLayer/fetch/XHR/beacon) _(linha 56)_
- `capture_tab` / `download_image` _(linhas 310, 324)_
- `fetch_script_text` _(linha 339)_
- `get_blocked_scripts` / `block_script` / `unblock_script` _(linhas 351, 361, 391)_
- `open_screenshot_preview` / `open_report_viewer` _(linhas 415, 445)_
- `download_report` / `download_asset` _(linhas 461, 476)_
- `fetch_page_for_match` / `fetch_css_urls` _(linhas 490, 505)_

### popup.html
**FunÃ§Ã£o:** UI principal do plugin (grid de 14 ferramentas + subpainÃ©is).
- BotÃµes principais `btn-*` (Color Picker, Screenshot, Picker, DS, Blueprinter, Match, Lighthouse, SEO, AEO, Event Tracker, Script Finder, Script Match, Static Builder, Quick Updater)
- SubpainÃ©is: `shot-panel`, `picker-panel`, `ds-panel`, `bluep-panel`, `match-panel`, `lh-panel`, `seo-panel`, `aeo-panel`, `event-panel`, `script-panel`, `script-match-panel`, `static-builder-panel`

### popup.js
**FunÃ§Ã£o:** controlador do popup, valida inputs, abre pÃ¡ginas de relatÃ³rio, chama content/background.

**FunÃ§Ãµes-chave:**
- Status helpers (`setStatus`, `setShotStatus`, `setScriptStatus`, `setStaticBuilderStatus`, etc.) _(linhas 82-210)_
- `getActiveTab(cb)` / `sendToTab(tabId,payload,cb)` _(linhas 243, 249)_
- `startEventPolling(tab)` + `renderEvents(events)` _(linhas 272, 289)_
- `startScreenshot(mode)` _(linha 350)_
- `runDsPageFromPopup()` / `runDsHtmlFromPopup()` _(linhas 409, 423)_
- `runBlueprinterFromPopup()` _(linha 448)_
- `startElementPicker()` / `startColorPicker()` / `startXpathPicker()` _(linhas 477, 505, 521)_
- `togglePanel(btn,panel,...)` _(linha 582)_
- `validateMatchUrls()` / `validateScriptMatchUrls()` _(linhas 708, 732)_
- `populateStaticBuilderPanel()` / `validateStaticBuilderUrl()` _(linhas 757, 768)_
- `loadScripts()` / `renderScripts(...)` _(linhas 835, 853)_
- `collectSeoSignals()` / `collectAeoSignals()` (executadas com `chrome.scripting.executeScript`) _(linhas 944, 1081)_

### content.js
**FunÃ§Ã£o:** engine injetada na pÃ¡gina: picker, color picker, tracker, screenshots, coleta CSS/scripts e geraÃ§Ã£o de relatÃ³rios DS.

**Blocos principais:**
- Picker/XPath:
  - `getXPath(el)` _(linha 35)_
  - `ensurePickerUi()` _(linha 90)_
  - `startPicker(mode, opts)` / `stopPicker()` _(linhas 426, 521)_
- Color Picker:
  - `ensureColorPickerUi()` / `ensureColorPickerModal()` _(linhas 535, 575)_
  - `rgbStringToHex(color)` _(linha 634)_
  - `pickColorFromPoint(x,y)` _(linha 648)_
  - `startColorPicker()` / `stopColorPicker(silent)` _(linhas 694, 674)_
- Event Tracker:
  - `injectEventTrackerScript()` _(linha 785)_
  - `normalizeEventMessage(msg)` _(linha 794)_
  - `startEventTracker()` / `stopEventTracker()` _(linhas 853, 876)_
- Screenshot:
  - `captureViewportImage()` _(linha 961)_
  - `captureVisibleScreenshot(options)` _(linha 1140)_
  - `captureFullPageScreenshot(options)` _(linha 1162)_
  - `captureComponentScreenshot(el, options)` _(linha 1265)_
- DS/CSS extraction:
  - `collectAllCss()` _(linha 1402)_
  - `filterCssByRoot(allCss, root)` _(linha 1859)_
  - `collectScopedMetrics(rootEl, scopedCss)` _(linha 2950)_
  - `generateReport(data)` _(linha 2430)_
  - `generateScopedReport(opts)` _(linha 3234)_
  - `runScopedExtraction(rootEl)` / `runScopedExtractionFromHtml(html)` _(linhas 3571, 3625)_
- Scripts:
  - `detectScriptVendor(url, code)` _(linha 1552)_
  - `collectScripts()` _(linha 1578)_

**Listener de mensagens (orquestraÃ§Ã£o):**
- `chrome.runtime.onMessage.addListener(...)` _(linha 3742)_
- AÃ§Ãµes: `screenshot_start`, `collect_scripts`, `extract_ds_html`, `extract_ds_scope`, `toggle_picker`, `toggle_picker_xpath`, `start_color_picker`, `event_tracker_toggle`, `event_tracker_get`, `collect_css`, `collect_css_raw`, `extract_ds`

---

## ðŸ“‚ INFRA DE RELATÃ“RIOS

### report_utils.js
**FunÃ§Ã£o:** utilitÃ¡rios compartilhados de UI/report download/modal.

**FunÃ§Ãµes-chave:**
- `getReportDesignSystemCss()` _(linha 7)_
- `applyReportDesignSystem()` _(linha 50)_
- `syncCollapseArrows()` + `initReportDesignSystem()` _(linhas 82, 92)_
- `downloadBlob(blob, filename)` _(linha 122)_
- `saveDocumentAsHtml(filename)` _(linha 142)_
- `bindSaveButton(btn, filename)` _(linha 163)_
- `bindCodeModal(opts)` _(linha 170)_
- `downloadIframeImage(frame, filenameBase)` _(linha 228)_
- `bindPreviewDownloads(opts)` _(linha 264)_

### report_viewer.html
**FunÃ§Ã£o:** shell para abrir relatÃ³rio salvo temporariamente em storage.

### report_viewer.js
**FunÃ§Ã£o:** carrega payload `dd_report_*`, renderiza HTML e reativa recursos utilitÃ¡rios.

**FunÃ§Ãµes:**
- `getStorageArea()` _(linha 4)_
- `setStatus(msg)` _(linha 10)_
- `parseSourceHtml(root)` _(linha 16)_
- `extractStyles(doc)` _(linha 28)_
- `renderReport(html, filename)` _(linha 37)_
- `init()` _(linha 88)_

### template_ds.html
**FunÃ§Ã£o:** template visual/tokens do design system de relatÃ³rios.
- Tokens CSS (`--color-*`, `--space-*`, `--radius-*`, etc.)
- SeÃ§Ãµes padrÃ£o (`failed`, `warnings`, `passed`)
- Script inline:
  - `refreshArrow(section)` _(linha 516)_
  - toggle colapsÃ¡vel de seÃ§Ãµes _(linhas 523-533)_

---

## ðŸ“‚ FERRAMENTAS E PÃGINAS DE RELATÃ“RIO

### ds_extractor.html + ds_extractor.js
**FunÃ§Ã£o:** fluxo dedicado de DS extraction (escopo pÃ¡gina ou elemento HTML colado).

**FunÃ§Ãµes (JS):**
- `setStatus` / `clearStatus` _(linhas 32, 38)_
- `sendToTab(payload)` _(linha 42)_
- `openReport(html, filename)` / `downloadReport(html, filename)` _(linhas 73, 65)_
- `handleResponse(resp, filename)` _(linha 83)_
- `scopeToElement()` / `scopeToPage()` _(linhas 104, 110)_

### blueprinter.html + blueprinter.js
**FunÃ§Ã£o:** gera blueprint de componente, preview desktop/mobile, ediÃ§Ã£o de copy/CTA e download de assets.

**FunÃ§Ãµes-chave (JS):**
- Fluxo/estado:
  - `showStep(name)` _(linha 78)_
  - `updateReportHeader(url, generatedDate)` _(linha 54)_
  - `bindResultPanelCollapsers()` _(linha 88)_
- SanitizaÃ§Ã£o/rewrite:
  - `sanitizeHtml(html)` _(linha 167)_
  - `rewriteCssUrls(cssText, baseUrl)` _(linha 174)_
  - `rewriteHtmlAssets(html, baseUrl, map)` _(linha 295)_
- Coleta CSS/assets:
  - `fetchCssFromTab(tabId)` _(linha 455)_
  - `buildCssFromSheets(resp, baseUrl)` _(linha 478)_
  - `fetchAssetBlobs(urls, onProgress)` _(linha 351)_
- ExtraÃ§Ã£o e render:
  - `extractData(html)` _(linha 759)_
  - `renderBlueprint(data)` _(linha 943)_
  - `applyEditsToHtml(html, edits)` _(linha 567)_
  - `openPreviewTab(htmlDoc)` _(linha 935)_
- Quick mode e modais:
  - `tryRunQuickBlueprint()` _(linha 1328)_
  - `openModal/closeModal` preview _(linhas 1391-1392)_
  - `openCodeModal/closeCodeModal` _(linhas 1411-1412)_
  - `openMobileModal/closeMobileModal` _(linhas 1424-1425)_

### match_analysis.html + match_analysis.js
**FunÃ§Ã£o:** compara duas pÃ¡ginas (layout/estilo/estrutura/infra) e calcula score ponderado.

**FunÃ§Ãµes-chave (JS):**
- ExtraÃ§Ã£o de sinais:
  - `extractFonts`, `extractColors`, `extractButtons`, `extractHover`, `extractLayout`, `extractNavigation`, `extractFooter`, `extractTypography`, `extractSections` _(linhas 61-331)_
- Infra/stack:
  - `detectTechStack(html, url)` _(linha 347)_
- Scoring:
  - `scoreFonts`, `scoreColors`, `scoreButtons`, `scoreHover`, `scoreLayout`, `scoreNavigation`, `scoreFooter`, `scoreTypography`, `scoreSections` _(linhas 457-507)_
- Render:
  - `buildInfrastructureBlock(...)` _(linha 800)_
  - `buildReport(...)` _(linha 834)_
- ExecuÃ§Ã£o:
  - `getCssForPage(html, baseUrl)` _(linha 1016)_
  - `run()` _(linha 1052)_

### script_match.html + script_match.js
**FunÃ§Ã£o:** compara scripts carregados em duas URLs (match exato + soft por filename).

**FunÃ§Ãµes-chave (JS):**
- `detectVendor(url)` _(linha 165)_
- `normalizeScriptUrl(src, baseUrl)` _(linha 177)_
- `getMatchKey(url)` _(linha 188)_
- `extractScriptsFromHtml(html, baseUrl)` _(linha 210)_
- `compareScripts(scriptsA, scriptsB)` _(linha 243)_
- `renderReport(urlA, urlB, result)` _(linha 314)_
- `run()` _(linha 498)_

### static_builder.html + static_builder.js
**FunÃ§Ã£o:** gera cÃ³pia HTML estÃ¡tica de qualquer URL â€” CSS inline, todos os URLs relativos convertidos para absolutos, SEO tags preservadas.

**FunÃ§Ãµes-chave (JS):**
- `setStatus(msg)` / `showError(msg)` _(linhas 26, 31)_
- `resolveUrl(url, base)` _(linha 39)_
- `rewriteCssUrls(cssText, baseUrl)` _(linha 51)_
- `rewriteSrcset(srcset, baseUrl)` _(linha 61)_
- `rewriteHtmlUrls(doc, baseUrl)` _(linha 74)_ â€” reescreve src, href, srcset, action, poster, data, xlink:href, style inline, blocos style
- `inlineCssFiles(doc, baseUrl, callback)` _(linha 155)_ â€” busca CSS via `fetch_css_urls`, substitui `<link>` por `<style>`
- `processStaticHtml(rawHtml, pageUrl, callback)` _(linha 191)_
- `showResult(html, url, stats)` _(linha 228)_
- `run()` _(linha 281)_

**Fluxo:**
```text
popup.js (btn-static-builder) â†’ static_builder.html?url=...
  â†’ static_builder.js run()
  â†’ background.js fetch_page_for_match â†’ HTML bruto
  â†’ inlineCssFiles â†’ background.js fetch_css_urls â†’ CSS inlined
  â†’ rewriteHtmlUrls â†’ todos URLs absolutos
  â†’ showResult â†’ Save as HTML (Blob download) | Open Preview (window.open blob URL)
```

### lighthouse_report.html + lighthouse_report.js
**FunÃ§Ã£o:** chama PageSpeed Insights API (desktop/mobile), renderiza score, mÃ©tricas e auditorias.

**FunÃ§Ãµes-chave (JS):**
- `renderGauge(...)` _(linha 47)_
- `renderMetrics(auditsD, auditsM)` _(linha 73)_
- `extractAuditGroups(lhr)` _(linha 98)_
- `renderAuditList(containerId, list)` _(linha 142)_
- `bindSectionToggles()` _(linha 183)_
- `bindReload()` / `bindSave()` _(linhas 196, 206)_
- `run()` _(linha 226)_

### seo_report.html + seo_report.js
**FunÃ§Ã£o:** score SEO em 5 pilares (40 checks), grade, recomendaÃ§Ãµes e export JSON.

**Pilares (JS):**
- `evaluateIndexability(s)` _(linha 146)_
- `evaluateOnPageSeo(s, pageType, keyword)` _(linha 231)_
- `evaluateContentQuality(s, pageType, keyword)` _(linha 398)_
- `evaluateSemanticSeo(s, pageType)` _(linha 584)_
- `evaluateMediaLinks(s, pageType)` _(linha 706)_

**OrquestraÃ§Ã£o:**
- `buildReport(signals)` _(linha 915)_
- `renderReport(report, signals)` _(linha 1131)_
- `buildJsonExport(report, signals)` _(linha 1236)_
- `run()` _(linha 1282)_

### aeo_report.html + aeo_report.js
**FunÃ§Ã£o:** score AEO (Answer Engine Optimization) com foco em elegibilidade, resposta e extraibilidade.

**Pilares (JS):**
- `evalEligibility(s,d,type)` _(linha 288)_
- `evalAnswerability(s,d,type)` _(linha 326)_
- `evalSemantic(s,d,type)` _(linha 367)_
- `evalCitation(s,d,type)` _(linha 414)_
- `evalCoverage(s,d,type)` _(linha 450)_

**OrquestraÃ§Ã£o:**
- `derive(s,type,topic)` _(linha 179)_
- `pillarScore(list)` _(linha 481)_
- `penalties(base,s,d)` _(linha 493)_
- `recommend(report)` _(linha 510)_
- `buildReport(signals)` _(linha 535)_
- `render(report, signals)` _(linha 796)_
- `run()` _(linha 847)_

---

## ðŸ“‚ ARQUIVOS DE SUPORTE

### create_icons.py
**FunÃ§Ã£o:** gera `icons/icon16.png`, `icon48.png`, `icon128.png`.

**EstratÃ©gia:**
1. `try_cairosvg()` _(linha 24)_
2. fallback `try_pillow()` _(linha 37)_
3. fallback final stdlib: `make_command_icon_png(size)` _(linha 61)_ + `make_placeholder_icons()` _(linha 212)_

### icon.svg
**FunÃ§Ã£o:** fonte vetorial do Ã­cone da extensÃ£o (sÃ­mbolo `keyboard_command_key` + badge "1.2").

### icons/*.png
**FunÃ§Ã£o:** Ã­cones finais usados pelo Chrome (`16/48/128`).

### README.md
**FunÃ§Ã£o:** overview funcional, changelog e instruÃ§Ãµes de instalaÃ§Ã£o/uso.

### CLAUDE.md
**FunÃ§Ã£o:** regras de operaÃ§Ã£o e contexto tÃ©cnico do projeto.

### .claude/settings.local.json
**FunÃ§Ã£o:** permissÃµes locais da automaÃ§Ã£o/assistente.

---

## ðŸ”„ FLUXOS DE EXECUÃ‡ÃƒO

### 1) Fluxo principal do popup
```text
popup.html (botÃ£o) -> popup.js
  -> sendToTab(...) para content.js
  -> ou chrome.runtime.sendMessage(...) para background.js
  -> abre report page (chrome.runtime.getURL + chrome.tabs.create)
```

### 2) DS Extractor (page)
```text
popup.js/ds_extractor.js -> content.js action: extract_ds
  -> collectAllCss + anÃ¡lise tokens/componentes
  -> generateReport(html)
  -> background.js open_report_viewer
  -> report_viewer.html/report_viewer.js renderiza
```

### 3) Blueprinter
```text
popup.js (quick payload) -> blueprinter.html
  -> blueprinter.js extractData + renderBlueprint
  -> preview desktop/mobile + download de assets
```

### 4) Screenshot
```text
popup.js startScreenshot(mode) -> content.js screenshot_start
  -> background.js capture_tab (chrome.tabs.captureVisibleTab)
  -> content.js compÃµe canvas + footer + download
  -> opcional: background.js open_screenshot_preview
```

### 5) Match / Script Match
```text
report page JS -> background.js fetch_page_for_match
  -> parsing + scoring local (match_analysis.js/script_match.js)
  -> render do relatÃ³rio + save HTML
```

### 6) SEO / AEO
```text
popup.js coleta sinais na aba ativa (executeScript)
  -> grava dd_seo_data / dd_aeo_data em chrome.storage.local
  -> abre seo_report.html / aeo_report.html
  -> report JS consome storage, calcula score e renderiza
```

---

## ðŸ“Š ESTATÃSTICAS DO SCAN

- **Total de arquivos na pasta:** 33
- **Arquivos textuais analisados:** 30
- **Arquivos binÃ¡rios (Ã­cones PNG):** 3
- **Linhas textuais totais:** ~16.800 (estimado apÃ³s adiÃ§Ã£o de static_builder.html + static_builder.js)
- **FunÃ§Ãµes declaradas (`function`/`def`):** ~503 (+11 em static_builder.js, +3 em popup.js)
- **Arquivos JS com maior densidade funcional:**
  - `content.js` (128 funÃ§Ãµes)
  - `popup.js` (72 funÃ§Ãµes)
  - `match_analysis.js` (65 funÃ§Ãµes)
  - `blueprinter.js` (52 funÃ§Ãµes)

---

## âš ï¸ NOTAS TÃ‰CNICAS IMPORTANTES

- Versionamento principal **alinhado em v2.0.3** (`manifest`, popup, relatÃ³rios e docs principais).
- PadrÃ£o oficial de versionamento: **major.minor.patch**.
- Existem sinais de **problema de encoding** em alguns arquivos (caracteres como `Ã¢â‚¬â€`, `Ã¢â€“Â²`, etc.), especialmente em strings de UI.
- O projeto estÃ¡ fortemente acoplado ao padrÃ£o de mensagens (`msg.action`) entre `popup.js`, `content.js` e `background.js`; mudanÃ§as em nomes de action exigem ajuste nos 3 pontos.

---

**VersÃ£o do Ã­ndice:** 1.2
**Data:** 2026-03-23
**Status:** âœ… Atualizado com padronizaÃ§Ã£o semver (`2.0.3`)
