﻿(function () {
  'use strict';

  var VIEWPORTS = {
    desktop: 1366,
    tablet: 834,
    mobile: 390
  };

  var state = {
    mode: 'single',
    baseHtml: '',
    baseDoctype: '<!DOCTYPE html>',
    fileName: '',
    patches: {},
    selectedPath: '',
    hoverPath: '',
    viewport: 'desktop',
    safeMode: true,
    isBindingEditor: false,
    syncLock: false,
    drag: {
      active: false,
      dx: 0,
      dy: 0
    },
    projectFiles: [],
    projectPages: [],
    projectPagePath: '',
    projectBlobMap: {},
    originalDoc: null,
    previewDoc: null
  };

  var refs = {
    loadFileBtn: document.getElementById('qu-load-file'),
    loadFolderBtn: document.getElementById('qu-load-folder'),
    previewBtn: document.getElementById('qu-preview'),
    saveBtn: document.getElementById('qu-save'),
    fileInput: document.getElementById('qu-file-input'),
    folderInput: document.getElementById('qu-folder-input'),
    status: document.getElementById('qu-status'),
    fileName: document.getElementById('qu-file-name'),
    projectPage: document.getElementById('qu-project-page'),
    safeMode: document.getElementById('qu-safe-mode'),
    viewportSegment: document.getElementById('qu-viewport-segment'),
    frameOriginal: document.getElementById('qu-frame-original'),
    framePreview: document.getElementById('qu-frame-preview'),
    shellOriginal: document.getElementById('qu-shell-original'),
    shellPreview: document.getElementById('qu-shell-preview'),
    canvasOriginal: document.getElementById('qu-canvas-original'),
    canvasPreview: document.getElementById('qu-canvas-preview'),
    emptyOriginal: document.getElementById('qu-empty-original'),
    emptyPreview: document.getElementById('qu-empty-preview'),
    loaderOriginal: document.getElementById('qu-loader-original'),
    loaderPreview: document.getElementById('qu-loader-preview'),
    originalMeta: document.getElementById('qu-original-meta'),
    previewMeta: document.getElementById('qu-preview-meta'),
    editor: document.getElementById('qu-editor'),
    editorHead: document.querySelector('#qu-editor .qu-editor-head'),
    editorEmpty: document.getElementById('qu-editor-empty'),
    targetMeta: document.getElementById('qu-target-meta'),
    capabilities: document.getElementById('qu-capabilities'),
    inputText: document.getElementById('qu-input-text'),
    inputHref: document.getElementById('qu-input-href'),
    inputSrc: document.getElementById('qu-input-src'),
    inputAlt: document.getElementById('qu-input-alt'),
    stylePadding: document.getElementById('qu-style-padding'),
    styleMargin: document.getElementById('qu-style-margin'),
    styleBg: document.getElementById('qu-style-bg'),
    styleColor: document.getElementById('qu-style-color'),
    styleRadius: document.getElementById('qu-style-radius'),
    styleFont: document.getElementById('qu-style-font'),
    fieldText: document.getElementById('qu-field-text'),
    fieldHref: document.getElementById('qu-field-href'),
    fieldSrc: document.getElementById('qu-field-src'),
    fieldAlt: document.getElementById('qu-field-alt'),
    resetSelected: document.getElementById('qu-reset-selected'),
    resetAll: document.getElementById('qu-reset-all')
  };

  function esc(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function setStatus(message, type) {
    if (!refs.status) return;
    refs.status.textContent = message || '';
    refs.status.style.color = type === 'error' ? '#dd1234' : (type === 'success' ? '#166534' : '#4a4a4a');
  }

  function setFileNameLabel(name) {
    if (!refs.fileName) return;
    refs.fileName.textContent = name || 'No file loaded.';
  }

  function setProjectPageVisibility(show) {
    if (!refs.projectPage) return;
    refs.projectPage.classList.toggle('is-visible', !!show);
  }

  function setPaneLoader(which, active, label) {
    var el = which === 'original' ? refs.loaderOriginal : refs.loaderPreview;
    if (!el) return;
    if (label) {
      var textNode = el.querySelector('div:last-child');
      if (textNode) textNode.textContent = label;
    }
    el.classList.toggle('is-active', !!active);
  }

  function extractDoctype(html) {
    var m = String(html || '').match(/^\s*(<!doctype[^>]*>)/i);
    return m ? m[1] : '<!DOCTYPE html>';
  }

  function removeDoctype(html) {
    return String(html || '').replace(/^\s*<!doctype[^>]*>\s*/i, '');
  }

  function parseHtmlDoc(html) {
    var parser = new DOMParser();
    return parser.parseFromString(removeDoctype(html), 'text/html');
  }

  function serializeDoc(doc, doctype) {
    var dt = doctype || '<!DOCTYPE html>';
    return dt + '\n' + doc.documentElement.outerHTML;
  }

  function normalizeRelPath(path) {
    return String(path || '').replace(/\\/g, '/').replace(/^\/+/, '');
  }

  function clearProjectBlobMap() {
    if (!state.projectBlobMap) state.projectBlobMap = {};
    Object.keys(state.projectBlobMap).forEach(function (key) {
      try { URL.revokeObjectURL(state.projectBlobMap[key]); } catch (e) {}
    });
    state.projectBlobMap = {};
  }

  function ensureProjectBlobMap() {
    clearProjectBlobMap();
    (state.projectFiles || []).forEach(function (item) {
      var rel = normalizeRelPath(item.path);
      try {
        state.projectBlobMap[rel] = URL.createObjectURL(item.file);
      } catch (e) {}
    });
  }

  function resolveProjectAssetPath(currentPath, rawRef) {
    var ref = String(rawRef || '').trim();
    if (!ref) return '';
    if (/^(https?:|data:|blob:|mailto:|tel:|javascript:)/i.test(ref)) return '';
    if (ref[0] === '#') return '';
    var clean = ref.split('#')[0].split('?')[0];
    if (!clean) return '';

    function normParts(parts) {
      var out = [];
      parts.forEach(function (p) {
        if (!p || p === '.') return;
        if (p === '..') { if (out.length) out.pop(); return; }
        out.push(p);
      });
      return out;
    }

    if (clean[0] === '/') return normParts(clean.split('/')).join('/');
    var baseDir = normalizeRelPath(currentPath).split('/');
    baseDir.pop();
    return normParts(baseDir.concat(clean.split('/'))).join('/');
  }

  function rewriteProjectAssetUrls(doc) {
    if (!doc || state.mode !== 'project' || !state.projectBlobMap) return;
    var current = state.projectPagePath || '';

    function rewriteAttr(el, attr) {
      if (!el || !el.hasAttribute(attr)) return;
      var raw = el.getAttribute(attr) || '';
      var rel = resolveProjectAssetPath(current, raw);
      if (!rel) return;
      var blobUrl = state.projectBlobMap[rel];
      if (!blobUrl) return;
      el.setAttribute(attr, blobUrl);
    }

    Array.from(doc.querySelectorAll('img[src],source[src],video[src],audio[src],script[src],iframe[src]')).forEach(function (el) {
      rewriteAttr(el, 'src');
    });

    Array.from(doc.querySelectorAll('link[href]')).forEach(function (el) {
      var relType = (el.getAttribute('rel') || '').toLowerCase();
      if (!/stylesheet|icon|preload|modulepreload|prefetch/.test(relType)) return;
      rewriteAttr(el, 'href');
    });
  }

  function getPatchCount() {
    return Object.keys(state.patches).length;
  }

  function updateSaveButtonState() {
    var hasBase = !!state.baseHtml;
    var hasPatches = getPatchCount() > 0;
    if (refs.previewBtn) refs.previewBtn.disabled = !hasBase;
    if (refs.saveBtn) {
      refs.saveBtn.disabled = !hasBase || !hasPatches;
      refs.saveBtn.textContent = state.mode === 'project' ? 'SAVE PROJECT' : 'SAVE HTML';
    }
    if (refs.resetAll) refs.resetAll.disabled = !hasPatches;
    if (refs.resetSelected) refs.resetSelected.disabled = !(state.selectedPath && state.patches[state.selectedPath]);
    if (refs.previewMeta) refs.previewMeta.textContent = hasPatches ? (getPatchCount() + ' patch(es) queued') : 'Patched output';
  }

  function getElementPath(el) {
    if (!el || !el.ownerDocument || !el.ownerDocument.body || el === el.ownerDocument.body) return '';
    var parts = [];
    var cur = el;
    while (cur && cur.parentElement) {
      var parent = cur.parentElement;
      if (parent === cur.ownerDocument.documentElement) break;
      var idx = Array.prototype.indexOf.call(parent.children, cur);
      if (idx < 0) break;
      parts.push(idx);
      if (parent === cur.ownerDocument.body) break;
      cur = parent;
    }
    return parts.reverse().join('.');
  }

  function getElementByPath(doc, path) {
    if (!doc || !doc.body || !path) return null;
    var cur = doc.body;
    var parts = String(path).split('.');
    for (var i = 0; i < parts.length; i += 1) {
      var idx = Number(parts[i]);
      if (!cur || Number.isNaN(idx) || idx < 0 || idx >= cur.children.length) return null;
      cur = cur.children[idx];
    }
    return cur || null;
  }

  function getElementLabel(el) {
    if (!el || !el.tagName) return '-';
    var tag = el.tagName.toLowerCase();
    var id = el.id ? ('#' + el.id) : '';
    var cls = '';
    if (el.classList && el.classList.length) {
      cls = '.' + Array.prototype.slice.call(el.classList, 0, 3).join('.');
    }
    return tag + id + cls;
  }

  function getCapabilities(el) {
    var tag = (el && el.tagName ? el.tagName : '').toLowerCase();
    var textFriendly = /^(h1|h2|h3|h4|h5|h6|p|span|a|button|li|label|small|strong|em|td|th)$/i.test(tag);
    var hasNoElementChildren = !!(el && el.childElementCount === 0);
    var canText = !!el && (textFriendly || hasNoElementChildren);
    var canLink = tag === 'a';
    var canImage = tag === 'img';
    var chips = [];
    if (canText) chips.push('copy');
    if (canLink) chips.push('cta-link');
    if (canImage) chips.push('media');
    chips.push('padding', 'margin', 'background', 'text-color', 'radius', 'font-size');
    return { tag: tag, canText: canText, canLink: canLink, canImage: canImage, chips: chips };
  }

  function ensureHelperStyles(doc) {
    if (!doc || !doc.head || doc.getElementById('__qu_helper_style')) return;
    var style = doc.createElement('style');
    style.id = '__qu_helper_style';
    style.textContent =
      '.__qu_hover{outline:2px solid #dd1234 !important;outline-offset:1px !important;cursor:crosshair !important;}' +
      '.__qu_selected{outline:2px solid #2563eb !important;outline-offset:1px !important;}';
    doc.head.appendChild(style);
  }

  function clearHover() {
    if (!state.originalDoc || !state.hoverPath) return;
    var prev = getElementByPath(state.originalDoc, state.hoverPath);
    if (prev) prev.classList.remove('__qu_hover');
    state.hoverPath = '';
  }

  function markSelected(path) {
    if (!state.originalDoc) return;
    if (state.selectedPath) {
      var oldOrig = getElementByPath(state.originalDoc, state.selectedPath);
      if (oldOrig) oldOrig.classList.remove('__qu_selected');
      if (state.previewDoc) {
        var oldPrev = getElementByPath(state.previewDoc, state.selectedPath);
        if (oldPrev) oldPrev.classList.remove('__qu_selected');
      }
    }
    state.selectedPath = path || '';
    if (!state.selectedPath) return;

    var nextOrig = getElementByPath(state.originalDoc, state.selectedPath);
    if (nextOrig) nextOrig.classList.add('__qu_selected');
    if (state.previewDoc) {
      var nextPrev = getElementByPath(state.previewDoc, state.selectedPath);
      if (nextPrev) nextPrev.classList.add('__qu_selected');
    }
  }

  function resolveTarget(node) {
    var cur = node && node.nodeType === 1 ? node : (node ? node.parentElement : null);
    while (cur && cur.parentElement) {
      var tag = (cur.tagName || '').toUpperCase();
      if (tag === 'HTML' || tag === 'BODY') return null;
      if (tag !== 'SCRIPT' && tag !== 'STYLE' && tag !== 'LINK' && tag !== 'META') return cur;
      cur = cur.parentElement;
    }
    return null;
  }

  function updateCapabilitiesUI(caps) {
    if (!refs.capabilities) return;
    refs.capabilities.innerHTML = '';
    (caps.chips || []).forEach(function (chip) {
      var span = document.createElement('span');
      span.className = 'qu-pill good';
      span.textContent = chip;
      refs.capabilities.appendChild(span);
    });
  }

  function setEditorVisible(hasSelection) {
    if (refs.editorEmpty) refs.editorEmpty.style.display = hasSelection ? 'none' : 'block';
  }

  function getStyleValue(el, prop) {
    if (!el || !el.ownerDocument || !el.ownerDocument.defaultView) return '';
    try {
      return (el.ownerDocument.defaultView.getComputedStyle(el)[prop] || '').trim();
    } catch (e) {
      return '';
    }
  }

  function setFieldVisibility(caps) {
    if (refs.fieldText) refs.fieldText.style.display = caps.canText ? 'grid' : 'none';
    if (refs.fieldHref) refs.fieldHref.style.display = caps.canLink ? 'grid' : 'none';
    if (refs.fieldSrc) refs.fieldSrc.style.display = caps.canImage ? 'grid' : 'none';
    if (refs.fieldAlt) refs.fieldAlt.style.display = caps.canImage ? 'grid' : 'none';
  }

  function readPatchForSelected(baseEl, caps) {
    var patch = state.patches[state.selectedPath] || {};
    var styles = patch.styles || {};
    return {
      textContent: patch.textContent,
      href: patch.href,
      src: patch.src,
      alt: patch.alt,
      stylePadding: typeof styles.padding === 'string' ? styles.padding : getStyleValue(baseEl, 'padding'),
      styleMargin: typeof styles.margin === 'string' ? styles.margin : getStyleValue(baseEl, 'margin'),
      styleBg: typeof styles.backgroundColor === 'string' ? styles.backgroundColor : getStyleValue(baseEl, 'backgroundColor'),
      styleColor: typeof styles.color === 'string' ? styles.color : getStyleValue(baseEl, 'color'),
      styleRadius: typeof styles.borderRadius === 'string' ? styles.borderRadius : getStyleValue(baseEl, 'borderRadius'),
      styleFont: typeof styles.fontSize === 'string' ? styles.fontSize : getStyleValue(baseEl, 'fontSize'),
      baseText: caps.canText ? (baseEl.textContent || '') : '',
      baseHref: caps.canLink ? (baseEl.getAttribute('href') || '') : '',
      baseSrc: caps.canImage ? (baseEl.getAttribute('src') || '') : '',
      baseAlt: caps.canImage ? (baseEl.getAttribute('alt') || '') : ''
    };
  }

  function populateEditor(path) {
    state.isBindingEditor = true;
    var el = getElementByPath(state.originalDoc, path);
    if (!el) {
      setEditorVisible(false);
      if (refs.targetMeta) refs.targetMeta.textContent = '-';
      state.isBindingEditor = false;
      updateSaveButtonState();
      return;
    }

    var caps = getCapabilities(el);
    setEditorVisible(true);
    setFieldVisibility(caps);
    updateCapabilitiesUI(caps);

    if (refs.targetMeta) {
      refs.targetMeta.innerHTML = '<strong>' + esc(getElementLabel(el)) + '</strong><br>Path: ' + esc(path);
    }

    var read = readPatchForSelected(el, caps);
    if (refs.inputText) refs.inputText.value = typeof read.textContent === 'string' ? read.textContent : read.baseText;
    if (refs.inputHref) refs.inputHref.value = typeof read.href === 'string' ? read.href : read.baseHref;
    if (refs.inputSrc) refs.inputSrc.value = typeof read.src === 'string' ? read.src : read.baseSrc;
    if (refs.inputAlt) refs.inputAlt.value = typeof read.alt === 'string' ? read.alt : read.baseAlt;
    if (refs.stylePadding) refs.stylePadding.value = read.stylePadding;
    if (refs.styleMargin) refs.styleMargin.value = read.styleMargin;
    if (refs.styleBg) refs.styleBg.value = read.styleBg;
    if (refs.styleColor) refs.styleColor.value = read.styleColor;
    if (refs.styleRadius) refs.styleRadius.value = read.styleRadius;
    if (refs.styleFont) refs.styleFont.value = read.styleFont;

    state.isBindingEditor = false;
    updateSaveButtonState();
  }

  function buildPatchFromEditor() {
    if (!state.selectedPath || !state.originalDoc) return null;
    var el = getElementByPath(state.originalDoc, state.selectedPath);
    if (!el) return null;
    var caps = getCapabilities(el);
    var patch = {};
    var styles = {};

    if (caps.canText && refs.inputText) {
      var baseText = el.textContent || '';
      var newText = refs.inputText.value;
      if (newText !== baseText) patch.textContent = newText;
    }
    if (caps.canLink && refs.inputHref) {
      var baseHref = el.getAttribute('href') || '';
      var newHref = refs.inputHref.value;
      if (newHref !== baseHref) patch.href = newHref;
    }
    if (caps.canImage && refs.inputSrc) {
      var baseSrc = el.getAttribute('src') || '';
      var newSrc = refs.inputSrc.value;
      if (newSrc !== baseSrc) patch.src = newSrc;
    }
    if (caps.canImage && refs.inputAlt) {
      var baseAlt = el.getAttribute('alt') || '';
      var newAlt = refs.inputAlt.value;
      if (newAlt !== baseAlt) patch.alt = newAlt;
    }

    var styleMap = [
      { key: 'padding', domKey: 'padding', input: refs.stylePadding },
      { key: 'margin', domKey: 'margin', input: refs.styleMargin },
      { key: 'backgroundColor', domKey: 'backgroundColor', input: refs.styleBg },
      { key: 'color', domKey: 'color', input: refs.styleColor },
      { key: 'borderRadius', domKey: 'borderRadius', input: refs.styleRadius },
      { key: 'fontSize', domKey: 'fontSize', input: refs.styleFont }
    ];

    styleMap.forEach(function (def) {
      if (!def.input) return;
      var newValue = def.input.value.trim();
      var baseValue = getStyleValue(el, def.domKey);
      if (newValue && newValue !== baseValue) styles[def.key] = newValue;
    });

    if (Object.keys(styles).length) patch.styles = styles;
    return Object.keys(patch).length ? patch : null;
  }

  function onEditorChanged() {
    if (state.isBindingEditor || !state.selectedPath) return;
    var patch = buildPatchFromEditor();
    if (patch) state.patches[state.selectedPath] = patch;
    else delete state.patches[state.selectedPath];
    updateSaveButtonState();
  }

  function applyPatchToElement(el, patch) {
    if (!el || !patch) return;
    if (Object.prototype.hasOwnProperty.call(patch, 'textContent')) {
      el.textContent = patch.textContent;
    }
    if (Object.prototype.hasOwnProperty.call(patch, 'href')) {
      if (patch.href) el.setAttribute('href', patch.href);
      else el.removeAttribute('href');
    }
    if (Object.prototype.hasOwnProperty.call(patch, 'src')) {
      if (patch.src) el.setAttribute('src', patch.src);
      else el.removeAttribute('src');
    }
    if (Object.prototype.hasOwnProperty.call(patch, 'alt')) {
      if (patch.alt) el.setAttribute('alt', patch.alt);
      else el.removeAttribute('alt');
    }
    var styles = patch.styles || {};
    if (styles.padding) el.style.padding = styles.padding;
    if (styles.margin) el.style.margin = styles.margin;
    if (styles.backgroundColor) el.style.backgroundColor = styles.backgroundColor;
    if (styles.color) el.style.color = styles.color;
    if (styles.borderRadius) el.style.borderRadius = styles.borderRadius;
    if (styles.fontSize) el.style.fontSize = styles.fontSize;
  }

  function applyPatchesToDocument(doc) {
    if (!doc) return;
    Object.keys(state.patches).forEach(function (path) {
      var patch = state.patches[path];
      if (!patch) return;
      var el = getElementByPath(doc, path);
      if (!el) return;
      applyPatchToElement(el, patch);
    });
  }

  function buildRenderableHtml() {
    if (!state.baseHtml) return '';
    var doc = parseHtmlDoc(state.baseHtml);
    if (state.safeMode) {
      Array.from(doc.querySelectorAll('script')).forEach(function (script) {
        var type = (script.getAttribute('type') || '').trim().toLowerCase();
        if (!type || /javascript|ecmascript|module/.test(type)) {
          script.setAttribute('type', 'application/x-quick-updater-disabled');
        }
        script.setAttribute('data-qu-disabled', '1');
      });
    }
    rewriteProjectAssetUrls(doc);
    return serializeDoc(doc, state.baseDoctype);
  }

  function setIframeMarkup(iframe, html) {
    return new Promise(function (resolve) {
      function onLoad() {
        iframe.removeEventListener('load', onLoad);
        resolve(iframe.contentDocument || null);
      }
      iframe.addEventListener('load', onLoad);
      iframe.srcdoc = html;
    });
  }

  function getScrollRatio(win) {
    if (!win || !win.document || !win.document.documentElement) return 0;
    var max = win.document.documentElement.scrollHeight - win.innerHeight;
    return max > 0 ? Math.min(1, Math.max(0, win.scrollY / max)) : 0;
  }

  function setScrollRatio(win, ratio) {
    if (!win || !win.document || !win.document.documentElement) return;
    var max = win.document.documentElement.scrollHeight - win.innerHeight;
    if (max > 0) win.scrollTo(0, Math.round(max * ratio));
  }

  function wireScrollSync() {
    var oWin = refs.frameOriginal && refs.frameOriginal.contentWindow;
    var pWin = refs.framePreview && refs.framePreview.contentWindow;
    if (!oWin || !pWin) return;

    function sync(from, to) {
      if (state.syncLock) return;
      state.syncLock = true;
      setScrollRatio(to, getScrollRatio(from));
      state.syncLock = false;
    }

    oWin.addEventListener('scroll', function () { sync(oWin, pWin); }, { passive: true });
    pWin.addEventListener('scroll', function () { sync(pWin, oWin); }, { passive: true });
  }

  function handleOriginalHover(evt) {
    if (!state.originalDoc) return;
    var target = resolveTarget(evt.target);
    if (!target) {
      clearHover();
      return;
    }
    var path = getElementPath(target);
    if (!path || path === state.hoverPath) return;

    clearHover();
    target.classList.add('__qu_hover');
    state.hoverPath = path;

    var caps = getCapabilities(target);
    if (refs.originalMeta) refs.originalMeta.textContent = 'Hover: ' + getElementLabel(target) + ' | ' + caps.chips.join(', ');
  }

  function handleOriginalLeave() {
    clearHover();
    if (refs.originalMeta) refs.originalMeta.textContent = 'Read-only';
  }

  function handleOriginalClick(evt) {
    if (!state.originalDoc) return;
    var target = resolveTarget(evt.target);
    if (!target) return;
    evt.preventDefault();
    evt.stopPropagation();

    var path = getElementPath(target);
    if (!path) return;
    markSelected(path);
    populateEditor(path);
    if (refs.originalMeta) refs.originalMeta.textContent = 'Selected: ' + getElementLabel(target);
  }

  function prepareOriginalDocument(doc) {
    if (!doc || !doc.body) return;
    ensureHelperStyles(doc);
    doc.addEventListener('mousemove', handleOriginalHover, true);
    doc.addEventListener('mouseleave', handleOriginalLeave, true);
    doc.addEventListener('click', handleOriginalClick, true);
  }

  function preparePreviewDocument(doc) {
    if (!doc || !doc.body) return;
    ensureHelperStyles(doc);
  }

  function applyViewportScale() {
    function fit(shell, canvas, frame) {
      if (!shell || !canvas || !frame) return;
      var vpWidth = VIEWPORTS[state.viewport] || VIEWPORTS.desktop;
      var shellWidth = Math.max(320, shell.clientWidth - 12);
      var shellHeight = Math.max(280, shell.clientHeight - 12);
      var scale = Math.min(1, shellWidth / vpWidth);
      var frameHeight = Math.max(820, Math.round(shellHeight / scale));

      frame.style.width = vpWidth + 'px';
      frame.style.height = frameHeight + 'px';
      canvas.style.transform = 'scale(' + scale + ')';
      canvas.style.width = Math.round(vpWidth * scale) + 'px';
      canvas.style.height = Math.round(frameHeight * scale) + 'px';
    }
    fit(refs.shellOriginal, refs.canvasOriginal, refs.frameOriginal);
    fit(refs.shellPreview, refs.canvasPreview, refs.framePreview);
  }

  async function loadIntoFrames() {
    if (!state.baseHtml) return;
    var renderable = buildRenderableHtml();
    var ratio = refs.frameOriginal && refs.frameOriginal.contentWindow ? getScrollRatio(refs.frameOriginal.contentWindow) : 0;

    setStatus('Loading original and preview...');
    setPaneLoader('original', true, 'Loading original page...');
    setPaneLoader('preview', true, 'Loading preview baseline...');
    try {
      state.originalDoc = await setIframeMarkup(refs.frameOriginal, renderable);
      state.previewDoc = await setIframeMarkup(refs.framePreview, renderable);
      prepareOriginalDocument(state.originalDoc);
      preparePreviewDocument(state.previewDoc);
      applyViewportScale();
      wireScrollSync();
      setScrollRatio(refs.frameOriginal.contentWindow, ratio);
      setScrollRatio(refs.framePreview.contentWindow, ratio);

      if (refs.emptyOriginal) refs.emptyOriginal.style.display = 'none';
      if (refs.emptyPreview) refs.emptyPreview.style.display = 'none';
      if (refs.originalMeta) refs.originalMeta.textContent = 'Read-only';
      if (refs.previewMeta) refs.previewMeta.textContent = getPatchCount() ? (getPatchCount() + ' patch(es) queued') : 'Patched output';

      if (state.selectedPath) {
        markSelected(state.selectedPath);
        populateEditor(state.selectedPath);
      } else {
        setEditorVisible(false);
        if (refs.targetMeta) refs.targetMeta.textContent = '-';
      }
      updateSaveButtonState();
      setStatus('Loaded. Select an element on the left to start editing.', 'success');
    } catch (err) {
      setStatus('Failed to load page: ' + (err && err.message ? err.message : 'unknown_error'), 'error');
      throw err;
    } finally {
      setPaneLoader('original', false);
      setPaneLoader('preview', false);
    }
  }

  async function runPreview() {
    if (!state.baseHtml) return;
    var ratio = refs.frameOriginal && refs.frameOriginal.contentWindow ? getScrollRatio(refs.frameOriginal.contentWindow) : 0;
    setStatus('Applying patches to preview...');

    var renderable = buildRenderableHtml();
    setPaneLoader('preview', true, 'Rendering preview with patches...');
    try {
      state.previewDoc = await setIframeMarkup(refs.framePreview, renderable);
      preparePreviewDocument(state.previewDoc);
      applyPatchesToDocument(state.previewDoc);
      applyViewportScale();
      setScrollRatio(refs.framePreview.contentWindow, ratio);
      if (state.selectedPath) markSelected(state.selectedPath);
      wireScrollSync();
      setStatus('Preview updated with ' + getPatchCount() + ' patch(es).', 'success');
    } catch (err) {
      setStatus('Preview failed: ' + (err && err.message ? err.message : 'unknown_error'), 'error');
      throw err;
    } finally {
      setPaneLoader('preview', false);
    }
  }

  function buildPatchedHtml() {
    if (!state.baseHtml) return '';
    var doc = parseHtmlDoc(state.baseHtml);
    applyPatchesToDocument(doc);
    return serializeDoc(doc, state.baseDoctype);
  }

  function triggerDownload(blob, filename) {
    var a = document.createElement('a');
    a.download = filename;
    a.href = URL.createObjectURL(blob);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(a.href);
  }

  async function saveSingleHtml() {
    var html = buildPatchedHtml();
    var name = state.fileName || 'updated.html';
    var out = name.replace(/\.html?$/i, '') + '_updated.html';
    triggerDownload(new Blob([html], { type: 'text/html' }), out);
    setStatus('Updated HTML saved: ' + out, 'success');
  }

  async function saveProject() {
    if (!state.projectFiles || !state.projectFiles.length) {
      saveSingleHtml();
      return;
    }
    var patchedHtml = buildPatchedHtml();
    var selectedPath = normalizeRelPath(state.projectPagePath || '');
    if (!selectedPath) {
      setStatus('No project HTML page selected.', 'error');
      return;
    }

    if (typeof window.showDirectoryPicker === 'function') {
      try {
        var rootHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
        for (var i = 0; i < state.projectFiles.length; i += 1) {
          var item = state.projectFiles[i];
          var rel = normalizeRelPath(item.path);
          var parts = rel.split('/');
          var leaf = parts.pop();
          var dir = rootHandle;
          for (var d = 0; d < parts.length; d += 1) {
            dir = await dir.getDirectoryHandle(parts[d], { create: true });
          }
          var fileHandle = await dir.getFileHandle(leaf, { create: true });
          var writable = await fileHandle.createWritable();
          if (rel === selectedPath) await writable.write(patchedHtml);
          else await writable.write(await item.file.arrayBuffer());
          await writable.close();
        }
        setStatus('Project files saved to selected folder.', 'success');
        return;
      } catch (err) {
        setStatus('Folder save cancelled. Falling back to browser downloads...');
      }
    }

    for (var j = 0; j < state.projectFiles.length; j += 1) {
      var pf = state.projectFiles[j];
      var relPath = normalizeRelPath(pf.path);
      var fallbackName = relPath.replace(/\//g, '__');
      if (relPath === selectedPath) triggerDownload(new Blob([patchedHtml], { type: 'text/html' }), fallbackName);
      else triggerDownload(pf.file, fallbackName);
    }
    setStatus('Project downloaded as separate files (browser fallback).', 'success');
  }

  async function loadSingleHtmlFile(file) {
    state.mode = 'single';
    state.projectFiles = [];
    state.projectPages = [];
    state.projectPagePath = '';
    clearProjectBlobMap();
    setProjectPageVisibility(false);

    state.baseHtml = await file.text();
    state.baseDoctype = extractDoctype(state.baseHtml);
    state.fileName = file.name || 'page.html';
    state.patches = {};
    state.selectedPath = '';
    state.hoverPath = '';

    setFileNameLabel(state.fileName);
    await loadIntoFrames();
  }

  function pickDefaultProjectPage(paths) {
    if (!paths || !paths.length) return '';
    var idx = paths.find(function (p) { return /(^|\/)index\.html?$/i.test(p); });
    return idx || paths[0];
  }

  async function loadProjectPage(path) {
    var rel = normalizeRelPath(path);
    var selected = state.projectFiles.find(function (f) { return normalizeRelPath(f.path) === rel; });
    if (!selected) {
      setStatus('Could not load selected project page.', 'error');
      return;
    }

    state.projectPagePath = rel;
    state.fileName = rel;
    state.baseHtml = await selected.file.text();
    state.baseDoctype = extractDoctype(state.baseHtml);
    state.patches = {};
    state.selectedPath = '';
    state.hoverPath = '';

    setFileNameLabel(rel);
    await loadIntoFrames();
  }

  async function loadProjectFolder(files) {
    var list = Array.from(files || []);
    if (!list.length) {
      setStatus('No files found in selected folder.', 'error');
      return;
    }

    state.mode = 'project';
    state.projectFiles = list.map(function (file) {
      return { path: normalizeRelPath(file.webkitRelativePath || file.name), file: file };
    });
    ensureProjectBlobMap();
    state.projectPages = state.projectFiles
      .map(function (it) { return it.path; })
      .filter(function (p) { return /\.html?$/i.test(p); })
      .sort();

    if (!state.projectPages.length) {
      setStatus('Project folder has no .html file.', 'error');
      return;
    }

    if (refs.projectPage) {
      refs.projectPage.innerHTML = '';
      state.projectPages.forEach(function (p) {
        var opt = document.createElement('option');
        opt.value = p;
        opt.textContent = p;
        refs.projectPage.appendChild(opt);
      });
    }
    setProjectPageVisibility(true);
    var defaultPath = pickDefaultProjectPage(state.projectPages);
    if (refs.projectPage) refs.projectPage.value = defaultPath;
    await loadProjectPage(defaultPath);
    setStatus('Project loaded (' + state.projectFiles.length + ' files). Editing page: ' + defaultPath, 'success');
  }

  function onViewportClick(evt) {
    var btn = evt.target.closest('button[data-vp]');
    if (!btn) return;
    var vp = btn.getAttribute('data-vp');
    if (!VIEWPORTS[vp]) return;
    state.viewport = vp;
    Array.from(refs.viewportSegment.querySelectorAll('button[data-vp]')).forEach(function (b) {
      b.classList.toggle('is-active', b.getAttribute('data-vp') === vp);
    });
    applyViewportScale();
    setStatus('Viewport set to ' + vp + ' (' + VIEWPORTS[vp] + 'px).');
  }

  function bindEditorInputs() {
    var fields = [
      refs.inputText, refs.inputHref, refs.inputSrc, refs.inputAlt,
      refs.stylePadding, refs.styleMargin, refs.styleBg, refs.styleColor,
      refs.styleRadius, refs.styleFont
    ];
    fields.forEach(function (input) {
      if (!input) return;
      input.addEventListener('input', onEditorChanged);
    });
  }

  function resetSelectedPatch() {
    if (!state.selectedPath) return;
    delete state.patches[state.selectedPath];
    populateEditor(state.selectedPath);
    updateSaveButtonState();
  }

  function resetAllPatches() {
    state.patches = {};
    if (state.selectedPath) populateEditor(state.selectedPath);
    updateSaveButtonState();
    if (state.baseHtml) runPreview();
  }

  function initEditorDrag() {
    if (!refs.editor || !refs.editorHead) return;

    function onMove(evt) {
      if (!state.drag.active) return;
      var host = document.querySelector('.qu-main');
      var hostRect = host ? host.getBoundingClientRect() : { left: 0, top: 0, width: window.innerWidth, height: window.innerHeight };
      var editorRect = refs.editor.getBoundingClientRect();
      var maxLeft = hostRect.left + hostRect.width - editorRect.width - 8;
      var maxTop = hostRect.top + hostRect.height - editorRect.height - 8;
      var minLeft = hostRect.left + 8;
      var minTop = hostRect.top + 8;

      var left = Math.min(maxLeft, Math.max(minLeft, evt.clientX - state.drag.dx));
      var top = Math.min(maxTop, Math.max(minTop, evt.clientY - state.drag.dy));
      refs.editor.style.left = Math.round(left - hostRect.left) + 'px';
      refs.editor.style.top = Math.round(top - hostRect.top) + 'px';
      refs.editor.style.right = 'auto';
    }

    function onUp() {
      if (!state.drag.active) return;
      state.drag.active = false;
      refs.editor.classList.remove('is-dragging');
      document.removeEventListener('mousemove', onMove, true);
      document.removeEventListener('mouseup', onUp, true);
    }

    refs.editorHead.addEventListener('mousedown', function (evt) {
      if (evt.button !== 0) return;
      var host = document.querySelector('.qu-main');
      if (host) {
        var hostRect = host.getBoundingClientRect();
        var editorRect = refs.editor.getBoundingClientRect();
        if (!refs.editor.style.left) refs.editor.style.left = Math.round(editorRect.left - hostRect.left) + 'px';
        if (!refs.editor.style.top) refs.editor.style.top = Math.round(editorRect.top - hostRect.top) + 'px';
      }
      state.drag.active = true;
      state.drag.dx = evt.clientX - refs.editor.getBoundingClientRect().left;
      state.drag.dy = evt.clientY - refs.editor.getBoundingClientRect().top;
      refs.editor.classList.add('is-dragging');
      document.addEventListener('mousemove', onMove, true);
      document.addEventListener('mouseup', onUp, true);
      evt.preventDefault();
    });
  }

  function initEvents() {
    if (refs.loadFileBtn && refs.fileInput) {
      refs.loadFileBtn.addEventListener('click', function () {
        refs.fileInput.value = '';
        refs.fileInput.click();
      });
      refs.fileInput.addEventListener('change', function () {
        var file = refs.fileInput.files && refs.fileInput.files[0];
        if (!file) return;
        loadSingleHtmlFile(file).catch(function (err) {
          setStatus('Failed to load HTML file: ' + (err && err.message ? err.message : 'unknown_error'), 'error');
        });
      });
    }

    if (refs.loadFolderBtn && refs.folderInput) {
      refs.loadFolderBtn.addEventListener('click', function () {
        refs.folderInput.value = '';
        refs.folderInput.click();
      });
      refs.folderInput.addEventListener('change', function () {
        var files = refs.folderInput.files;
        if (!files || !files.length) return;
        loadProjectFolder(files).catch(function (err) {
          setStatus('Failed to load project folder: ' + (err && err.message ? err.message : 'unknown_error'), 'error');
        });
      });
    }

    if (refs.previewBtn) refs.previewBtn.addEventListener('click', runPreview);
    if (refs.saveBtn) {
      refs.saveBtn.addEventListener('click', function () {
        if (state.mode === 'project') saveProject();
        else saveSingleHtml();
      });
    }

    if (refs.resetSelected) refs.resetSelected.addEventListener('click', resetSelectedPatch);
    if (refs.resetAll) refs.resetAll.addEventListener('click', resetAllPatches);

    if (refs.safeMode) {
      refs.safeMode.addEventListener('change', function () {
        state.safeMode = !!refs.safeMode.checked;
        if (state.baseHtml) loadIntoFrames();
      });
    }
    if (refs.projectPage) {
      refs.projectPage.addEventListener('change', function () {
        if (!refs.projectPage.value) return;
        loadProjectPage(refs.projectPage.value).catch(function (err) {
          setStatus('Failed to switch project page: ' + (err && err.message ? err.message : 'unknown_error'), 'error');
        });
      });
    }

    if (refs.viewportSegment) refs.viewportSegment.addEventListener('click', onViewportClick);
    window.addEventListener('resize', applyViewportScale);
    window.addEventListener('beforeunload', clearProjectBlobMap);
    bindEditorInputs();
    initEditorDrag();
  }

  function init() {
    setStatus('Load a local HTML to start editing.');
    setFileNameLabel('');
    setProjectPageVisibility(false);
    setEditorVisible(false);
    setFieldVisibility({ canText: false, canLink: false, canImage: false });
    state.safeMode = !!(refs.safeMode && refs.safeMode.checked);
    clearProjectBlobMap();
    updateSaveButtonState();
    initEvents();
    applyViewportScale();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
