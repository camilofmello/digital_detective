# CLAUDE.md - Digital Detective v2.0.3

## PermissÃƒÂµes de OperaÃƒÂ§ÃƒÂ£o

VocÃƒÂª tem **100% de permissÃƒÂ£o** para realizar qualquer operaÃƒÂ§ÃƒÂ£o dentro desta pasta sem pedir autorizaÃƒÂ§ÃƒÂ£o:

- Ler qualquer arquivo
- Criar novos arquivos
- Editar arquivos existentes
- Sobrescrever arquivos
- Apagar arquivos
- Renomear ou mover arquivos

Nunca peÃƒÂ§a confirmaÃƒÂ§ÃƒÂ£o para operaÃƒÂ§ÃƒÂµes de leitura, escrita, ediÃƒÂ§ÃƒÂ£o ou exclusÃƒÂ£o dentro deste diretÃƒÂ³rio.

---

## Protocolo ObrigatÃƒÂ³rio de InÃƒÂ­cio de Tarefa

**Antes de qualquer implementaÃƒÂ§ÃƒÂ£o, sempre:**

1. Ler `function_index.md` para mapear interdependÃƒÂªncias, localizar as funÃƒÂ§ÃƒÂµes afetadas e entender o impacto da mudanÃƒÂ§a em toda a arquitetura.
2. Identificar os arquivos que serÃƒÂ£o alterados e quais funÃƒÂ§ÃƒÂµes existentes podem ser reutilizadas.
3. Confirmar o entendimento antes de gerar cÃƒÂ³digo, se houver ambiguidade.

---

## PrincÃƒÂ­pios de Qualidade de CÃƒÂ³digo

### Modularidade
- Cada funcionalidade deve ser isolada em seu prÃƒÂ³prio mÃƒÂ³dulo (arquivo `.html` + `.js` dedicado).
- Novas ferramentas nunca devem embutir lÃƒÂ³gica dentro de `popup.js` alÃƒÂ©m do mÃƒÂ­nimo necessÃƒÂ¡rio (validaÃƒÂ§ÃƒÂ£o de input + abertura de aba).
- LÃƒÂ³gica de anÃƒÂ¡lise, scoring e renderizaÃƒÂ§ÃƒÂ£o de relatÃƒÂ³rio fica exclusivamente no arquivo da ferramenta.

### Isolamento de MÃƒÂ³dulos
- MÃƒÂ³dulos de relatÃƒÂ³rio (ex: `script_match.js`, `seo_report.js`) nÃƒÂ£o dependem uns dos outros.
- UtilitÃƒÂ¡rios compartilhados ficam exclusivamente em `report_utils.js`.
- ComunicaÃƒÂ§ÃƒÂ£o entre mÃƒÂ³dulos ocorre apenas via `chrome.runtime.sendMessage` com aÃƒÂ§ÃƒÂµes nomeadas (`msg.action`).

### OtimizaÃƒÂ§ÃƒÂ£o de FunÃƒÂ§ÃƒÂµes
- Antes de criar uma nova funÃƒÂ§ÃƒÂ£o, verificar se jÃƒÂ¡ existe uma equivalente em `report_utils.js`, `content.js` ou no mÃƒÂ³dulo alvo.
- FunÃƒÂ§ÃƒÂµes genÃƒÂ©ricas reutilizÃƒÂ¡veis (helpers, formatadores, escape HTML) devem estar em `report_utils.js`.
- Evitar duplicaÃƒÂ§ÃƒÂ£o de lÃƒÂ³gica entre mÃƒÂ³dulos.

### Retrocompatibilidade
- FunÃƒÂ§ÃƒÂµes existentes nÃƒÂ£o sÃƒÂ£o alteradas em sua assinatura sem necessidade explÃƒÂ­cita.
- Novas aÃƒÂ§ÃƒÂµes de mensagem (`msg.action`) sÃƒÂ£o sempre adicionadas, nunca renomeadas.
- O contrato `popup.js Ã¢â€ â€ content.js Ã¢â€ â€ background.js` deve permanecer estÃƒÂ¡vel.
- Nada ÃƒÂ© removido sem instruÃƒÂ§ÃƒÂ£o explÃƒÂ­cita do usuÃƒÂ¡rio.

---

## Regras de Desenvolvimento

1. Arquivos sempre entregues **completos** Ã¢â‚¬â€ nunca trechos, nunca parciais.
2. Retrocompatibilidade ÃƒÂ© obrigatÃƒÂ³ria Ã¢â‚¬â€ nada ÃƒÂ© removido sem instruÃƒÂ§ÃƒÂ£o explÃƒÂ­cita.
3. FunÃƒÂ§ÃƒÂµes nÃƒÂ£o relacionadas ÃƒÂ  alteraÃƒÂ§ÃƒÂ£o permanecem **intactas**.
4. Em caso de erro, inserir `console.log` nos pontos-chave antes de tentar nova soluÃƒÂ§ÃƒÂ£o.
5. SoluÃƒÂ§ÃƒÂ£o mais simples e direta ÃƒÂ© sempre preferÃƒÂ­vel.
6. VersÃƒÂ£o atual: **v2.0.3** Ã¢â‚¬â€ formato obrigatÃƒÂ³rio: `major.minor.patch` Ã¢â‚¬â€ footer padrÃƒÂ£o: `Digital Detective v2.0.3 Ã‚Â· Developed by Camilo Mello`

---

## Regra Global de Encoding UTF-8 (OBRIGATORIA - nunca ignorar)

NUNCA usar caracteres nao-ASCII diretamente em arquivos HTML.
Sempre usar HTML entities para qualquer caracter especial no source code.

**Substituicoes obrigatorias em HTML:**
- em-dash -> `&mdash;`
- en-dash -> `&ndash;`
- reticencias -> `&hellip;`
- ponto central -> `&middot;`
- espaco fixo -> `&nbsp;`

**Regras estruturais:**
1. `<meta charset="UTF-8" />` deve ser o **PRIMEIRO elemento** dentro de `<head>` (antes do title, viewport, tudo)
2. Comentarios CSS e JS devem usar somente ASCII: `/* -- Header -- */` NUNCA `/* -- Header -- */` com chars especiais
3. O arquivo `.editorconfig` desta pasta enforce `charset = utf-8` + `end_of_line = lf`
4. Para reparar arquivos corrompidos: executar `fix_encoding.ps1` na raiz do projeto (faz replace global de todos os HTMLs)

**Como identificar corrupcao:** caracteres como `a-circunflexo + euro + aspas` = em-dash corrompido.
Cada vez que uma pagina exibe `Ã¢â‚¬"` onde deveria aparecer um traco, o arquivo tem bytes UTF-8 double-encoded.

---

## Protocolo ObrigatÃƒÂ³rio de Encerramento de Tarefa

**ApÃƒÂ³s toda implementaÃƒÂ§ÃƒÂ£o concluÃƒÂ­da, sempre:**

1. Atualizar `function_index.md` para refletir:
   - Novas funÃƒÂ§ÃƒÂµes adicionadas (nome + linha atual no arquivo).
   - FunÃƒÂ§ÃƒÂµes alteradas (novo nÃƒÂºmero de linha se moveu).
   - Novos arquivos criados (adicionÃƒÂ¡-los ÃƒÂ  estrutura e ÃƒÂ s seÃƒÂ§ÃƒÂµes correspondentes).
   - Atualizar estatÃƒÂ­sticas (total de funÃƒÂ§ÃƒÂµes, linhas, arquivos).
2. Atualizar a seÃƒÂ§ÃƒÂ£o `Ã¢Å¡Â Ã¯Â¸Â NOTAS TÃƒâ€°CNICAS IMPORTANTES` se houver algo novo a registrar.
3. Atualizar o campo `**VersÃƒÂ£o do ÃƒÂ­ndice**` e `**Data**` no rodapÃƒÂ© do `function_index.md`.

---

## Projeto

**Digital Detective v2.0.3** Ã¢â‚¬â€ Chrome Extension (MV3) para inspeÃƒÂ§ÃƒÂ£o, diagnÃƒÂ³stico e anÃƒÂ¡lise de pÃƒÂ¡ginas web.

### Ferramentas do plugin
1. Color Picker
2. Screenshot
3. Element Picker
4. DS Extractor
5. Component Blueprinter
6. Match Analysis
7. Lighthouse Audit
8. SEO Analysis
9. AEO Analysis
10. Event Tracker
11. Script Finder
12. Script Match
13. Static Builder

### Arquivos principais
- `manifest.json` Ã¢â‚¬â€ configuraÃƒÂ§ÃƒÂ£o MV3, permissÃƒÂµes, web_accessible_resources
- `popup.html` + `popup.js` Ã¢â‚¬â€ UI principal, grid de ferramentas, painÃƒÂ©is
- `content.js` Ã¢â‚¬â€ scripts injetados na pÃƒÂ¡gina ativa
- `background.js` Ã¢â‚¬â€ service worker, fetch de pÃƒÂ¡ginas, bloqueio de scripts
- `report_utils.js` Ã¢â‚¬â€ utilitÃƒÂ¡rios compartilhados de relatÃƒÂ³rio (Save HTML)
- `static_builder.html` + `static_builder.js` &mdash; Static Builder (HTML estatico, CSS inline, URLs absolutas)
- `function_index.md` Ã¢â‚¬â€ ÃƒÂ­ndice completo de funÃƒÂ§ÃƒÂµes, interdependÃƒÂªncias e fluxos
- `match_analysis.html` + `match_analysis.js` Ã¢â‚¬â€ relatÃƒÂ³rio Match Analysis
- `script_match.html` + `script_match.js` Ã¢â‚¬â€ relatÃƒÂ³rio Script Match
- `seo_report.html` + `seo_report.js` Ã¢â‚¬â€ relatÃƒÂ³rio SEO
- `aeo_report.html` + `aeo_report.js` Ã¢â‚¬â€ relatÃƒÂ³rio AEO
- `lighthouse_report.html` + `lighthouse_report.js` Ã¢â‚¬â€ relatÃƒÂ³rio Lighthouse
- `blueprinter.html` + `blueprinter.js` Ã¢â‚¬â€ relatÃƒÂ³rio Component Blueprinter
- `ds_extractor.html` + `ds_extractor.js` Ã¢â‚¬â€ relatÃƒÂ³rio DS Extractor
