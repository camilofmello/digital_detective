﻿(function () {
  'use strict';

  var PILLAR_WEIGHTS = {
    eligibilityAccess: 25,
    answerability: 25,
    semanticClarity: 20,
    citationExtractionReadiness: 15,
    multiQueryCoverage: 15
  };

  var PILLAR_LABELS = {
    eligibilityAccess: 'Eligibility & Access',
    answerability: 'Answerability',
    semanticClarity: 'Semantic Clarity',
    citationExtractionReadiness: 'Citation & Extraction Readiness',
    multiQueryCoverage: 'Multi-Query Coverage'
  };

  var RULE_VALUES = { pass: 1, warning: 0.5, fail: 0, not_applicable: 0 };

  var CONFIG = {
    minVisibleWords: 45,
    thresholds: { post: 700, page: 250, product: 180, category: 150, homepage: 0, profile: 200 },
    stop: ['a', 'an', 'the', 'and', 'or', 'but', 'for', 'with', 'from', 'this', 'that', 'de', 'da', 'do', 'das', 'dos', 'com', 'sem', 'para', 'por', 'que', 'como'],
    vague: ['thing', 'things', 'stuff', 'various', 'many', 'several', 'some', 'maybe', 'generally', 'coisa', 'coisas', 'varios', 'varias', 'muitos', 'muitas', 'alguns', 'algumas']
  };

  function setStatus(text) {
    var el = document.getElementById('aeo-status');
    if (el) el.textContent = text || '';
  }

  function esc(text) {
    return String(text || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function failPage(message) {
    var loading = document.getElementById('aeo-loading');
    if (!loading) return;
    loading.innerHTML = '<div class="aeo-error"><div class="aeo-error-title">AEO Analysis failed</div><div class="aeo-error-msg">' + esc(message) + '</div></div>';
  }

  function cap(v, min, max) { return Math.max(min, Math.min(max, v)); }
  function round(v, p) {
    var pow = Math.pow(10, typeof p === 'number' ? p : 0);
    return Math.round((v || 0) * pow) / pow;
  }

  function fold(text) {
    var value = String(text || '');
    try { return value.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (e) { return value; }
  }

  function norm(text) {
    return fold(String(text || '')).toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function words(text) {
    return String(text || '').split(/\s+/).filter(function (t) { return t && t.trim(); }).length;
  }

  function uniq(arr) {
    var seen = {};
    return (arr || []).filter(function (v) {
      var k = String(v || '');
      if (!k || seen[k]) return false;
      seen[k] = true;
      return true;
    });
  }

  function tok(text) {
    return norm(text).split(' ').filter(function (t) { return t.length > 2 && CONFIG.stop.indexOf(t) === -1; });
  }

  function overlap(a, b) {
    var x = uniq(a || []);
    var y = uniq(b || []);
    if (!x.length || !y.length) return 0;
    var hits = x.filter(function (t) { return y.indexOf(t) !== -1; }).length;
    return hits / Math.max(x.length, y.length);
  }

  function splitSentences(text) {
    return String(text || '').split(/[.!?\n]+/).map(function (s) { return s.trim(); }).filter(function (s) { return words(s) >= 3; });
  }

  function grade(score) {
    if (score >= 90) return 'Excellent';
    if (score >= 75) return 'Strong';
    if (score >= 60) return 'Fair';
    if (score >= 40) return 'Weak';
    return 'Critical';
  }

  function scoreColor(score) {
    if (score >= 80) return '#16a34a';
    if (score >= 55) return '#d97706';
    return '#dd1234';
  }

  function pageType(s) {
    var path = '';
    try { path = new URL(s.url || '').pathname.toLowerCase(); } catch (e) {}
    if (s.hasProfileSchema || /\/author\/|\/profile\/|\/creator\/|\/team\//.test(path)) return 'profile';
    if (s.hasProductSchema || (s.hasPriceEl && s.hasCartCta)) return 'product';
    if (s.hasArticleSchema || (s.hasArticleEl && s.hasPublishDate) || (s.hasAuthor && (s.visibleWordCount || 0) > 450 && (s.h2s || []).length >= 2)) return 'post';
    if (s.isRootUrl) return 'homepage';
    if ((s.hasPagination && s.hasItemCards) || (s.hasItemCards && (s.visibleWordCount || 0) < 550)) return 'category';
    return 'page';
  }

  function intent(type) {
    if (type === 'product') return 'transactional';
    if (type === 'category') return 'commercial investigation';
    if (type === 'homepage' || type === 'profile') return 'navigational';
    return 'informational';
  }

  function inferTopic(s) {
    var c = [];
    if (s.h1s && s.h1s[0]) c.push(s.h1s[0]);
    if (s.title) c.push(s.title);
    if (s.ogTags && s.ogTags['og:title']) c.push(s.ogTags['og:title']);
    if (s.schemaItems && s.schemaItems.length) {
      s.schemaItems.slice(0, 6).forEach(function (item) {
        if (item.name) c.push(item.name);
        if (item.headline) c.push(item.headline);
      });
    }
    if (s.slug) c.push(String(s.slug).replace(/[-_]/g, ' '));
    c = c.map(function (t) { return String(t || '').replace(/\s+/g, ' ').trim(); }).filter(Boolean).sort(function (a, b) { return tok(b).length - tok(a).length; });
    return c[0] || 'unknown topic';
  }

  function canonState(url, canonical) {
    if (!canonical) return 'missing';
    try {
      var p = new URL(url);
      var c = new URL(canonical, url);
      if (p.origin !== c.origin) return 'unrelated';
      var pp = (p.pathname || '/').replace(/\/$/, '') || '/';
      var cp = (c.pathname || '/').replace(/\/$/, '') || '/';
      return pp === cp ? 'equivalent' : 'minor_mismatch';
    } catch (e) {
      return 'invalid';
    }
  }

  function applies(type, list) {
    return !list || !list.length || list.indexOf(type) !== -1;
  }

  function mk(category, ruleId, label, weight, status, details, recommendation) {
    return {
      category: category,
      ruleId: ruleId,
      label: label,
      weight: weight,
      status: status,
      details: details || '',
      recommendation: recommendation || '',
      scoreContribution: round((RULE_VALUES[status] || 0) * weight, 2)
    };
  }

  function evalRule(type, meta, fn) {
    if (!applies(type, meta.appliesTo)) return mk(meta.category, meta.ruleId, meta.label, meta.weight, 'not_applicable', 'Not applicable for this page type.');
    var out = fn();
    return mk(meta.category, meta.ruleId, meta.label, meta.weight, out.status, out.details, out.recommendation);
  }

  function derive(s, type, topic) {
    var intro = [s.introText || '', s.firstParagraph || ''].concat((s.topBlocks || []).slice(0, 4).map(function (b) { return b.text || ''; })).join(' ').trim();
    var body = String(s.mainText || s.bodyText || '');
    var bodyTokens = tok(body);
    var sent = splitSentences(body);
    var longRatio = sent.length ? sent.filter(function (x) { return words(x) > 28; }).length / sent.length : 0;
    var vague = bodyTokens.filter(function (t) { return CONFIG.vague.indexOf(t) !== -1; }).length;
    var vagueDensity = bodyTokens.length ? vague / bodyTokens.length : 0;
    var para = (s.paragraphs || []).filter(function (p) { return p && p.words >= 4; });
    var usable = para.filter(function (p) { return p.words >= 25 && p.words <= 120; }).length;
    var bloated = para.filter(function (p) { return p.words > 180; }).length;
    var chunkability = para.length ? usable / para.length : 0;
    var bloatedRatio = para.length ? bloated / para.length : 0;
    var topAnswer = (s.topBlocks || []).find(function (b, idx) {
      var w = b.words || words(b.text || '');
      if (idx > 5 || w < 8 || w > 90) return false;
      var t = String(b.text || '');
      return /\.|:/.test(t) || /( is | are | means | refers to | includes | can | should | helps )/i.test(' ' + t + ' ');
    }) || null;
    var schemaTypes = (s.schemaTypes || []).map(function (x) { return String(x || '').toLowerCase(); });
    var hasSchema = !!(schemaTypes.length || (s.schemaItems || []).length);
    var expected = {
      product: /product/,
      post: /article|blogposting|newsarticle|techarticle/,
      profile: /person|profilepage|author/,
      category: /collectionpage|itemlist|breadcrumblist|webpage/,
      homepage: /website|organization|webpage/,
      page: /webpage|faqpage|howto|organization|service|aboutpage/
    }[type] || /webpage/;
    var hasExpectedSchema = schemaTypes.some(function (x) { return expected.test(x); });
    var genericOnly = hasSchema && schemaTypes.every(function (x) { return /webpage|website|thing|organization/.test(x); });
    var schemaText = (s.schemaItems || []).slice(0, 8).map(function (it) {
      return [it.name, it.headline, it.description, it.about, it.mainEntity].join(' ');
    }).join(' ');
    var visibleText = [s.title || '', (s.h1s || [])[0] || '', intro, (s.h2s || []).slice(0, 8).join(' ')].join(' ');
    var schemaMatch = overlap(tok(schemaText), tok(visibleText));
    var topicTokens = tok(topic);
    var topicIntro = overlap(topicTokens, tok(intro));
    var titleH1 = overlap(tok(s.title || ''), tok((s.h1s || [])[0] || ''));
    var topicConsistency = overlap(topicTokens, tok(visibleText));
    var entitySignal = cap((topicTokens.length >= 2 ? 0.35 : 0) + (tok((s.h1s || [])[0] || '').length >= 2 ? 0.25 : 0) + ((s.schemaItems || []).some(function (it) { return it && (it.name || it.headline); }) ? 0.25 : 0), 0, 1);
    var internal = (s.internalLinks || []).filter(function (a) { return a && !a.isHash && !a.isJs && !a.isMailOrTel; });
    var related = (s.relatedMainLinks || []).filter(function (a) { return a && a.inMain && words(a.text || '') >= 2; });
    var jsNav = (s.jsNavigationSignals && s.jsNavigationSignals.clickableJsNav) || 0;
    var jsNavDominant = internal.length <= 1 && jsNav >= 4;
    var ext = (s.externalLinks || []).filter(function (a) {
      var h = String((a && a.href) || '').toLowerCase();
      return h && h.indexOf('facebook.com') === -1 && h.indexOf('instagram.com') === -1 && h.indexOf('tiktok.com') === -1;
    });
    var listSignal = (s.listCount || 0) > 0 ? 1 : 0;
    var tableSignal = (s.tableCount || 0) > 0 ? 1 : 0;
    var faqSignal = (s.hasFaqSection || (s.answerLikeBlocks || 0) > 0) ? 1 : 0;
    var followSignal = (s.hasFaqSection ? 1 : 0) + ((s.answerLikeBlocks || 0) >= 2 ? 1 : 0) + (((s.h2s || []).length + (s.h3s || []).length) >= 3 ? 1 : 0);
    var subheadingCount = (s.h2s || []).length + (s.h3s || []).length;
    var uniqueRatio = bodyTokens.length ? uniq(bodyTokens).length / bodyTokens.length : 0;
    var semanticBreadth = cap((uniqueRatio * 1.2) + (Math.min(subheadingCount, 6) / 20), 0, 1);
    var threshold = type === 'homepage' ? 150 : (CONFIG.thresholds[type] || CONFIG.thresholds.page);
    var depth = cap(((s.visibleWordCount || 0) / Math.max(threshold, 1)) * 0.55 + (Math.min(subheadingCount, 6) / 6) * 0.30 + (Math.min(followSignal, 3) / 3) * 0.15, 0, 1);
    var facts = Math.min((body.match(/\b\d+(?:[.,]\d+)?\b/g) || []).length, 8) + Math.min((body.match(/\b(?:19|20)\d{2}\b/g) || []).length, 3) + Math.min((body.match(/\b\d+(?:[.,]\d+)?%/g) || []).length, 3) + (s.hasDefinitionPattern ? 1 : 0);
    var primaryImage = (s.primaryImage && s.primaryImage.src) || '';
    var imageAlt = (s.primaryImage && s.primaryImage.alt) || '';
    var imageMatch = !!imageAlt && overlap(tok(imageAlt), topicTokens) >= 0.2;
    return {
      category: type,
      visibleWords: s.visibleWordCount || 0,
      threshold: threshold,
      canonical: canonState(s.url, s.canonical),
      robots: norm(s.metaRobots || ''),
      snippetRestricted: !!s.snippetRestricted || /nosnippet|max snippet 0|max-snippet 0/.test(norm(s.metaRobots || '')),
      directAnswer: !!topAnswer,
      topExtractable: !!topAnswer && (topAnswer.words || 0) <= 80,
      introWords: words(intro),
      topicIntro: topicIntro,
      titleH1: titleH1,
      topicConsistency: topicConsistency,
      entitySignal: entitySignal,
      subheadingCount: subheadingCount,
      scannableSignals: listSignal + tableSignal + faqSignal,
      followSignal: followSignal,
      semanticBreadth: semanticBreadth,
      depth: depth,
      chunkability: chunkability,
      bloatedRatio: bloatedRatio,
      longRatio: longRatio,
      vagueDensity: vagueDensity,
      hasClearHeading: (s.h1s || []).length > 0 || words(s.primaryHeading || '') >= 3,
      crawlableInternal: internal.length,
      relatedInternal: related.length,
      jsNavDominant: jsNavDominant,
      hasSchema: hasSchema,
      hasExpectedSchema: hasExpectedSchema,
      genericSchema: genericOnly,
      schemaMatch: schemaMatch,
      schemaMisleading: hasSchema && !genericOnly && schemaMatch < 0.2,
      structuredRelevant: hasSchema && hasExpectedSchema,
      primaryImage: primaryImage,
      imageMatch: imageMatch,
      imagesWithAlt: (s.images || []).filter(function (img) { return img && img.hasAlt; }).length,
      imageCount: (s.images || []).length,
      extCorroboration: ext.length,
      facts: facts,
      attributionStrong: !!s.hasAuthor && !!s.hasOrganization,
      attributionPartial: !!s.hasAuthor || !!s.hasOrganization || (s.schemaItems || []).some(function (it) { return it && (it.author || it.publisher); }),
      rendered: !!s.renderedTextAvailable,
      mainTextLength: String(s.mainText || s.bodyText || '').length,
      thinForIntent: (s.visibleWordCount || 0) < (threshold * 0.5)
    };
  }

  function evalEligibility(s, d, type) {
    var c = PILLAR_LABELS.eligibilityAccess;
    return [
      evalRule(type, { category: c, ruleId: 'indexability', label: 'Page is indexable', weight: 5 }, function () {
        if (/\bnoindex\b/.test(d.robots)) return { status: 'fail', details: 'Meta robots includes noindex.', recommendation: 'Remove noindex unless intentional.' };
        if (/\bnofollow\b|\bnone\b|\bnoarchive\b/.test(d.robots)) return { status: 'warning', details: 'Robots directives are restrictive.', recommendation: 'Review restrictive robots directives.' };
        return { status: 'pass', details: 'No blocking index directive detected.' };
      }),
      evalRule(type, { category: c, ruleId: 'snippet-eligibility', label: 'Snippet eligibility', weight: 5 }, function () {
        if (d.snippetRestricted) return { status: 'fail', details: 'Snippet output appears restricted.', recommendation: 'Remove snippet restrictions for extractability.' };
        if (/max-snippet\s*:\s*[1-4]?\d/.test(d.robots)) return { status: 'warning', details: 'Snippet length appears constrained.', recommendation: 'Increase allowed snippet length.' };
        return { status: 'pass', details: 'No snippet blocking signal detected.' };
      }),
      evalRule(type, { category: c, ruleId: 'canonical-consistency', label: 'Canonical consistency', weight: 4 }, function () {
        if (d.canonical === 'unrelated') return { status: 'fail', details: 'Canonical points to unrelated origin.', recommendation: 'Align canonical with equivalent URL.' };
        if (d.canonical === 'minor_mismatch') return { status: 'warning', details: 'Canonical path differs from current path.', recommendation: 'Verify canonical path intent.' };
        if (d.canonical === 'missing' || d.canonical === 'invalid') return { status: 'warning', details: 'Canonical is missing or invalid.', recommendation: 'Add a valid canonical tag.' };
        return { status: 'pass', details: 'Canonical appears coherent.' };
      }),
      evalRule(type, { category: c, ruleId: 'main-content-accessibility', label: 'Main content accessibility', weight: 4 }, function () {
        if (d.visibleWords < 35) return { status: 'fail', details: 'Almost no meaningful visible content.', recommendation: 'Expose meaningful visible body content.' };
        if (d.visibleWords < CONFIG.minVisibleWords) return { status: 'warning', details: 'Visible content is thin (' + d.visibleWords + ' words).', recommendation: 'Expand visible answer content.' };
        return { status: 'pass', details: 'Meaningful visible content detected.' };
      }),
      evalRule(type, { category: c, ruleId: 'crawlable-internal-paths', label: 'Crawlable internal paths', weight: 3 }, function () {
        if (d.jsNavDominant) return { status: 'fail', details: 'Core navigation appears JS-only.', recommendation: 'Use crawlable HTML anchor links in navigation and related blocks.' };
        if (d.crawlableInternal === 0) return { status: 'fail', details: 'No crawlable internal links detected.', recommendation: 'Add internal crawlable links.' };
        if (d.crawlableInternal < 4) return { status: 'warning', details: 'Limited crawlable internal links detected.', recommendation: 'Increase related internal linking.' };
        return { status: 'pass', details: 'Crawlable internal links are present.' };
      }),
      evalRule(type, { category: c, ruleId: 'rendering-availability', label: 'Rendering availability', weight: 4 }, function () {
        if (!d.rendered || d.mainTextLength < 80) return { status: 'fail', details: 'Rendered main text is missing or incomplete.', recommendation: 'Ensure main content is available in rendered DOM.' };
        if (d.mainTextLength < 300) return { status: 'warning', details: 'Rendered content appears partial.', recommendation: 'Improve post-render content completeness.' };
        return { status: 'pass', details: 'Main text is available after rendering.' };
      })
    ];
  }

  function evalAnswerability(s, d, type) {
    var c = PILLAR_LABELS.answerability;
    return [
      evalRule(type, { category: c, ruleId: 'direct-answer-near-top', label: 'Direct answer near top', weight: 5, appliesTo: ['post', 'page', 'product'] }, function () {
        if (d.directAnswer) return { status: 'pass', details: 'A concise answer-like block appears near the top.' };
        if (d.introWords >= 25) return { status: 'warning', details: 'Intro context exists but no clear answer block near top.', recommendation: 'Add a concise answer/definition block early in content.' };
        return { status: 'fail', details: 'No clear answer block near top.', recommendation: 'Place a direct answer paragraph at the top of content.' };
      }),
      evalRule(type, { category: c, ruleId: 'question-to-answer-match', label: 'Question-to-answer match', weight: 5 }, function () {
        if (d.topicIntro >= 0.55) return { status: 'pass', details: 'Opening content aligns with likely user intent.' };
        if (d.topicIntro >= 0.3) return { status: 'warning', details: 'Intent match is partial.', recommendation: 'Align intro copy directly with the main topic.' };
        return { status: 'fail', details: 'Opening content weakly matches likely intent.', recommendation: 'Rewrite opening blocks to resolve the headline query clearly.' };
      }),
      evalRule(type, { category: c, ruleId: 'structured-subanswers', label: 'Structured subanswers', weight: 4, appliesTo: ['post', 'page', 'category'] }, function () {
        if (d.subheadingCount >= 4) return { status: 'pass', details: 'Subtopics are clearly segmented.' };
        if (d.subheadingCount >= 2) return { status: 'warning', details: 'Some subtopic segmentation exists.', recommendation: 'Add more H2/H3 sections for subquestions.' };
        return { status: 'fail', details: 'Weak subtopic segmentation.', recommendation: 'Organize content by subquestions with clear headings.' };
      }),
      evalRule(type, { category: c, ruleId: 'scannable-formatting', label: 'Scannable formatting', weight: 3, appliesTo: ['post', 'page', 'category'] }, function () {
        if (d.scannableSignals >= 2) return { status: 'pass', details: 'Page uses scan-friendly structures (lists/tables/FAQ).' };
        if (d.scannableSignals === 1) return { status: 'warning', details: 'Minimal scan-friendly formatting detected.', recommendation: 'Use more lists, tables, or FAQ/step blocks.' };
        return { status: 'fail', details: 'No scan-friendly formatting detected.', recommendation: 'Add scan-friendly answer structures.' };
      }),
      evalRule(type, { category: c, ruleId: 'early-context-framing', label: 'Early context framing', weight: 3 }, function () {
        if (d.introWords >= 30) return { status: 'pass', details: 'Page establishes context early.' };
        if (d.introWords >= 15) return { status: 'warning', details: 'Intro framing is present but weak.', recommendation: 'Clarify scope and outcome in the opening paragraph.' };
        return { status: 'fail', details: 'Opening context framing is missing.', recommendation: 'Add an explicit intro framing paragraph.' };
      }),
      evalRule(type, { category: c, ruleId: 'low-ambiguity-writing', label: 'Low ambiguity writing', weight: 3 }, function () {
        if (d.vagueDensity <= 0.008 && d.longRatio <= 0.28) return { status: 'pass', details: 'Writing is clear and concrete.' };
        if (d.vagueDensity <= 0.018 && d.longRatio <= 0.4) return { status: 'warning', details: 'Writing clarity is mixed.', recommendation: 'Reduce abstract wording and long sentences.' };
        return { status: 'fail', details: 'Writing appears vague and hard to parse quickly.', recommendation: 'Rewrite key sections with concrete, shorter statements.' };
      }),
      evalRule(type, { category: c, ruleId: 'answer-completeness', label: 'Answer completeness', weight: 2, appliesTo: ['post', 'page', 'product'] }, function () {
        if (d.visibleWords >= d.threshold) return { status: 'pass', details: 'Content depth is sufficient for intent.' };
        if (d.visibleWords >= d.threshold * 0.6) return { status: 'warning', details: 'Content partially answers intent but lacks depth.', recommendation: 'Expand coverage beyond teaser-level text.' };
        return { status: 'fail', details: 'Content is too thin for likely intent.', recommendation: 'Add substantial answer detail for core intent.' };
      })
    ];
  }

  function evalSemantic(s, d, type) {
    var c = PILLAR_LABELS.semanticClarity;
    return [
      evalRule(type, { category: c, ruleId: 'title-h1-alignment', label: 'Title/H1 alignment', weight: 4 }, function () {
        if (!s.title && !(s.h1s || []).length) return { status: 'fail', details: 'Title and H1 are both missing.', recommendation: 'Add clear title and primary heading.' };
        if (!s.title || !(s.h1s || []).length) return { status: 'warning', details: 'Title or H1 is missing.', recommendation: 'Keep title and H1 present and aligned.' };
        if (d.titleH1 >= 0.55) return { status: 'pass', details: 'Title and H1 are strongly aligned.' };
        if (d.titleH1 >= 0.3) return { status: 'warning', details: 'Title and H1 are partially aligned.', recommendation: 'Align title and H1 around one primary topic phrase.' };
        return { status: 'fail', details: 'Title and H1 are mismatched.', recommendation: 'Rework title and H1 to describe the same topic.' };
      }),
      evalRule(type, { category: c, ruleId: 'primary-topic-consistency', label: 'Primary topic consistency', weight: 4 }, function () {
        if (d.topicConsistency >= 0.55) return { status: 'pass', details: 'Primary topic is consistent across key sections.' };
        if (d.topicConsistency >= 0.32) return { status: 'warning', details: 'Topic focus is somewhat mixed.', recommendation: 'Reduce topic drift and reinforce one main focus.' };
        return { status: 'fail', details: 'Topic focus appears scattered.', recommendation: 'Refocus page around one primary topic.' };
      }),
      evalRule(type, { category: c, ruleId: 'main-entity-clarity', label: 'Main entity clarity', weight: 4 }, function () {
        if (d.entitySignal >= 0.6) return { status: 'pass', details: 'Main entity/topic is explicit.' };
        if (d.entitySignal >= 0.35) return { status: 'warning', details: 'Main entity is partially clear.', recommendation: 'Name the main entity explicitly in H1 and intro.' };
        return { status: 'fail', details: 'Main entity is unclear.', recommendation: 'Clarify who/what the page is about.' };
      }),
      evalRule(type, { category: c, ruleId: 'structured-data-relevance', label: 'Structured data relevance', weight: 4 }, function () {
        var critical = type === 'post' || type === 'product' || type === 'profile';
        if (!d.hasSchema) return { status: critical ? 'fail' : 'warning', details: critical ? 'No structured data detected for a critical page type.' : 'No structured data detected.', recommendation: 'Add specific structured data aligned with visible content.' };
        if (d.schemaMisleading) return { status: 'fail', details: 'Structured data appears mismatched with visible focus.', recommendation: 'Align schema fields and types to visible page focus.' };
        if (!d.structuredRelevant) return { status: 'warning', details: 'Structured data exists but relevance is weak.', recommendation: 'Use the most specific schema type for this page.' };
        if (d.genericSchema) return { status: 'warning', details: 'Schema is mostly generic.', recommendation: 'Use specific schema beyond generic WebPage/Thing.' };
        return { status: 'pass', details: 'Structured data is relevant to page focus.' };
      }),
      evalRule(type, { category: c, ruleId: 'visible-to-markup-match', label: 'Visible-to-markup match', weight: 4 }, function () {
        if (!d.hasSchema) return { status: 'warning', details: 'No schema available for visible-content matching.', recommendation: 'Add schema and keep it consistent with visible copy.' };
        if (d.schemaMatch >= 0.55) return { status: 'pass', details: 'Schema fields match visible content well.' };
        if (d.schemaMatch >= 0.3) return { status: 'warning', details: 'Partial mismatch between schema and visible content.', recommendation: 'Update schema fields to mirror visible headings and intro.' };
        return { status: 'fail', details: 'Clear mismatch between schema and visible content.', recommendation: 'Rewrite schema to truthfully represent visible content.' };
      }),
      evalRule(type, { category: c, ruleId: 'primary-image-context', label: 'Primary image context', weight: 2 }, function () {
        if (!d.primaryImage) return { status: 'fail', details: 'No clear primary image signal detected.', recommendation: 'Provide a relevant primary image signal.' };
        if (d.imageMatch || d.imagesWithAlt >= 1) return { status: 'pass', details: 'Primary image supports topic context.' };
        return { status: 'warning', details: 'Primary image exists but context signal is weak.', recommendation: 'Improve image alt/caption context.' };
      }),
      evalRule(type, { category: c, ruleId: 'author-organization-signals', label: 'Author / organization signals', weight: 2, appliesTo: ['post', 'page', 'profile'] }, function () {
        if (d.attributionStrong) return { status: 'pass', details: 'Author and organization signals are clear.' };
        if (d.attributionPartial) return { status: 'warning', details: 'Partial attribution signals found.', recommendation: 'Strengthen byline and publisher signals.' };
        return { status: 'fail', details: 'Source attribution signals are missing.', recommendation: 'Add author and publisher identity signals.' };
      })
    ];
  }

  function evalCitation(s, d, type) {
    var c = PILLAR_LABELS.citationExtractionReadiness;
    return [
      evalRule(type, { category: c, ruleId: 'paragraph-chunkability', label: 'Paragraph chunkability', weight: 4 }, function () {
        if (d.chunkability >= 0.55 && d.bloatedRatio <= 0.25) return { status: 'pass', details: 'Paragraphs are mostly self-contained.' };
        if (d.chunkability >= 0.3) return { status: 'warning', details: 'Paragraph chunk quality is mixed.', recommendation: 'Split long blocks into concise answer chunks.' };
        return { status: 'fail', details: 'Paragraphs are not extraction-friendly.', recommendation: 'Rewrite into shorter stand-alone paragraphs.' };
      }),
      evalRule(type, { category: c, ruleId: 'fact-specificity', label: 'Fact specificity', weight: 3 }, function () {
        if (d.facts >= 6) return { status: 'pass', details: 'Content contains concrete factual signals.' };
        if (d.facts >= 3) return { status: 'warning', details: 'Some factual specificity exists.', recommendation: 'Add numbers, dates, attributes, and concrete examples.' };
        return { status: 'fail', details: 'Content is mostly generic with low factual detail.', recommendation: 'Increase factual specificity in core answer sections.' };
      }),
      evalRule(type, { category: c, ruleId: 'source-attribution-signals', label: 'Source attribution signals', weight: 3, appliesTo: ['post', 'page', 'profile'] }, function () {
        if (d.attributionStrong) return { status: 'pass', details: 'Source attribution is strong.' };
        if (d.attributionPartial) return { status: 'warning', details: 'Attribution is partial.', recommendation: 'Expose both author and publisher clearly.' };
        return { status: 'fail', details: 'Attribution is missing.', recommendation: 'Add visible source attribution signals.' };
      }),
      evalRule(type, { category: c, ruleId: 'primary-answer-extractability', label: 'Primary answer extractability', weight: 3, appliesTo: ['post', 'page'] }, function () {
        if (d.topExtractable) return { status: 'pass', details: 'Top answer block is cleanly extractable.' };
        if (words(s.firstParagraph || '') >= 15) return { status: 'warning', details: 'Opening paragraph exists but is not strongly extractable.', recommendation: 'Rewrite opening answer into a concise standalone block.' };
        return { status: 'fail', details: 'No extractable primary answer block found.', recommendation: 'Add a concise answer summary directly below the heading.' };
      }),
      evalRule(type, { category: c, ruleId: 'supporting-media-clarity', label: 'Supporting media clarity', weight: 2 }, function () {
        if (d.primaryImage && (d.imageMatch || d.imagesWithAlt >= 1)) return { status: 'pass', details: 'Media supports topical understanding.' };
        if (d.imageCount > 0) return { status: 'warning', details: 'Media exists but support clarity is weak.', recommendation: 'Improve media context (alt/captions).' };
        return { status: 'fail', details: 'No meaningful supporting media detected.', recommendation: 'Add relevant supporting media where useful.' };
      }),
      evalRule(type, { category: c, ruleId: 'external-corroboration', label: 'External corroboration', weight: 3, appliesTo: ['post', 'page'] }, function () {
        if (d.extCorroboration >= 2) return { status: 'pass', details: 'Corroborative external references are present.' };
        if (d.extCorroboration === 1) return { status: 'warning', details: 'Only one corroborative reference detected.', recommendation: 'Add additional credible external references.' };
        return { status: 'fail', details: 'No corroborative references detected where expected.', recommendation: 'Link to credible external sources for key claims.' };
      })
    ];
  }

  function evalCoverage(s, d, type) {
    var c = PILLAR_LABELS.multiQueryCoverage;
    return [
      evalRule(type, { category: c, ruleId: 'related-subtopic-coverage', label: 'Related subtopic coverage', weight: 4, appliesTo: ['post', 'page', 'category'] }, function () {
        if (d.subheadingCount >= 5) return { status: 'pass', details: 'Page covers multiple adjacent subtopics.' };
        if (d.subheadingCount >= 2) return { status: 'warning', details: 'Subtopic breadth is limited.', recommendation: 'Add adjacent subtopic sections likely to be asked next.' };
        return { status: 'fail', details: 'Coverage is too narrow.', recommendation: 'Expand coverage beyond one thin angle.' };
      }),
      evalRule(type, { category: c, ruleId: 'follow-up-readiness', label: 'Follow-up readiness', weight: 4, appliesTo: ['post', 'page', 'product'] }, function () {
        if (d.followSignal >= 2) return { status: 'pass', details: 'Page supports likely follow-up questions.' };
        if (d.followSignal === 1) return { status: 'warning', details: 'Some follow-up support exists.', recommendation: 'Add FAQ or next-question sections.' };
        return { status: 'fail', details: 'Follow-up support is weak.', recommendation: 'Create sections that naturally answer next-step questions.' };
      }),
      evalRule(type, { category: c, ruleId: 'internal-support-cluster', label: 'Internal support cluster', weight: 4, appliesTo: ['post', 'page', 'category'] }, function () {
        if (d.relatedInternal >= 4) return { status: 'pass', details: 'Related internal support cluster is strong.' };
        if (d.relatedInternal >= 1) return { status: 'warning', details: 'Some related internal links are present.', recommendation: 'Expand related internal linking around the topic.' };
        return { status: 'fail', details: 'Page appears isolated from related internal content.', recommendation: 'Link to supporting internal pages and back-link this page.' };
      }),
      evalRule(type, { category: c, ruleId: 'synonym-entity-breadth', label: 'Synonym / entity breadth', weight: 3, appliesTo: ['post', 'page', 'product'] }, function () {
        if (d.semanticBreadth >= 0.45) return { status: 'pass', details: 'Language includes useful semantic variety.' };
        if (d.semanticBreadth >= 0.3) return { status: 'warning', details: 'Semantic breadth is limited.', recommendation: 'Add related terminology and entity variation.' };
        return { status: 'fail', details: 'Language is narrow and repetitive.', recommendation: 'Broaden terminology without topic drift.' };
      }),
      evalRule(type, { category: c, ruleId: 'topic-expansion-depth', label: 'Topic expansion depth', weight: 2 }, function () {
        if (d.depth >= 0.65) return { status: 'pass', details: 'Content expands beyond headline query.' };
        if (d.depth >= 0.4) return { status: 'warning', details: 'Depth is baseline but limited.', recommendation: 'Expand depth to cover adjacent intent.' };
        return { status: 'fail', details: 'Depth underdelivers vs. expected intent.', recommendation: 'Increase topic depth and supporting sections.' };
      })
    ];
  }

  function pillarScore(list) {
    var w = 0, s = 0;
    (list || []).forEach(function (r) {
      if (r.status === 'not_applicable') return;
      w += r.weight;
      s += (RULE_VALUES[r.status] || 0) * r.weight;
    });
    if (!w) return { raw: 1, score: 100 };
    var raw = s / w;
    return { raw: raw, score: round(raw * 100, 0) };
  }

  function penalties(base, s, d) {
    var score = base;
    var issues = [];
    function add(id, severity, message, value) {
      score -= value;
      issues.push({ id: id, severity: severity, message: message, penalty: value });
    }
    if (/\bnoindex\b/.test(d.robots)) add('meta-robots-noindex', 'high', 'Meta robots contains noindex, blocking index eligibility.', 40);
    if ((s.visibleWordCount || 0) < 35) add('no-meaningful-visible-content', 'high', 'Rendered page has no meaningful visible content.', 15);
    if (!d.hasClearHeading) add('missing-primary-heading', 'high', 'Page lacks a clear primary heading or equivalent title.', 10);
    if (d.canonical === 'unrelated') add('canonical-unrelated-url', 'high', 'Canonical points to an unrelated URL.', 10);
    if (d.thinForIntent) add('content-too-thin-intent', 'medium', 'Visible content is too thin for likely intent.', 10);
    if (d.schemaMisleading) add('structured-data-mismatch', 'medium', 'Structured data appears mismatched to visible focus.', 8);
    if (d.snippetRestricted) add('snippet-restricted', 'medium', 'Snippet restrictions may impair answer extraction.', 8);
    return { score: round(cap(score, 0, 100), 0), issues: issues };
  }

  function recommend(report) {
    var out = [];
    var seen = {};
    function add(t) {
      var text = String(t || '').trim();
      var k = norm(text);
      if (!text || !k || seen[k]) return;
      seen[k] = true;
      out.push(text);
    }
    report.criticalIssues.forEach(function (i) {
      if (i.id === 'meta-robots-noindex') add('Remove noindex from robots directives unless intentional.');
      if (i.id === 'no-meaningful-visible-content') add('Expose meaningful visible content in the rendered DOM.');
      if (i.id === 'missing-primary-heading') add('Add one clear top-level heading aligned with page focus.');
      if (i.id === 'canonical-unrelated-url') add('Align canonical with the equivalent preferred URL.');
      if (i.id === 'content-too-thin-intent') add('Expand body content depth to satisfy likely intent.');
      if (i.id === 'structured-data-mismatch') add('Align structured data with visible content and topic.');
      if (i.id === 'snippet-restricted') add('Remove restrictive snippet directives where possible.');
    });
    var fixes = report.checks.failed.concat(report.checks.warnings);
    fixes.sort(function (a, b) { return b.weight - a.weight; });
    fixes.forEach(function (r) { if (r.recommendation) add(r.recommendation); });
    return out.slice(0, 10);
  }

  function buildReport(signals) {
    var type = pageType(signals);
    var detectedIntent = intent(type);
    var detectedTopic = inferTopic(signals);
    var d = derive(signals, type, detectedTopic);

    var rules = {
      eligibilityAccess: evalEligibility(signals, d, type),
      answerability: evalAnswerability(signals, d, type),
      semanticClarity: evalSemantic(signals, d, type),
      citationExtractionReadiness: evalCitation(signals, d, type),
      multiQueryCoverage: evalCoverage(signals, d, type)
    };

    var rawScores = {};
    var pillarScores = {};
    Object.keys(rules).forEach(function (k) {
      var scoreObj = pillarScore(rules[k]);
      rawScores[k] = scoreObj.raw;
      pillarScores[k] = scoreObj.score;
    });

    var base = 0;
    Object.keys(PILLAR_WEIGHTS).forEach(function (k) { base += (rawScores[k] || 0) * PILLAR_WEIGHTS[k]; });
    base = round(cap(base, 0, 100), 0);

    var pen = penalties(base, signals, d);

    var all = [].concat(rules.eligibilityAccess, rules.answerability, rules.semanticClarity, rules.citationExtractionReadiness, rules.multiQueryCoverage);
    var failed = all.filter(function (r) { return r.status === 'fail'; }).sort(function (a, b) { return b.weight - a.weight; });
    var warnings = all.filter(function (r) { return r.status === 'warning'; }).sort(function (a, b) { return b.weight - a.weight; });
    var passed = all.filter(function (r) { return r.status === 'pass'; });
    var notApplicable = all.filter(function (r) { return r.status === 'not_applicable'; });

    var report = {
      url: signals.url,
      pageType: type,
      detectedIntent: detectedIntent,
      detectedTopic: detectedTopic,
      score: pen.score,
      grade: grade(pen.score),
      pillarScores: pillarScores,
      criticalIssues: pen.issues.map(function (i) { return { id: i.id, severity: i.severity, message: i.message }; }),
      checks: { failed: failed, warnings: warnings, passed: passed, notApplicable: notApplicable },
      prioritizedRecommendations: []
    };
    report.prioritizedRecommendations = recommend(report);
    return report;
  }

  function renderGauge(score) {
    var svg = document.getElementById('aeo-gauge-svg');
    if (!svg) return;
    var r = 40;
    var c = 2 * Math.PI * r;
    var d = c * (score / 100);
    var g = c - d;
    var color = scoreColor(score);
    svg.innerHTML =
      '<circle cx="50" cy="50" r="' + r + '" fill="none" stroke="#e5e7eb" stroke-width="8"></circle>' +
      '<circle cx="50" cy="50" r="' + r + '" fill="none" stroke="' + color + '" stroke-width="8" stroke-linecap="round" stroke-dasharray="' + d.toFixed(2) + ' ' + g.toFixed(2) + '" transform="rotate(-90 50 50)"></circle>';
    var n = document.getElementById('aeo-score-num');
    if (n) { n.textContent = score; n.style.color = color; }
  }

  function renderPillars(pillarScores) {
    var box = document.getElementById('aeo-pillar-bars');
    if (!box) return;
    box.innerHTML = '';
    Object.keys(PILLAR_LABELS).forEach(function (k) {
      var score = pillarScores[k] || 0;
      var color = scoreColor(score);
      var row = document.createElement('div');
      row.className = 'aeo-pillar-row';
      row.innerHTML =
        '<div class="aeo-pillar-name">' + esc(PILLAR_LABELS[k]) + '</div>' +
        '<div class="aeo-pillar-track"><div class="aeo-pillar-fill" style="width:' + score + '%;background:' + color + ';"></div></div>' +
        '<div class="aeo-pillar-num" style="color:' + color + ';">' + score + '</div>';
      box.appendChild(row);
    });
  }

  function renderCheck(rule) {
    var node = document.createElement('div');
    node.className = 'aeo-check-item';
    node.innerHTML =
      '<div class="aeo-check-dot ' + rule.status + '"></div>' +
      '<div class="aeo-check-body">' +
      '<div class="aeo-check-head"><span class="aeo-check-cat">' + esc(rule.category) + '</span><span class="aeo-check-label">' + esc(rule.label) + '</span></div>' +
      '<div class="aeo-check-details">' + esc(rule.details) + '</div>' +
      '</div>';
    return node;
  }

  function renderList(id, list) {
    var box = document.getElementById(id);
    if (!box) return;
    box.innerHTML = '';
    if (!list || !list.length) {
      var empty = document.createElement('div');
      empty.className = 'aeo-empty';
      empty.textContent = 'None.';
      box.appendChild(empty);
      return;
    }
    list.forEach(function (item) { box.appendChild(renderCheck(item)); });
  }

  function renderPassed(passed) {
    var box = document.getElementById('aeo-pass-list');
    if (!box) return;
    box.innerHTML = '';
    if (!passed || !passed.length) {
      var empty = document.createElement('div');
      empty.className = 'aeo-empty';
      empty.textContent = 'No passed checks.';
      box.appendChild(empty);
      return;
    }
    var groups = {};
    passed.forEach(function (p) {
      if (!groups[p.category]) groups[p.category] = [];
      groups[p.category].push(p);
    });
    Object.keys(groups).forEach(function (cat) {
      var group = document.createElement('div');
      group.className = 'aeo-pass-group';
      var title = document.createElement('div');
      title.className = 'aeo-pass-title';
      title.textContent = cat;
      group.appendChild(title);
      groups[cat].forEach(function (it) { group.appendChild(renderCheck(it)); });
      box.appendChild(group);
    });
  }

  function renderCritical(list) {
    var section = document.getElementById('aeo-critical');
    var box = document.getElementById('aeo-critical-list');
    var count = document.getElementById('aeo-critical-count');
    if (!section || !box) return;
    if (!list || !list.length) {
      section.style.display = 'none';
      return;
    }
    section.style.display = 'block';
    if (count) count.textContent = '(' + list.length + ')';
    box.innerHTML = '';
    list.forEach(function (issue) {
      var node = document.createElement('div');
      node.className = 'aeo-critical-item';
      node.innerHTML = '<div class="aeo-critical-title">' + esc(issue.id) + '</div><div class="aeo-critical-desc">' + esc(issue.message) + '</div>';
      box.appendChild(node);
    });
  }

  function renderRecommendations(list) {
    var box = document.getElementById('aeo-rec-list');
    if (!box) return;
    box.innerHTML = '';
    if (!list || !list.length) {
      var empty = document.createElement('div');
      empty.className = 'aeo-empty';
      empty.textContent = 'No priority recommendations.';
      box.appendChild(empty);
      return;
    }
    list.forEach(function (text, i) {
      var li = document.createElement('li');
      li.className = 'aeo-rec-item';
      li.innerHTML = '<div class="aeo-rec-num">' + (i + 1) + '</div><div>' + esc(text) + '</div>';
      box.appendChild(li);
    });
  }

  function bindSections() {
    document.querySelectorAll('.aeo-toggle-head').forEach(function (head) {
      head.addEventListener('click', function () {
        var section = head.closest('.aeo-section');
        if (!section) return;
        var collapsed = section.classList.toggle('aeo-collapsed');
        var btn = head.querySelector('.aeo-section-toggle');
        if (btn) btn.innerHTML = collapsed ? '&#9660;' : '&#9650;';
      });
    });
  }

  function bindReload() {
    var b = document.getElementById('aeo-reload');
    if (!b) return;
    b.addEventListener('click', function () { window.location.reload(); });
  }

  function bindSave(report) {
    var b = document.getElementById('aeo-save');
    if (!b) return;
    b.addEventListener('click', function () {
      var html = '<!DOCTYPE html>\n' + document.documentElement.outerHTML;
      var blob = new Blob([html], { type: 'text/html' });
      var a = document.createElement('a');
      var host = '';
      try { host = new URL(report.url).hostname.replace(/^www\./, '').replace(/[^a-zA-Z0-9.-]/g, '_'); } catch (e) {}
      a.download = 'aeo_report_' + (host || 'page') + '.html';
      a.href = URL.createObjectURL(blob);
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(a.href);
    });
  }

  function exportRule(r) {
    return { category: r.category, ruleId: r.ruleId, label: r.label, status: r.status, scoreContribution: r.scoreContribution, weight: r.weight, details: r.details };
  }

  function buildExport(report, signals) {
    return {
      url: report.url,
      pageType: report.pageType,
      detectedIntent: report.detectedIntent,
      detectedTopic: report.detectedTopic,
      score: report.score,
      grade: report.grade,
      pillarScores: report.pillarScores,
      criticalIssues: report.criticalIssues,
      checks: {
        failed: report.checks.failed.map(exportRule),
        warnings: report.checks.warnings.map(exportRule),
        passed: report.checks.passed.map(exportRule),
        notApplicable: report.checks.notApplicable.map(exportRule)
      },
      prioritizedRecommendations: report.prioritizedRecommendations,
      capturedAt: signals.capturedAt || null
    };
  }

  function bindCopyJson(report, signals) {
    var b = document.getElementById('aeo-copy-json');
    if (!b) return;
    b.addEventListener('click', function () {
      var text = JSON.stringify(buildExport(report, signals), null, 2);
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () {
          b.textContent = 'Copied!';
          setTimeout(function () { b.textContent = 'Copy JSON'; }, 1800);
        });
      } else {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); } catch (e) {}
        ta.remove();
        b.textContent = 'Copied!';
        setTimeout(function () { b.textContent = 'Copy JSON'; }, 1800);
      }
    });
  }

  function render(report, signals) {
    var loading = document.getElementById('aeo-loading');
    var root = document.getElementById('aeo-root');
    if (loading) loading.style.display = 'none';
    if (root) root.style.display = 'block';
    document.title = 'AEO - ' + report.url;

    var urlEl = document.getElementById('aeo-url');
    if (urlEl) { urlEl.textContent = report.url; urlEl.setAttribute('href', report.url); }
    var timeEl = document.getElementById('aeo-gen-time');
    if (timeEl) timeEl.textContent = 'Generated: ' + new Date().toUTCString();

    renderGauge(report.score);
    renderPillars(report.pillarScores);
    renderCritical(report.criticalIssues);
    renderList('aeo-fail-list', report.checks.failed);
    renderList('aeo-warn-list', report.checks.warnings);
    renderRecommendations(report.prioritizedRecommendations);
    renderPassed(report.checks.passed);

    var gradeEl = document.getElementById('aeo-grade');
    var badgeEl = document.getElementById('aeo-grade-badge');
    if (gradeEl) gradeEl.textContent = report.grade;
    if (badgeEl) { badgeEl.textContent = report.score + ' / 100'; badgeEl.style.background = scoreColor(report.score); }
    var pageTypeEl = document.getElementById('aeo-page-type');
    if (pageTypeEl) pageTypeEl.textContent = { post: 'Post / Article', page: 'Page / Landing Page', product: 'Product Page', category: 'Category / Archive', homepage: 'Homepage', profile: 'Profile / Author / Creator' }[report.pageType] || report.pageType;
    var intentEl = document.getElementById('aeo-intent');
    if (intentEl) intentEl.textContent = report.detectedIntent;
    var topicEl = document.getElementById('aeo-topic');
    if (topicEl) topicEl.textContent = report.detectedTopic;

    var failChip = document.getElementById('aeo-fail-chip');
    var warnChip = document.getElementById('aeo-warn-chip');
    var passChip = document.getElementById('aeo-pass-chip');
    if (failChip) failChip.textContent = report.checks.failed.length + ' failures';
    if (warnChip) warnChip.textContent = report.checks.warnings.length + ' warnings';
    if (passChip) passChip.textContent = report.checks.passed.length + ' passed';

    var failCount = document.getElementById('aeo-fail-count');
    var warnCount = document.getElementById('aeo-warn-count');
    var passCount = document.getElementById('aeo-pass-count');
    if (failCount) failCount.textContent = '(' + report.checks.failed.length + ')';
    if (warnCount) warnCount.textContent = '(' + report.checks.warnings.length + ')';
    if (passCount) passCount.textContent = '(' + report.checks.passed.length + ')';

    bindSections();
    bindReload();
    bindSave(report);
    bindCopyJson(report, signals);
  }

  function run() {
    setStatus('Loading captured AEO data...');
    chrome.storage.local.get(['dd_aeo_data'], function (res) {
      var signals = res && res.dd_aeo_data;
      if (!signals) {
        failPage('No AEO data found. Run AEO Analysis from popup and try again.');
        return;
      }
      try { chrome.storage.local.remove(['dd_aeo_data']); } catch (e) {}
      setStatus('Building report...');
      var report = buildReport(signals);
      render(report, signals);
    });
  }

  document.addEventListener('DOMContentLoaded', run);
})();
