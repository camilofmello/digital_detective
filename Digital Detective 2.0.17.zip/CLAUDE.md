# CLAUDE.md - Digital Detective v2.0.17

## PermissÃƒÆ’Ã‚Âµes de OperaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o

VocÃƒÆ’Ã‚Âª tem **100% de permissÃƒÆ’Ã‚Â£o** para realizar qualquer operaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o dentro desta pasta sem pedir autorizaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o:

- Ler qualquer arquivo
- Criar novos arquivos
- Editar arquivos existentes
- Sobrescrever arquivos
- Apagar arquivos
- Renomear ou mover arquivos

Nunca peÃƒÆ’Ã‚Â§a confirmaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o para operaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes de leitura, escrita, ediÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o ou exclusÃƒÆ’Ã‚Â£o dentro deste diretÃƒÆ’Ã‚Â³rio.

---

## Protocolo ObrigatÃƒÆ’Ã‚Â³rio de InÃƒÆ’Ã‚Â­cio de Tarefa

**Antes de qualquer implementaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o, sempre:**

1. Ler `function_index.md` para mapear interdependÃƒÆ’Ã‚Âªncias, localizar as funÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes afetadas e entender o impacto da mudanÃƒÆ’Ã‚Â§a em toda a arquitetura.
2. Identificar os arquivos que serÃƒÆ’Ã‚Â£o alterados e quais funÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes existentes podem ser reutilizadas.
3. Confirmar o entendimento antes de gerar cÃƒÆ’Ã‚Â³digo, se houver ambiguidade.

---

## PrincÃƒÆ’Ã‚Â­pios de Qualidade de CÃƒÆ’Ã‚Â³digo

### Modularidade
- Cada funcionalidade deve ser isolada em seu prÃƒÆ’Ã‚Â³prio mÃƒÆ’Ã‚Â³dulo (arquivo `.html` + `.js` dedicado).
- Novas ferramentas nunca devem embutir lÃƒÆ’Ã‚Â³gica dentro de `popup.js` alÃƒÆ’Ã‚Â©m do mÃƒÆ’Ã‚Â­nimo necessÃƒÆ’Ã‚Â¡rio (validaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o de input + abertura de aba).
- LÃƒÆ’Ã‚Â³gica de anÃƒÆ’Ã‚Â¡lise, scoring e renderizaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o de relatÃƒÆ’Ã‚Â³rio fica exclusivamente no arquivo da ferramenta.

### Isolamento de MÃƒÆ’Ã‚Â³dulos
- MÃƒÆ’Ã‚Â³dulos de relatÃƒÆ’Ã‚Â³rio (ex: `script_match.js`, `seo_report.js`) nÃƒÆ’Ã‚Â£o dependem uns dos outros.
- UtilitÃƒÆ’Ã‚Â¡rios compartilhados ficam exclusivamente em `report_utils.js`.
- ComunicaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o entre mÃƒÆ’Ã‚Â³dulos ocorre apenas via `chrome.runtime.sendMessage` com aÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes nomeadas (`msg.action`).

### OtimizaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o de FunÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes
- Antes de criar uma nova funÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o, verificar se jÃƒÆ’Ã‚Â¡ existe uma equivalente em `report_utils.js`, `content.js` ou no mÃƒÆ’Ã‚Â³dulo alvo.
- FunÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes genÃƒÆ’Ã‚Â©ricas reutilizÃƒÆ’Ã‚Â¡veis (helpers, formatadores, escape HTML) devem estar em `report_utils.js`.
- Evitar duplicaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o de lÃƒÆ’Ã‚Â³gica entre mÃƒÆ’Ã‚Â³dulos.

### Retrocompatibilidade
- FunÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes existentes nÃƒÆ’Ã‚Â£o sÃƒÆ’Ã‚Â£o alteradas em sua assinatura sem necessidade explÃƒÆ’Ã‚Â­cita.
- Novas aÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes de mensagem (`msg.action`) sÃƒÆ’Ã‚Â£o sempre adicionadas, nunca renomeadas.
- O contrato `popup.js ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬Â content.js ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬Â background.js` deve permanecer estÃƒÆ’Ã‚Â¡vel.
- Nada ÃƒÆ’Ã‚Â© removido sem instruÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o explÃƒÆ’Ã‚Â­cita do usuÃƒÆ’Ã‚Â¡rio.

---

## Regras de Desenvolvimento

1. Arquivos sempre entregues **completos** ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â nunca trechos, nunca parciais.
2. Retrocompatibilidade ÃƒÆ’Ã‚Â© obrigatÃƒÆ’Ã‚Â³ria ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â nada ÃƒÆ’Ã‚Â© removido sem instruÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o explÃƒÆ’Ã‚Â­cita.
3. FunÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes nÃƒÆ’Ã‚Â£o relacionadas ÃƒÆ’Ã‚Â  alteraÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o permanecem **intactas**.
4. Em caso de erro, inserir `console.log` nos pontos-chave antes de tentar nova soluÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o.
5. SoluÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o mais simples e direta ÃƒÆ’Ã‚Â© sempre preferÃƒÆ’Ã‚Â­vel.
6. VersÃƒÆ’Ã‚Â£o atual: **v2.0.17** ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â formato obrigatÃƒÆ’Ã‚Â³rio: `major.minor.patch` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â footer padrÃƒÆ’Ã‚Â£o: `Digital Detective v2.0.17 Ãƒâ€šÃ‚Â· Developed by Camilo Mello`

---

## Regra Global de Encoding UTF-8 (OBRIGATORIA - nunca ignorar)

NUNCA usar caracteres nao-ASCII diretamente em arquivos HTML.
Sempre usar HTML entities para qualquer caracter especial no source code.

**Substituicoes obrigatorias em HTML:**
- em-dash -> `&mdash;`
- en-dash -> `&ndash;`
- reticencias -> `&hellip;`
- ponto central -> `&middot;`
- espaco fixo -> `&nbsp;`

**Regras estruturais:**
1. `<meta charset="UTF-8" />` deve ser o **PRIMEIRO elemento** dentro de `<head>` (antes do title, viewport, tudo)
2. Comentarios CSS e JS devem usar somente ASCII: `/* -- Header -- */` NUNCA `/* -- Header -- */` com chars especiais
3. O arquivo `.editorconfig` desta pasta enforce `charset = utf-8` + `end_of_line = lf`
4. Para reparar arquivos corrompidos: executar `fix_encoding.ps1` na raiz do projeto (faz replace global de todos os HTMLs)

**Como identificar corrupcao:** caracteres como `a-circunflexo + euro + aspas` = em-dash corrompido.
Cada vez que uma pagina exibe `ÃƒÂ¢Ã¢â€šÂ¬"` onde deveria aparecer um traco, o arquivo tem bytes UTF-8 double-encoded.

---

## Protocolo ObrigatÃƒÆ’Ã‚Â³rio de Encerramento de Tarefa

**ApÃƒÆ’Ã‚Â³s toda implementaÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o concluÃƒÆ’Ã‚Â­da, sempre:**

1. Atualizar `function_index.md` para refletir:
   - Novas funÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes adicionadas (nome + linha atual no arquivo).
   - FunÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes alteradas (novo nÃƒÆ’Ã‚Âºmero de linha se moveu).
   - Novos arquivos criados (adicionÃƒÆ’Ã‚Â¡-los ÃƒÆ’Ã‚Â  estrutura e ÃƒÆ’Ã‚Â s seÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes correspondentes).
   - Atualizar estatÃƒÆ’Ã‚Â­sticas (total de funÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes, linhas, arquivos).
2. Atualizar a seÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o `ÃƒÂ¢Ã…Â¡Ã‚Â ÃƒÂ¯Ã‚Â¸Ã‚Â NOTAS TÃƒÆ’Ã¢â‚¬Â°CNICAS IMPORTANTES` se houver algo novo a registrar.
3. Atualizar o campo `**VersÃƒÆ’Ã‚Â£o do ÃƒÆ’Ã‚Â­ndice**` e `**Data**` no rodapÃƒÆ’Ã‚Â© do `function_index.md`.

---

## Projeto

**Digital Detective v2.0.17** ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â Chrome Extension (MV3) para inspeÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o, diagnÃƒÆ’Ã‚Â³stico e anÃƒÆ’Ã‚Â¡lise de pÃƒÆ’Ã‚Â¡ginas web.

### Ferramentas do plugin
1. Color Picker
2. Screenshot
3. Element Picker
4. DS Extractor
5. Component Blueprinter
6. Match Analysis
7. Lighthouse Audit
8. SEO Analysis
9. AEO Analysis
10. Event Tracker
11. Script Finder
12. Script Match
13. Static Builder

### Arquivos principais
- `manifest.json` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â configuraÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Â£o MV3, permissÃƒÆ’Ã‚Âµes, web_accessible_resources
- `popup.html` + `popup.js` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â UI principal, grid de ferramentas, painÃƒÆ’Ã‚Â©is
- `content.js` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â scripts injetados na pÃƒÆ’Ã‚Â¡gina ativa
- `background.js` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â service worker, fetch de pÃƒÆ’Ã‚Â¡ginas, bloqueio de scripts
- `report_utils.js` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â utilitÃƒÆ’Ã‚Â¡rios compartilhados de relatÃƒÆ’Ã‚Â³rio (Save HTML)
- `static_builder.html` + `static_builder.js` &mdash; Static Builder (HTML estatico, CSS inline, URLs absolutas)
- `function_index.md` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â ÃƒÆ’Ã‚Â­ndice completo de funÃƒÆ’Ã‚Â§ÃƒÆ’Ã‚Âµes, interdependÃƒÆ’Ã‚Âªncias e fluxos
- `match_analysis.html` + `match_analysis.js` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â relatÃƒÆ’Ã‚Â³rio Match Analysis
- `script_match.html` + `script_match.js` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â relatÃƒÆ’Ã‚Â³rio Script Match
- `seo_report.html` + `seo_report.js` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â relatÃƒÆ’Ã‚Â³rio SEO
- `aeo_report.html` + `aeo_report.js` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â relatÃƒÆ’Ã‚Â³rio AEO
- `lighthouse_report.html` + `lighthouse_report.js` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â relatÃƒÆ’Ã‚Â³rio Lighthouse
- `blueprinter.html` + `blueprinter.js` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â relatÃƒÆ’Ã‚Â³rio Component Blueprinter
- `ds_extractor.html` + `ds_extractor.js` ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â relatÃƒÆ’Ã‚Â³rio DS Extractor
