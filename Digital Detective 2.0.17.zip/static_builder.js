(function () {
  'use strict';

  var loadingEl = document.getElementById('sb-loading');
  var resultEl = document.getElementById('sb-result');
  var statusMsg = document.getElementById('sb-status-msg');
  var loadingUrl = document.getElementById('sb-loading-url');
  var progressFill = document.getElementById('sb-progress-fill');
  var progressMeta = document.getElementById('sb-progress-meta');

  var sourceUrl = '';
  var sourceTabId = null;
  var generatedHtml = '';

  var MAX_INLINE_ASSET_BYTES = 3 * 1024 * 1024;
  var MAX_INLINE_ASSET_COUNT = 320;
  var MAX_INLINE_SCRIPT_CHARS = 1200000;
  var loadingProgress = 0;
  var progressTimer = null;

  function clampProgress(value) {
    var n = Number(value);
    if (!Number.isFinite(n)) return 0;
    if (n < 0) return 0;
    if (n > 100) return 100;
    return n;
  }

  function renderProgress() {
    if (progressFill) progressFill.style.width = clampProgress(loadingProgress) + '%';
    if (progressMeta) progressMeta.textContent = Math.round(clampProgress(loadingProgress)) + '%';
  }

  function setProgress(target) {
    loadingProgress = clampProgress(target);
    renderProgress();
  }

  function stopProgressPulse() {
    if (progressTimer) {
      clearInterval(progressTimer);
      progressTimer = null;
    }
  }

  function startProgressPulse() {
    stopProgressPulse();
    progressTimer = setInterval(function () {
      if (loadingProgress < 88) {
        loadingProgress += (Math.random() * 2.2) + 0.3;
        if (loadingProgress > 88) loadingProgress = 88;
        renderProgress();
      }
    }, 180);
  }

  function setStatus(msg, progressTarget) {
    if (statusMsg) statusMsg.textContent = msg || '';
    if (typeof progressTarget === 'number') {
      var target = clampProgress(progressTarget);
      if (target > loadingProgress) {
        loadingProgress = target;
        renderProgress();
      }
    }
  }

  function showError(msg) {
    stopProgressPulse();
    if (statusMsg) statusMsg.textContent = msg || 'An unexpected error occurred.';
    var spinner = document.getElementById('sb-spinner');
    if (spinner) spinner.style.display = 'none';
    if (loadingEl) loadingEl.className = 'sb-loading-box sb-error';
  }

  function normalizeComparableUrl(url) {
    try {
      var parsed = new URL(String(url || '').trim());
      parsed.hash = '';
      return parsed.href;
    } catch (e) {
      return String(url || '').trim().split('#')[0];
    }
  }

  function isIgnoredScheme(value) {
    return /^(data:|javascript:|mailto:|tel:|blob:|#)/i.test(String(value || '').trim());
  }

  function resolveUrl(url, base) {
    if (!url) return url;
    var value = String(url).trim();
    if (!value) return value;
    if (isIgnoredScheme(value)) return value;
    if (value.indexOf('//') === 0) return 'https:' + value;
    try {
      return new URL(value, base).href;
    } catch (e) {
      return value;
    }
  }

  function isHttpUrl(url) {
    try {
      var u = new URL(String(url || '').trim());
      var p = (u.protocol || '').toLowerCase();
      return p === 'http:' || p === 'https:';
    } catch (e) {
      return false;
    }
  }

  function sendMessage(payload) {
    return new Promise(function (resolve) {
      chrome.runtime.sendMessage(payload, function (resp) {
        if (chrome.runtime.lastError) {
          resolve(null);
          return;
        }
        resolve(resp || null);
      });
    });
  }

  function fetchTextByUrls(urls) {
    var list = Array.isArray(urls) ? urls.filter(function (u) { return isHttpUrl(u); }) : [];
    if (!list.length) return Promise.resolve({});
    return sendMessage({ action: 'fetch_text_urls', urls: list }).then(function (resp) {
      var map = {};
      var items = (resp && Array.isArray(resp.items)) ? resp.items : [];
      items.forEach(function (item) {
        if (!item || !item.url) return;
        map[item.url] = item.text || '';
      });
      return map;
    });
  }

  function fetchCssByUrls(urls) {
    var list = Array.isArray(urls) ? urls.filter(function (u) { return isHttpUrl(u); }) : [];
    if (!list.length) return Promise.resolve([]);
    return sendMessage({ action: 'fetch_css_urls', urls: list }).then(function (resp) {
      var items = (resp && Array.isArray(resp.items)) ? resp.items : [];
      return items;
    });
  }

  function fetchAssetsDataUri(urls, maxBytes) {
    var list = Array.isArray(urls) ? urls.filter(function (u) { return isHttpUrl(u); }) : [];
    if (!list.length) {
      return Promise.resolve({
        map: {},
        meta: { requested: 0, ok: 0, failed: 0, tooLarge: 0 }
      });
    }
    return sendMessage({
      action: 'fetch_assets_datauri',
      urls: list,
      maxBytes: maxBytes
    }).then(function (resp) {
      var map = {};
      var meta = { requested: list.length, ok: 0, failed: 0, tooLarge: 0 };
      var items = (resp && Array.isArray(resp.items)) ? resp.items : [];
      items.forEach(function (item) {
        if (!item || !item.url) return;
        if (item.ok && item.dataUri) {
          map[item.url] = item.dataUri;
          meta.ok++;
          return;
        }
        meta.failed++;
        if (item.error === 'asset_too_large') meta.tooLarge++;
      });
      return { map: map, meta: meta };
    });
  }

  function extractCssUrlCandidates(cssText, baseUrl) {
    var urls = [];
    if (!cssText) return urls;

    cssText.replace(/url\(\s*(['"]?)([^'"\)]*)\1\s*\)/gi, function (_, q, raw) {
      var value = String(raw || '').trim();
      if (!value || isIgnoredScheme(value)) return _;
      urls.push(resolveUrl(value, baseUrl));
      return _;
    });

    cssText.replace(/@import\s+(?:url\(\s*)?(?:(['"])([^'"]+)\1|([^'"\)\s;]+))(?:\s*\))?([^;]*);/gi, function (_, q, quotedUrl, rawUrl) {
      var href = String(quotedUrl || rawUrl || '').trim();
      if (!href || isIgnoredScheme(href)) return _;
      urls.push(resolveUrl(href, baseUrl));
      return _;
    });

    return urls;
  }

  function rewriteCssText(cssText, baseUrl, dataUriMap) {
    if (!cssText) return '';

    var out = cssText.replace(/@import\s+(?:url\(\s*)?(?:(['"])([^'"]+)\1|([^'"\)\s;]+))(?:\s*\))?([^;]*);/gi, function (all, q, quotedUrl, rawUrl, tail) {
      var href = String(quotedUrl || rawUrl || '').trim();
      if (!href || isIgnoredScheme(href)) return all;
      var abs = resolveUrl(href, baseUrl);
      var next = (dataUriMap && dataUriMap[abs]) ? dataUriMap[abs] : abs;
      var suffix = tail || '';
      return '@import url("' + next + '")' + suffix + ';';
    });

    out = out.replace(/url\(\s*(['"]?)([^'"\)]*)\1\s*\)/gi, function (all, q, rawUrl) {
      var value = String(rawUrl || '').trim();
      if (!value || isIgnoredScheme(value)) return all;
      var abs = resolveUrl(value, baseUrl);
      var next = (dataUriMap && dataUriMap[abs]) ? dataUriMap[abs] : abs;
      var quote = q || '';
      return 'url(' + quote + next + quote + ')';
    });

    return out;
  }

  function rewriteSrcset(srcset, baseUrl, dataUriMap) {
    if (!srcset) return srcset;
    return srcset.split(',').map(function (entry) {
      var part = entry.trim();
      if (!part) return entry;
      var chunks = part.split(/\s+/);
      if (!chunks.length || !chunks[0]) return entry;
      var abs = resolveUrl(chunks[0], baseUrl);
      chunks[0] = (dataUriMap && dataUriMap[abs]) ? dataUriMap[abs] : abs;
      return chunks.join(' ');
    }).join(', ');
  }

  function rewriteSimpleAttributeUrls(doc, selector, attrName, baseUrl, dataUriMap) {
    var count = 0;
    doc.querySelectorAll(selector).forEach(function (el) {
      var raw = el.getAttribute(attrName);
      if (!raw) return;
      var abs = resolveUrl(raw, baseUrl);
      var next = (dataUriMap && dataUriMap[abs]) ? dataUriMap[abs] : abs;
      el.setAttribute(attrName, next);
      count++;
    });
    return count;
  }

  function rewriteMetaUrlContents(doc, baseUrl) {
    var rewritable = {
      'og:url': true,
      'og:image': true,
      'og:image:url': true,
      'og:image:secure_url': true,
      'twitter:url': true,
      'twitter:image': true,
      'twitter:image:src': true,
      'twitter:player': true,
      'msapplication-tileimage': true
    };
    var count = 0;
    doc.querySelectorAll('meta[content]').forEach(function (meta) {
      var key = (meta.getAttribute('property') || meta.getAttribute('name') || '').toLowerCase().trim();
      if (!rewritable[key]) return;
      var value = meta.getAttribute('content');
      if (!value) return;
      meta.setAttribute('content', resolveUrl(value, baseUrl));
      count++;
    });
    return count;
  }

  function removeCspMetaTags(doc) {
    var removed = 0;
    doc.querySelectorAll('meta[http-equiv]').forEach(function (meta) {
      var equiv = (meta.getAttribute('http-equiv') || '').toLowerCase().trim();
      if (equiv === 'content-security-policy' || equiv === 'content-security-policy-report-only') {
        if (meta.parentNode) {
          meta.parentNode.removeChild(meta);
          removed++;
        }
      }
    });
    return removed;
  }

  function rewriteHtmlUrls(doc, baseUrl, dataUriMap) {
    var count = 0;

    count += rewriteSimpleAttributeUrls(
      doc,
      'script[src], img[src], source[src], video[src], audio[src], iframe[src], embed[src], input[src], track[src]',
      'src',
      baseUrl,
      dataUriMap
    );
    count += rewriteSimpleAttributeUrls(doc, 'a[href], area[href]', 'href', baseUrl);
    count += rewriteSimpleAttributeUrls(doc, 'link[href]:not([rel~="stylesheet"])', 'href', baseUrl, dataUriMap);
    count += rewriteSimpleAttributeUrls(doc, 'link[rel~="stylesheet"][href]', 'href', baseUrl, dataUriMap);
    count += rewriteSimpleAttributeUrls(doc, 'form[action]', 'action', baseUrl);
    count += rewriteSimpleAttributeUrls(doc, 'video[poster]', 'poster', baseUrl, dataUriMap);
    count += rewriteSimpleAttributeUrls(doc, 'object[data]', 'data', baseUrl, dataUriMap);
    count += rewriteSimpleAttributeUrls(doc, '[data-src]', 'data-src', baseUrl, dataUriMap);
    count += rewriteSimpleAttributeUrls(doc, '[data-href]', 'data-href', baseUrl, dataUriMap);
    count += rewriteSimpleAttributeUrls(doc, '[data-url]', 'data-url', baseUrl, dataUriMap);
    count += rewriteSimpleAttributeUrls(doc, '[data-bg]', 'data-bg', baseUrl, dataUriMap);
    count += rewriteSimpleAttributeUrls(doc, '[data-background]', 'data-background', baseUrl, dataUriMap);
    count += rewriteSimpleAttributeUrls(doc, '[data-background-image]', 'data-background-image', baseUrl, dataUriMap);

    doc.querySelectorAll('[srcset]').forEach(function (el) {
      var value = el.getAttribute('srcset');
      if (!value) return;
      el.setAttribute('srcset', rewriteSrcset(value, baseUrl, dataUriMap));
      count++;
    });
    doc.querySelectorAll('[data-srcset]').forEach(function (el) {
      var value = el.getAttribute('data-srcset');
      if (!value) return;
      el.setAttribute('data-srcset', rewriteSrcset(value, baseUrl, dataUriMap));
      count++;
    });

    count += rewriteMetaUrlContents(doc, baseUrl);

    var XLINK = 'http://www.w3.org/1999/xlink';
    doc.querySelectorAll('use, image').forEach(function (el) {
      var href = el.getAttribute('href');
      if (href && href.charAt(0) !== '#') {
        var abs = resolveUrl(href, baseUrl);
        var next = (dataUriMap && dataUriMap[abs]) ? dataUriMap[abs] : abs;
        el.setAttribute('href', next);
        count++;
      }
      var xlinkHref = el.getAttributeNS(XLINK, 'href');
      if (xlinkHref && xlinkHref.charAt(0) !== '#') {
        var abs2 = resolveUrl(xlinkHref, baseUrl);
        var next2 = (dataUriMap && dataUriMap[abs2]) ? dataUriMap[abs2] : abs2;
        el.setAttributeNS(XLINK, 'href', next2);
        count++;
      }
    });

    doc.querySelectorAll('[style]').forEach(function (el) {
      var styleText = el.getAttribute('style');
      if (!styleText) return;
      if (styleText.indexOf('url(') < 0 && styleText.toLowerCase().indexOf('@import') < 0) return;
      el.setAttribute('style', rewriteCssText(styleText, baseUrl, dataUriMap));
      count++;
    });

    doc.querySelectorAll('style').forEach(function (styleEl) {
      var css = styleEl.textContent || '';
      if (css.indexOf('url(') < 0 && css.toLowerCase().indexOf('@import') < 0) return;
      styleEl.textContent = rewriteCssText(css, baseUrl, dataUriMap);
      count++;
    });

    return count;
  }

  function inlineCssFiles(doc, baseUrl) {
    var linkEls = Array.from(doc.querySelectorAll('link[rel~="stylesheet"][href]'));
    if (!linkEls.length) {
      return Promise.resolve({ inlined: 0, failed: 0 });
    }
    var urls = linkEls.map(function (el) { return resolveUrl(el.getAttribute('href'), baseUrl); });
    return fetchCssByUrls(urls).then(function (items) {
      var inlined = 0;
      var failed = 0;
      linkEls.forEach(function (linkEl, idx) {
        var item = items[idx];
        if (!item || !item.css) {
          failed++;
          return;
        }
        var cssBaseUrl = item.url || urls[idx] || baseUrl;
        var css = rewriteCssText(item.css, cssBaseUrl, null);
        var styleEl = doc.createElement('style');
        styleEl.setAttribute('data-dd-inlined-from', urls[idx] || '');
        var media = linkEl.getAttribute('media');
        if (media) styleEl.setAttribute('media', media);
        var nonce = linkEl.getAttribute('nonce');
        if (nonce) styleEl.setAttribute('nonce', nonce);
        styleEl.textContent = css;
        if (linkEl.parentNode) {
          linkEl.parentNode.replaceChild(styleEl, linkEl);
          inlined++;
        }
      });
      return { inlined: inlined, failed: failed };
    });
  }

  function sanitizeInlineScriptText(text) {
    // Prevent accidental script-tag termination when serializing HTML.
    return String(text || '').replace(/<\/script/gi, '<\\/script');
  }

  function inlineExternalScripts(doc, baseUrl) {
    var scriptEls = Array.from(doc.querySelectorAll('script[src]'));
    if (!scriptEls.length) {
      return Promise.resolve({ inlined: 0, failed: 0, skippedLarge: 0 });
    }
    var urls = scriptEls.map(function (scriptEl) {
      return resolveUrl(scriptEl.getAttribute('src'), baseUrl);
    });
    return fetchTextByUrls(urls).then(function (map) {
      var inlined = 0;
      var failed = 0;
      var skippedLarge = 0;

      scriptEls.forEach(function (scriptEl, idx) {
        var absUrl = urls[idx];
        var text = map[absUrl] || '';
        if (!text) {
          failed++;
          scriptEl.setAttribute('src', absUrl);
          return;
        }
        if (text.length > MAX_INLINE_SCRIPT_CHARS) {
          skippedLarge++;
          scriptEl.setAttribute('src', absUrl);
          return;
        }

        var replacement = doc.createElement('script');
        Array.from(scriptEl.attributes || []).forEach(function (attr) {
          var name = String(attr.name || '').toLowerCase();
          if (name === 'src' || name === 'integrity' || name === 'crossorigin') return;
          replacement.setAttribute(attr.name, attr.value);
        });
        replacement.setAttribute('data-dd-inlined-from', absUrl);
        replacement.textContent = '\n/* inlined by Digital Detective from ' + absUrl + ' */\n' + sanitizeInlineScriptText(text) + '\n';
        if (scriptEl.parentNode) {
          scriptEl.parentNode.replaceChild(replacement, scriptEl);
          inlined++;
        }
      });

      return { inlined: inlined, failed: failed, skippedLarge: skippedLarge };
    });
  }

  function addAssetUrl(set, rawUrl, baseUrl) {
    if (!rawUrl) return;
    var abs = resolveUrl(rawUrl, baseUrl);
    if (!abs || isIgnoredScheme(abs) || !isHttpUrl(abs)) return;
    set.add(abs);
  }

  function collectAssetUrls(doc, baseUrl) {
    var urls = new Set();

    doc.querySelectorAll('img[src], source[src], video[src], audio[src], embed[src], input[src], track[src], object[data], video[poster], [data-src], [data-href], [data-url], [data-bg], [data-background], [data-background-image]').forEach(function (el) {
      if (el.hasAttribute('src')) addAssetUrl(urls, el.getAttribute('src'), baseUrl);
      if (el.hasAttribute('data')) addAssetUrl(urls, el.getAttribute('data'), baseUrl);
      if (el.hasAttribute('poster')) addAssetUrl(urls, el.getAttribute('poster'), baseUrl);
      if (el.hasAttribute('data-src')) addAssetUrl(urls, el.getAttribute('data-src'), baseUrl);
      if (el.hasAttribute('data-href')) addAssetUrl(urls, el.getAttribute('data-href'), baseUrl);
      if (el.hasAttribute('data-url')) addAssetUrl(urls, el.getAttribute('data-url'), baseUrl);
      if (el.hasAttribute('data-bg')) addAssetUrl(urls, el.getAttribute('data-bg'), baseUrl);
      if (el.hasAttribute('data-background')) addAssetUrl(urls, el.getAttribute('data-background'), baseUrl);
      if (el.hasAttribute('data-background-image')) addAssetUrl(urls, el.getAttribute('data-background-image'), baseUrl);
    });

    doc.querySelectorAll('link[href]').forEach(function (linkEl) {
      var rel = (linkEl.getAttribute('rel') || '').toLowerCase();
      if (!rel) return;
      if (
        rel.indexOf('icon') >= 0 ||
        rel.indexOf('apple-touch-icon') >= 0 ||
        rel.indexOf('mask-icon') >= 0 ||
        rel.indexOf('manifest') >= 0 ||
        rel.indexOf('preload') >= 0 ||
        rel.indexOf('prefetch') >= 0
      ) {
        addAssetUrl(urls, linkEl.getAttribute('href'), baseUrl);
      }
    });

    doc.querySelectorAll('use[href], image[href], use[xlink\\:href], image[xlink\\:href]').forEach(function (el) {
      addAssetUrl(urls, el.getAttribute('href'), baseUrl);
      addAssetUrl(urls, el.getAttribute('xlink:href'), baseUrl);
    });

    doc.querySelectorAll('[srcset]').forEach(function (el) {
      var value = el.getAttribute('srcset') || '';
      value.split(',').forEach(function (part) {
        var first = part.trim().split(/\s+/)[0];
        if (first) addAssetUrl(urls, first, baseUrl);
      });
    });
    doc.querySelectorAll('[data-srcset]').forEach(function (el) {
      var value = el.getAttribute('data-srcset') || '';
      value.split(',').forEach(function (part) {
        var first = part.trim().split(/\s+/)[0];
        if (first) addAssetUrl(urls, first, baseUrl);
      });
    });

    doc.querySelectorAll('[style]').forEach(function (el) {
      var css = el.getAttribute('style') || '';
      extractCssUrlCandidates(css, baseUrl).forEach(function (u) { addAssetUrl(urls, u, baseUrl); });
    });
    doc.querySelectorAll('style').forEach(function (styleEl) {
      var css = styleEl.textContent || '';
      extractCssUrlCandidates(css, baseUrl).forEach(function (u) { addAssetUrl(urls, u, baseUrl); });
    });

    return Array.from(urls).slice(0, MAX_INLINE_ASSET_COUNT);
  }

  function applyDataUriMap(doc, baseUrl, dataUriMap) {
    if (!dataUriMap) return 0;
    var touched = 0;

    function setMapped(el, attr) {
      var raw = el.getAttribute(attr);
      if (!raw) return;
      var abs = resolveUrl(raw, baseUrl);
      var mapped = dataUriMap[abs];
      if (!mapped) return;
      el.setAttribute(attr, mapped);
      touched++;
    }

    doc.querySelectorAll('img[src], source[src], video[src], audio[src], embed[src], input[src], track[src]').forEach(function (el) {
      setMapped(el, 'src');
    });
    doc.querySelectorAll('video[poster]').forEach(function (el) { setMapped(el, 'poster'); });
    doc.querySelectorAll('object[data]').forEach(function (el) { setMapped(el, 'data'); });
    doc.querySelectorAll('[data-src]').forEach(function (el) { setMapped(el, 'data-src'); });
    doc.querySelectorAll('[data-href]').forEach(function (el) { setMapped(el, 'data-href'); });
    doc.querySelectorAll('[data-url]').forEach(function (el) { setMapped(el, 'data-url'); });
    doc.querySelectorAll('[data-bg]').forEach(function (el) { setMapped(el, 'data-bg'); });
    doc.querySelectorAll('[data-background]').forEach(function (el) { setMapped(el, 'data-background'); });
    doc.querySelectorAll('[data-background-image]').forEach(function (el) { setMapped(el, 'data-background-image'); });

    doc.querySelectorAll('link[href]').forEach(function (el) {
      var rel = (el.getAttribute('rel') || '').toLowerCase();
      if (!rel) return;
      if (
        rel.indexOf('icon') >= 0 ||
        rel.indexOf('apple-touch-icon') >= 0 ||
        rel.indexOf('mask-icon') >= 0 ||
        rel.indexOf('manifest') >= 0 ||
        rel.indexOf('preload') >= 0 ||
        rel.indexOf('prefetch') >= 0
      ) {
        setMapped(el, 'href');
      }
    });

    doc.querySelectorAll('use[href], image[href]').forEach(function (el) { setMapped(el, 'href'); });
    doc.querySelectorAll('use[xlink\\:href], image[xlink\\:href]').forEach(function (el) { setMapped(el, 'xlink:href'); });

    doc.querySelectorAll('[srcset]').forEach(function (el) {
      var value = el.getAttribute('srcset');
      if (!value) return;
      el.setAttribute('srcset', rewriteSrcset(value, baseUrl, dataUriMap));
      touched++;
    });
    doc.querySelectorAll('[data-srcset]').forEach(function (el) {
      var value = el.getAttribute('data-srcset');
      if (!value) return;
      el.setAttribute('data-srcset', rewriteSrcset(value, baseUrl, dataUriMap));
      touched++;
    });

    doc.querySelectorAll('[style]').forEach(function (el) {
      var css = el.getAttribute('style');
      if (!css) return;
      if (css.indexOf('url(') < 0 && css.toLowerCase().indexOf('@import') < 0) return;
      el.setAttribute('style', rewriteCssText(css, baseUrl, dataUriMap));
      touched++;
    });
    doc.querySelectorAll('style').forEach(function (styleEl) {
      var css = styleEl.textContent || '';
      if (css.indexOf('url(') < 0 && css.toLowerCase().indexOf('@import') < 0) return;
      styleEl.textContent = rewriteCssText(css, baseUrl, dataUriMap);
      touched++;
    });

    return touched;
  }

  function processStaticHtml(rawHtml, pageUrl, options, callback) {
    var parser = new DOMParser();
    var doc;
    try {
      doc = parser.parseFromString(rawHtml, 'text/html');
    } catch (e) {
      callback(null, 'Failed to parse HTML: ' + String(e));
      return;
    }

    var divCountBefore = doc.querySelectorAll('div').length;

    var baseUrl = pageUrl;
    var baseTag = doc.querySelector('base[href]');
    if (baseTag) {
      try {
        baseUrl = new URL(baseTag.getAttribute('href'), pageUrl).href;
      } catch (e0) {}
      if (baseTag.parentNode) baseTag.parentNode.removeChild(baseTag);
    }

    setStatus('Inlining external CSS...', 56);
    inlineCssFiles(doc, baseUrl).then(function (cssStats) {
      setStatus('Inlining external scripts...', 66);
      return inlineExternalScripts(doc, baseUrl).then(function (scriptStats) {
        return { cssStats: cssStats, scriptStats: scriptStats };
      });
    }).then(function (stepStats) {
      setStatus('Rewriting URLs and SEO assets...', 76);
      var rewrittenCount = rewriteHtmlUrls(doc, baseUrl, null);
      var cspRemoved = removeCspMetaTags(doc);
      return {
        rewrittenCount: rewrittenCount,
        cspRemoved: cspRemoved,
        cssStats: stepStats.cssStats,
        scriptStats: stepStats.scriptStats
      };
    }).then(function (stepStats2) {
      setStatus('Inlining icons/fonts/media assets...', 86);
      var assetUrls = collectAssetUrls(doc, baseUrl);
      return fetchAssetsDataUri(assetUrls, MAX_INLINE_ASSET_BYTES).then(function (assetRes) {
        var dataUriMap = assetRes.map || {};
        var touched = applyDataUriMap(doc, baseUrl, dataUriMap);
        return {
          rewrittenCount: stepStats2.rewrittenCount,
          cspRemoved: stepStats2.cspRemoved,
          cssStats: stepStats2.cssStats,
          scriptStats: stepStats2.scriptStats,
          assetMeta: assetRes.meta || { requested: assetUrls.length, ok: 0, failed: 0, tooLarge: 0 },
          assetApplied: touched
        };
      });
    }).then(function (stats) {
      var divCountAfter = doc.querySelectorAll('div').length;
      var snapshotSource = (options && options.captureSource) ? options.captureSource : 'unknown';
      var sourceDoctype = (options && options.doctype) ? String(options.doctype).trim() : '<!DOCTYPE html>';

      var head = doc.querySelector('head');
      if (head) {
        var comment = doc.createComment(
          ' Generated by Digital Detective Static Builder v2.0.17' +
          ' | Source: ' + pageUrl +
          ' | Capture: ' + snapshotSource +
          ' | Date: ' + new Date().toISOString() +
          ' | CSS inlined: ' + (stats.cssStats ? stats.cssStats.inlined : 0) +
          ' | Scripts inlined: ' + (stats.scriptStats ? stats.scriptStats.inlined : 0) +
          ' | Assets inlined: ' + (stats.assetMeta ? stats.assetMeta.ok : 0) +
          ' | Resources rewritten: ' + stats.rewrittenCount +
          ' | CSP meta removed: ' + stats.cspRemoved +
          ' '
        );
        head.insertBefore(comment, head.firstChild);
      }

      var serialized = sourceDoctype + '\n' + doc.documentElement.outerHTML;
      var sizeKb = Math.round(serialized.length / 1024);

      callback(serialized, null, {
        inlinedCss: stats.cssStats ? stats.cssStats.inlined : 0,
        inlinedScripts: stats.scriptStats ? stats.scriptStats.inlined : 0,
        scriptsSkippedLarge: stats.scriptStats ? stats.scriptStats.skippedLarge : 0,
        inlinedAssets: stats.assetMeta ? stats.assetMeta.ok : 0,
        assetTooLarge: stats.assetMeta ? stats.assetMeta.tooLarge : 0,
        linksRewritten: stats.rewrittenCount || 0,
        cspRemoved: stats.cspRemoved || 0,
        sizeKb: sizeKb,
        captureSource: snapshotSource,
        divCountBefore: divCountBefore,
        divCountAfter: divCountAfter
      });
    }).catch(function (err) {
      callback(null, (err && err.message) ? err.message : 'Static processing failed.');
    });
  }

  function showResult(html, url, stats) {
    stopProgressPulse();
    setProgress(100);
    generatedHtml = html;

    var srcUrlEl = document.getElementById('sb-result-url');
    var dateEl = document.getElementById('sb-result-date');
    var cssEl = document.getElementById('sb-result-css');
    var linksEl = document.getElementById('sb-result-links');
    var sizeEl = document.getElementById('sb-result-size');
    var captureEl = document.getElementById('sb-result-capture');
    var divsEl = document.getElementById('sb-result-divs');
    var noteEl = document.getElementById('sb-result-note');

    if (srcUrlEl) srcUrlEl.textContent = url;
    if (dateEl) dateEl.textContent = new Date().toLocaleString();
    if (cssEl) cssEl.textContent = String(stats.inlinedCss || 0);
    if (linksEl) linksEl.textContent = String(stats.linksRewritten || 0);
    if (sizeEl) sizeEl.textContent = String(stats.sizeKb || 0) + ' KB';
    if (captureEl) captureEl.textContent = stats.captureSource || 'unknown';

    if (divsEl) {
      var before = Number(stats.divCountBefore || 0);
      var after = Number(stats.divCountAfter || 0);
      var parity = (before === after) ? 'OK' : 'DIFF';
      divsEl.textContent = before + ' -> ' + after + ' (' + parity + ')';
    }

    if (noteEl) {
      noteEl.innerHTML =
        '<strong>What was processed:</strong> CSS inlined: <strong>' + String(stats.inlinedCss || 0) +
        '</strong>, scripts inlined: <strong>' + String(stats.inlinedScripts || 0) +
        '</strong>, assets/fonts/icons inlined: <strong>' + String(stats.inlinedAssets || 0) +
        '</strong>, CSP tags removed: <strong>' + String(stats.cspRemoved || 0) +
        '</strong>. Script skip (large): <strong>' + String(stats.scriptsSkippedLarge || 0) +
        '</strong>, assets too large to inline: <strong>' + String(stats.assetTooLarge || 0) +
        '</strong>.';
    }

    if (loadingEl) loadingEl.style.display = 'none';
    if (resultEl) resultEl.style.display = '';

    var saveBtn = document.getElementById('sb-save');
    if (saveBtn) {
      saveBtn.addEventListener('click', function () {
        var hostname = '';
        try { hostname = new URL(url).hostname.replace(/\W+/g, '_'); } catch (e) {}
        var dateStr = new Date().toISOString().slice(0, 10);
        var filename = 'static_' + (hostname || 'page') + '_' + dateStr + '.html';
        var blob = new Blob([generatedHtml], { type: 'text/html' });
        var anchor = document.createElement('a');
        anchor.href = URL.createObjectURL(blob);
        anchor.download = filename;
        document.body.appendChild(anchor);
        anchor.click();
        document.body.removeChild(anchor);
        setTimeout(function () { URL.revokeObjectURL(anchor.href); }, 30000);
      });
    }

    var previewBtn = document.getElementById('sb-preview');
    if (previewBtn) {
      previewBtn.addEventListener('click', function () {
        var blob = new Blob([generatedHtml], { type: 'text/html' });
        var blobUrl = URL.createObjectURL(blob);
        var popup = window.open(blobUrl, '_blank');
        if (!popup) window.location.href = blobUrl;
        setTimeout(function () { URL.revokeObjectURL(blobUrl); }, 120000);
      });
    }
  }

  function sendToTab(tabId, payload, callback) {
    chrome.tabs.sendMessage(tabId, payload, function (resp) {
      if (!chrome.runtime.lastError) {
        callback(resp || { error: 'No response' });
        return;
      }
      chrome.scripting.executeScript(
        { target: { tabId: tabId }, files: ['content.js'] },
        function () {
          if (chrome.runtime.lastError) {
            callback({ error: 'Cannot inject on this page.' });
            return;
          }
          chrome.tabs.sendMessage(tabId, payload, function (retryResp) {
            callback(retryResp || { error: 'No response' });
          });
        }
      );
    });
  }

  function captureFromSourceTab(callback) {
    if (!sourceTabId) {
      callback(null);
      return;
    }
    chrome.tabs.get(sourceTabId, function (tab) {
      if (chrome.runtime.lastError || !tab || !tab.id || !tab.url) {
        callback(null);
        return;
      }
      var inputUrl = normalizeComparableUrl(sourceUrl);
      var tabUrl = normalizeComparableUrl(tab.url);
      if (inputUrl && tabUrl && inputUrl !== tabUrl) {
        callback(null);
        return;
      }
      setStatus('Capturing rendered DOM from source tab...', 18);
      sendToTab(tab.id, { action: 'capture_page_snapshot' }, function (resp) {
        if (!resp || resp.error || !resp.ok || !resp.html) {
          callback(null);
          return;
        }
        callback({
          html: resp.html,
          url: resp.url || sourceUrl,
          doctype: resp.doctype || '<!DOCTYPE html>',
          captureSource: 'source-tab'
        });
      });
    });
  }

  function captureFromBackground(callback) {
    setStatus('Rendering page in background for DOM capture...', 26);
    sendMessage({
      action: 'capture_rendered_page',
      url: sourceUrl,
      waitMs: 3500
    }).then(function (resp) {
      if (!resp || !resp.ok || !resp.html) {
        callback(null);
        return;
      }
      callback({
        html: resp.html,
        url: resp.url || sourceUrl,
        doctype: resp.doctype || '<!DOCTYPE html>',
        captureSource: 'background-render'
      });
    });
  }

  function fetchRawHtmlFallback(callback) {
    setStatus('Fallback: fetching raw HTML...', 34);
    sendMessage({ action: 'fetch_page_for_match', url: sourceUrl }).then(function (resp) {
      if (!resp || !resp.ok || !resp.html) {
        callback(null);
        return;
      }
      callback({
        html: resp.html,
        url: sourceUrl,
        doctype: '<!DOCTYPE html>',
        captureSource: 'raw-fetch'
      });
    });
  }

  function processSnapshot(snapshot) {
    var inputHtml = snapshot && snapshot.html ? snapshot.html : '';
    var effectiveUrl = snapshot && snapshot.url ? snapshot.url : sourceUrl;
    var doctype = snapshot && snapshot.doctype ? snapshot.doctype : '<!DOCTYPE html>';
    var captureSource = snapshot && snapshot.captureSource ? snapshot.captureSource : 'unknown';

    if (!inputHtml) {
      showError('Captured HTML is empty.');
      return;
    }

    setStatus('Processing static output...', 46);
    processStaticHtml(inputHtml, effectiveUrl, {
      doctype: doctype,
      captureSource: captureSource
    }, function (html, error, stats) {
      if (error || !html) {
        showError(error || 'Processing failed. Could not serialize the page.');
        return;
      }
      showResult(html, effectiveUrl, stats || {});
    });
  }

  function run() {
    var params = new URLSearchParams(window.location.search);
    sourceUrl = (params.get('url') || '').trim();
    var tabIdRaw = (params.get('tabId') || '').trim();
    var parsedTabId = Number(tabIdRaw);
    if (Number.isInteger(parsedTabId) && parsedTabId > 0) sourceTabId = parsedTabId;

    if (!sourceUrl) {
      showError('No URL provided. Please open Static Builder from the Digital Detective popup.');
      return;
    }

    if (loadingUrl) loadingUrl.textContent = sourceUrl;
    setProgress(4);
    startProgressPulse();
    setStatus('Starting robust static capture...', 8);

    captureFromSourceTab(function (sourceSnapshot) {
      if (sourceSnapshot && sourceSnapshot.html) {
        processSnapshot(sourceSnapshot);
        return;
      }

      captureFromBackground(function (bgSnapshot) {
        if (bgSnapshot && bgSnapshot.html) {
          processSnapshot(bgSnapshot);
          return;
        }

        fetchRawHtmlFallback(function (rawSnapshot) {
          if (rawSnapshot && rawSnapshot.html) {
            processSnapshot(rawSnapshot);
            return;
          }
          showError('Failed to capture this page. Reload the source URL and try again.');
        });
      });
    });
  }

  run();
})();
