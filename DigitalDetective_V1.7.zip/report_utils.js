﻿(function () {
  'use strict';

  var REPORT_DS_STYLE_ID = 'dd-report-ds-style';
  var REPORT_DS_ARROW_BOUND = 'ddArrowBound';

  function getReportDesignSystemCss() {
    return '' +
      ':root{' +
      '--dd-ds-bg:#F2F5F0;' +
      '--dd-ds-surface:#ffffff;' +
      '--dd-ds-surface-soft:#f8fafc;' +
      '--dd-ds-accent:#DD1234;' +
      '--dd-ds-text:#1c1c1c;' +
      '--dd-ds-muted:#4a4a4a;' +
      '--dd-ds-line:#c7ccd1;' +
      '--dd-ds-radius-sm:10px;' +
      '--dd-ds-radius-md:14px;' +
      '--dd-ds-radius-lg:16px;' +
      '--dd-ds-space-1:4px;' +
      '--dd-ds-space-2:8px;' +
      '--dd-ds-space-3:12px;' +
      '--dd-ds-space-4:16px;' +
      '--dd-ds-space-5:20px;' +
      '--dd-ds-space-6:24px;' +
      '--dd-ds-space-7:32px;' +
      '--dd-ds-shadow-sm:0 3px 12px rgba(10,10,10,0.266);' +
      '}' +
      'html,body{background:var(--dd-ds-bg)!important;color:var(--dd-ds-text)!important;font-family:"Noto Sans",sans-serif!important;}' +
      '#seo-root,#lhr-root,#aeo-root,#ma-root,.page,.dd-container{max-width:960px;margin:0 auto;padding:24px 20px 64px 20px;}' +
      '.ma-page{max-width:none!important;margin:0!important;padding:0!important;}' +
      '.seo-header,.lhr-header,.aeo-header,.ma-header,.app-header,.header,.dd-header{border-bottom:1px solid var(--dd-ds-line)!important;padding-bottom:18px!important;margin-bottom:24px!important;}' +
      '.seo-url-link,.lhr-url-link,.aeo-url,.ma-url-link,.app-url,.report-url-link,.dd-report-url a{color:var(--dd-ds-accent)!important;}' +
      '.seo-btn,.lhr-btn,.aeo-btn,.ma-save-btn,.ma-reload-btn,.header-btn,.primary-btn,.ghost-btn,.dd-btn,.btn,.modal-close,.panel-toggle,.panel-collapse-btn,.ma-collapse-btn,.seo-section-toggle,.lhr-section-toggle,.aeo-section-toggle,.preview-btn,.asset-btn,.edit-btn{border-radius:999px!important;font-size:11px!important;font-weight:700!important;padding:8px 16px!important;line-height:1.2!important;}' +
      '.panel-toggle,.panel-collapse-btn,.ma-collapse-btn,.seo-section-toggle,.lhr-section-toggle,.aeo-section-toggle{padding:0!important;width:24px!important;height:24px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;}' +
      '.seo-btn.primary,.lhr-btn.primary,.aeo-btn.primary,.ma-save-btn,.primary-btn,.dd-btn.primary,.btn:not(.ghost),#saveReport{background:var(--dd-ds-accent)!important;color:#fff!important;border:none!important;}' +
      '.seo-btn:not(.primary),.lhr-btn:not(.primary),.aeo-btn:not(.primary),.ma-reload-btn,.header-btn:not(.primary),.ghost-btn,.dd-btn:not(.primary),.btn.ghost,.modal-close,.preview-btn,.asset-btn,.edit-btn,.panel-toggle,.panel-collapse-btn,.ma-collapse-btn,.seo-section-toggle,.lhr-section-toggle,.aeo-section-toggle{background:#fff!important;color:var(--dd-ds-text)!important;border:1px solid var(--dd-ds-line)!important;}' +
      '.seo-btn:not(.primary):hover,.lhr-btn:not(.primary):hover,.aeo-btn:not(.primary):hover,.ma-reload-btn:hover,.header-btn:not(.primary):hover,.ghost-btn:hover,.dd-btn:not(.primary):hover,.btn.ghost:hover,.modal-close:hover,.preview-btn:hover,.asset-btn:hover,.edit-btn:hover,.panel-toggle:hover,.panel-collapse-btn:hover,.ma-collapse-btn:hover,.seo-section-toggle:hover,.lhr-section-toggle:hover,.aeo-section-toggle:hover{background:#DEE2E6!important;}' +
      '.seo-summary-card,.seo-pillars-card,.seo-section,.seo-success-banner,.aeo-summary-card,.aeo-card,.aeo-section,.lhr-score-card,.lhr-section,.ma-score-card,.ma-block,.ma-loading-box,.panel,.card,.scope-card,.status,.modal-content,.preview-box,.asset,.copy-item{background:var(--dd-ds-surface)!important;border:none!important;border-radius:var(--dd-ds-radius-md)!important;box-shadow:var(--dd-ds-shadow-sm)!important;}' +
      '.seo-section-head,.lhr-section-head,.aeo-section-head,.ma-block-head,.panel-head{background:var(--dd-ds-surface)!important;border-bottom:1px solid var(--dd-ds-line)!important;padding:14px 20px!important;}' +
      '.seo-section-body,.lhr-section-body,.aeo-section-body,.panel-content,.panel-body{padding:16px 20px!important;}' +
      '.ma-col,.lhr-col,.seo-check-item,.aeo-check-item,.lhr-audit-item,.ma-row{border-bottom:1px solid var(--dd-ds-line)!important;}' +
      '.ma-col:last-child,.seo-check-item:last-child,.aeo-check-item:last-child,.lhr-audit-item:last-child,.ma-row:last-child{border-bottom:none!important;}' +
      '.seo-footer,.lhr-footer,.aeo-footer,.ma-footer,.app-footer{margin-top:32px!important;padding-top:16px!important;border-top:1px solid var(--dd-ds-line)!important;font-size:10px!important;color:#7a7f86!important;text-align:center!important;}' +
      '.app-footer{position:static!important;background:transparent!important;}' +
      '.shell .status{max-width:420px;margin:0 auto;}' +
      '@media (max-width:900px){.seo-summary-card,.lhr-score-card,.aeo-summary-card,.ma-score-card{padding:16px!important;}.lhr-score-card,.ma-two-col,.lhr-two-col{grid-template-columns:1fr!important;display:grid!important;}.lhr-score-half+.lhr-score-half,.ma-col:first-child{border-left:none!important;border-right:none!important;padding-left:0!important;}}';
  }

  function applyReportDesignSystem() {
    if (!document || !document.head) return;
    if (document.getElementById(REPORT_DS_STYLE_ID)) return;
    var styleEl = document.createElement('style');
    styleEl.id = REPORT_DS_STYLE_ID;
    styleEl.textContent = getReportDesignSystemCss();
    document.head.appendChild(styleEl);
  }

  function setArrowForButton(btn, section, collapsedClass) {
    if (!btn || !section) return;
    var collapsed = section.classList.contains(collapsedClass);
    var nextArrow = collapsed ? '\u25BC' : '\u25B2';
    var nextLabel = collapsed ? 'Expand section' : 'Collapse section';
    if (btn.textContent !== nextArrow) btn.textContent = nextArrow;
    if (btn.getAttribute('aria-label') !== nextLabel) btn.setAttribute('aria-label', nextLabel);
  }

  function bindArrowButtons(selector, sectionSelector, collapsedClass) {
    var buttons = document.querySelectorAll(selector);
    Array.prototype.slice.call(buttons).forEach(function (btn) {
      var section = btn.closest(sectionSelector);
      if (!section) return;
      setArrowForButton(btn, section, collapsedClass);
      if (btn.dataset && btn.dataset[REPORT_DS_ARROW_BOUND]) return;
      if (btn.dataset) btn.dataset[REPORT_DS_ARROW_BOUND] = '1';
      btn.addEventListener('click', function () {
        setTimeout(function () { setArrowForButton(btn, section, collapsedClass); }, 0);
      });
    });
  }

  function syncCollapseArrows() {
    bindArrowButtons('.seo-section-toggle', '.seo-section', 'seo-collapsed');
    bindArrowButtons('.lhr-section-toggle', '.lhr-section', 'lhr-collapsed');
    bindArrowButtons('.aeo-section-toggle', '.aeo-section', 'aeo-collapsed');
    bindArrowButtons('.ma-collapse-btn', '.ma-block', 'ma-collapsed');
    bindArrowButtons('.panel-toggle', '.panel', 'is-collapsed');
    bindArrowButtons('.dd-section-toggle', '.dd-section', 'is-collapsed');
    bindArrowButtons('.panel-collapse-btn', '.panel', 'is-collapsed');
  }

  function initReportDesignSystem() {
    applyReportDesignSystem();
    syncCollapseArrows();
    setTimeout(syncCollapseArrows, 80);
    setTimeout(syncCollapseArrows, 300);
    if (!document || !document.body || window.__ddDsObserverActive || typeof MutationObserver === 'undefined') return;
    window.__ddDsObserverActive = true;

    var scheduled = false;
    var syncing = false;
    function scheduleSync() {
      if (scheduled) return;
      scheduled = true;
      setTimeout(function () {
        scheduled = false;
        if (syncing) return;
        syncing = true;
        try { syncCollapseArrows(); } finally { syncing = false; }
      }, 0);
    }

    var obs = new MutationObserver(function () {
      scheduleSync();
    });
    obs.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  function downloadBlob(blob, filename) {
    if (!blob) return;
    try {
      var blobUrl = URL.createObjectURL(blob);
      if (typeof chrome !== 'undefined' && chrome.downloads && chrome.downloads.download) {
        chrome.downloads.download({ url: blobUrl, filename: filename || '', saveAs: true }, function () {
          setTimeout(function () { try { URL.revokeObjectURL(blobUrl); } catch (e) {} }, 10000);
        });
        return;
      }
      var a = document.createElement('a');
      a.href = blobUrl;
      if (filename) a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { try { URL.revokeObjectURL(blobUrl); } catch (e) {} }, 10000);
    } catch (e2) {}
  }

  function saveDocumentAsHtml(filename) {
    var html = '<!doctype html>\n' + document.documentElement.outerHTML;
    var blob = new Blob([html], { type: 'text/html' });
    if (typeof chrome !== 'undefined' && chrome.downloads && chrome.downloads.download) {
      downloadBlob(blob, filename || 'report.html');
      return;
    }
    if (window.showSaveFilePicker) {
      window.showSaveFilePicker({
        suggestedName: filename || 'report.html',
        types: [{ description: 'HTML', accept: { 'text/html': ['.html'] } }]
      }).then(function (handle) {
        return handle.createWritable().then(function (writable) {
          return writable.write(blob).then(function () { return writable.close(); });
        });
      }).catch(function () { downloadBlob(blob, filename || 'report.html'); });
      return;
    }
    downloadBlob(blob, filename || 'report.html');
  }

  function bindSaveButton(btn, filename) {
    if (!btn) return;
    btn.addEventListener('click', function () {
      saveDocumentAsHtml(filename || 'report.html');
    });
  }

  function bindCodeModal(opts) {
    var modal = opts && opts.modal;
    var openBtn = opts && opts.openBtn;
    var getHtml = opts && opts.getHtml;
    if (!modal || !openBtn) return;
    var codeView = modal.querySelector('[data-code-view]');
    var closeEls = modal.querySelectorAll('[data-close-code]');
    function openModal() {
      modal.classList.add('is-open');
      modal.setAttribute('aria-hidden', 'false');
      if (codeView) {
        var html = (typeof getHtml === 'function') ? (getHtml() || '') : '';
        codeView.textContent = html;
      }
    }
    function closeModal() {
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
    }
    openBtn.addEventListener('click', openModal);
    Array.prototype.slice.call(closeEls).forEach(function (el) { el.addEventListener('click', closeModal); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });
  }

  function getBodyAttrs(doc) {
    if (!doc || !doc.body || !doc.body.attributes) return '';
    var out = [];
    Array.prototype.slice.call(doc.body.attributes).forEach(function (a) {
      if (!a || !a.name) return;
      out.push(a.name + '="' + String(a.value).replace(/"/g, '&quot;') + '"');
    });
    return out.join(' ');
  }

  function getStyleText(doc) {
    if (!doc) return '';
    var css = '';
    var styles = doc.querySelectorAll('style');
    Array.prototype.slice.call(styles).forEach(function (s) { css += s.textContent || ''; });
    return css;
  }

  function buildPreviewSvg(doc, width, height) {
    if (!doc) return '';
    var html = doc.body ? doc.body.innerHTML : '';
    var css = getStyleText(doc);
    var bodyAttrs = getBodyAttrs(doc);
    var wrapperAttrs = bodyAttrs ? ' ' + bodyAttrs : '';
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' + width + '" height="' + height + '">' +
      '<foreignObject width="100%" height="100%">' +
      '<div xmlns="http://www.w3.org/1999/xhtml" style="width:' + width + 'px;height:' + height + 'px;">' +
      '<style>body{margin:0;}' + css + '</style>' +
      '<div' + wrapperAttrs + '>' + html + '</div>' +
      '</div>' +
      '</foreignObject>' +
      '</svg>';
  }

  function downloadIframeImage(frame, filenameBase) {
    if (!frame || !frame.contentDocument) return;
    var doc = frame.contentDocument;
    var rect = frame.getBoundingClientRect();
    var width = Math.max(Math.round(rect.width || 0), 320);
    var height = Math.max(Math.round(rect.height || 0), 200);
    try {
      height = Math.max(doc.body.scrollHeight, doc.documentElement.scrollHeight, height);
    } catch (e) {}
    var svg = buildPreviewSvg(doc, width, height);
    if (!svg) return;
    var svgBlob = new Blob([svg], { type: 'image/svg+xml;charset=utf-8' });
    var svgUrl = URL.createObjectURL(svgBlob);
    var img = new Image();
    img.onload = function () {
      try { URL.revokeObjectURL(svgUrl); } catch (e) {}
      var canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      var ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      canvas.toBlob(function (blob) {
        if (!blob) {
          downloadBlob(svgBlob, (filenameBase || 'component') + '.svg');
          return;
        }
        downloadBlob(blob, (filenameBase || 'component') + '.png');
      }, 'image/png', 0.92);
    };
    img.onerror = function () {
      try { URL.revokeObjectURL(svgUrl); } catch (e) {}
      downloadBlob(svgBlob, (filenameBase || 'component') + '.svg');
    };
    img.src = svgUrl;
  }

  function bindPreviewDownloads(opts) {
    if (!opts) return;
    var desktopBtn = opts.desktopBtn;
    var mobileBtn = opts.mobileBtn;
    var desktopFrame = opts.desktopFrame;
    var mobileFrame = opts.mobileFrame;
    var base = opts.filenameBase || 'component';
    if (desktopBtn && desktopFrame) {
      desktopBtn.addEventListener('click', function () {
        downloadIframeImage(desktopFrame, base + '-desktop');
      });
    }
    if (mobileBtn && mobileFrame) {
      mobileBtn.addEventListener('click', function () {
        downloadIframeImage(mobileFrame, base + '-mobile');
      });
    }
  }

  window.DDReportUtils = {
    downloadBlob: downloadBlob,
    saveDocumentAsHtml: saveDocumentAsHtml,
    bindSaveButton: bindSaveButton,
    bindCodeModal: bindCodeModal,
    bindPreviewDownloads: bindPreviewDownloads,
    applyReportDesignSystem: applyReportDesignSystem,
    syncCollapseArrows: syncCollapseArrows,
    initReportDesignSystem: initReportDesignSystem
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initReportDesignSystem);
  } else {
    initReportDesignSystem();
  }
})();
