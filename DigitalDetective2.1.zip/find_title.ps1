$base = 'C:\Users\camil\OneDrive\Documentos\Profissional\OutSystems2026\Automations\Digital Detective v2.0'
$files = Get-ChildItem -Path "$base\*" -Include '*.js' | Where-Object { $_.Name -notmatch '^(fix_|verify_|inspect_|find_|diagnose_)' }
Write-Host '=== document.title assignments ==='
foreach ($f in $files) {
  $text = [System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::UTF8)
  $lines = $text -split "`n"
  for ($i = 0; $i -lt $lines.Length; $i++) {
    if ($lines[$i] -match 'document\.title') {
      Write-Host "$($f.Name):$($i+1): $($lines[$i].Trim().Substring(0,[Math]::Min(120,$lines[$i].Trim().Length)))"
    }
  }
}
Write-Host ''
Write-Host '=== HTML entities in .js string literals outside innerHTML/insertAdjacentHTML ==='
foreach ($f in $files) {
  $text = [System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::UTF8)
  $lines = $text -split "`n"
  for ($i = 0; $i -lt $lines.Length; $i++) {
    $l = $lines[$i]
    if ($l -match '&(mdash|ndash|hellip|rsquo|lsquo|rdquo|ldquo|bull|middot|copy|reg|deg|ge|amp);' -and $l -notmatch 'innerHTML|insertAdjacentHTML|outerHTML') {
      Write-Host "$($f.Name):$($i+1): $($l.Trim().Substring(0,[Math]::Min(120,$l.Trim().Length)))"
    }
  }
}
