$base = 'C:\Users\camil\OneDrive\Documentos\Profissional\OutSystems2026\Automations\Digital Detective v2.0'
$files = Get-ChildItem -Path "$base\*" -Include @('*.html','*.js') | Where-Object { $_.Name -notmatch '^(fix_encoding|inspect_bytes|verify_encoding)' }
$badCount = 0
foreach ($f in $files) {
  $text = [System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::UTF8)
  $hits = ([regex]::Matches($text, [char]0x00E2)).Count
  if ($hits -gt 0) { Write-Host "STILL CORRUPTED: $($f.Name) -- $hits occurrences of U+00E2"; $badCount++ }
}
if ($badCount -eq 0) { Write-Host 'ALL CLEAN -- no corrupted U+00E2 patterns found' } else { Write-Host "Total files still corrupted: $badCount" }
