(function () {
  'use strict';

  var REPORT_DS_STYLE_ID = 'dd-report-ds-style';
  var REPORT_DS_ARROW_BOUND = 'ddArrowBound';
  var REPORT_SAVE_BOUND = 'ddSaveBound';
  var REPORT_PDF_BOUND = 'ddPdfBound';
  var REPORT_PDF_MIRROR_BOUND = 'ddPdfMirrorBound';

  // ── Encoding artifact rules ────────────────────────────────────────────────
  // Each corrupted pattern is a sequence of Unicode codepoints that result from
  // reading UTF-8 bytes through CP1252, then storing as UTF-8 again.
  // Rule format: [/regex/g, 'correct-replacement']
  var ENCODING_ARTIFACT_RULES = [
    // -- 3-byte sequences (E2 8x/9x/Ax via CP1252) --
    [/\u00E2\u20AC\u201D/g, '\u2014'],    // em-dash  —
    [/\u00E2\u20AC\u201C/g, '\u2013'],    // en-dash  -
    [/\u00E2\u20AC\u00A6/g, '\u2026'],    // ellipsis ...
    [/\u00E2\u20AC\u009C/g, '\u201C'],    // left double quote "
    [/\u00E2\u20AC\u009D/g, '\u201D'],    // right double quote "
    [/\u00E2\u20AC\u02DC/g, '\u2018'],    // left single quote '
    [/\u00E2\u20AC\u2122/g, '\u2019'],    // right single quote '
    [/\u00E2\u20AC\u00A2/g, '\u2022'],    // bullet  *
    [/\u00E2\u201D\u20AC/g, '-'],         // box-drawing ─
    [/\u00E2\u2022\u0090/g, '-'],         // double horizontal ═
    [/\u00E2\u2013\u00B2/g, '\u25B2'],    // triangle up ▲
    [/\u00E2\u2013\u00BC/g, '\u25BC'],    // triangle down ▼
    [/\u00E2\u2020\u2019/g, '\u2192'],    // right arrow ->
    [/\u00E2\u2020\u0090/g, '\u2190'],    // left arrow <-
    [/\u00E2\u2030\u00A5/g, '\u2265'],    // >= sign >=
    // -- 2-byte sequences (C2 Ax via CP1252) --
    [/\u00C2\u00A0/g, '\u00A0'],          // non-breaking space
    [/\u00C2\u00B7/g, '\u00B7'],          // middle dot
    [/\u00C2\u00A9/g, '\u00A9'],          // copyright
    [/\u00C2\u00AE/g, '\u00AE'],          // registered
    [/\u00C2\u00B0/g, '\u00B0'],          // degree
    // -- 3-byte emoji (3-byte UTF-8, all bytes defined in CP1252) --
    [/\u00E2\u0161\u00A0/g, '\u26A0\uFE0F'],  // warning sign + VS16
    [/\u00E2\u0153\u2026/g, '\u2705'],         // check mark button
    [/\u00E2\u2019\u0152/g, '\u274C'],         // cross mark
    [/\u00E2\u0153\u201C/g, '\u2713'],         // check mark
    // -- 4-byte emoji (all 4 bytes defined in CP1252) --
    [/\u00F0\u0178\u0161\u00A8/g, '\uD83D\uDEA8'],  // alert siren
    [/\u00F0\u0178\u201D\u00BA/g, '\uD83D\uDD3A'],  // red triangle up
    [/\u00F0\u0178\u201D\u2014/g, '\uD83D\uDD17'],  // link
    [/\u00F0\u0178\u201C\u0160/g, '\uD83D\uDCCA'],  // bar chart
    [/\u00F0\u0178\u201D\u00B4/g, '\uD83D\uDD34'],  // red circle
    [/\u00F0\u0178\u0178\u00A1/g, '\uD83D\uDFE1'],  // yellow circle
    [/\u00F0\u0178\u2019\u00A1/g, '\uD83D\uDCA1'],  // light bulb
    [/\u00F0\u0178\u00A7\u00A9/g, '\uD83E\uDDE9'],  // puzzle piece
    // -- Orphaned corrupted U+FE0F variation selector (EF B8 8F) --
    [/\u00EF\u00B8\u008F/g, ''],  // remove: &#xFE0F; already written by file fix
    [/\u00EF\u00B8/g, '']         // remove: partial orphan fallback
  ];

  // Sanitize a plain string: fix corrupted UTF-8-via-CP1252 byte sequences.
  function sanitizeEncodingArtifacts(str) {
    if (!str || typeof str !== 'string') return str;
    for (var i = 0; i < ENCODING_ARTIFACT_RULES.length; i++) {
      str = str.replace(ENCODING_ARTIFACT_RULES[i][0], ENCODING_ARTIFACT_RULES[i][1]);
    }
    return str;
  }

  // Decode HTML entity strings that ended up in non-innerHTML contexts
  // (document.title, textContent) where they show as literal text.
  var HTML_ENTITY_MAP = {
    '&mdash;':  '\u2014', '&ndash;':  '\u2013', '&hellip;': '\u2026',
    '&bull;':   '\u2022', '&middot;': '\u00B7', '&lsquo;':  '\u2018',
    '&rsquo;':  '\u2019', '&ldquo;':  '\u201C', '&rdquo;':  '\u201D',
    '&copy;':   '\u00A9', '&reg;':    '\u00AE', '&deg;':    '\u00B0',
    '&nbsp;':   '\u00A0', '&ge;':     '\u2265', '&le;':     '\u2264',
    '&amp;':    '&',      '&lt;':     '<',      '&gt;':     '>'
  };
  function decodeTextEntities(str) {
    if (!str || str.indexOf('&') === -1) return str;
    // Replace named entities
    str = str.replace(/&[a-zA-Z]+;/g, function (m) {
      return HTML_ENTITY_MAP[m] !== undefined ? HTML_ENTITY_MAP[m] : m;
    });
    // Replace numeric hex entities: &#x1F534; -> codepoint
    str = str.replace(/&#x([0-9a-fA-F]+);/g, function (m, hex) {
      try { return String.fromCodePoint(parseInt(hex, 16)); } catch (e) { return m; }
    });
    // Replace numeric decimal entities: &#8212; -> codepoint
    str = str.replace(/&#(\d+);/g, function (m, dec) {
      try { return String.fromCodePoint(parseInt(dec, 10)); } catch (e) { return m; }
    });
    return str;
  }

  // Full string sanitizer: fix corrupted bytes AND literal HTML entities.
  function sanitizeStr(str) {
    return decodeTextEntities(sanitizeEncodingArtifacts(str));
  }

  // Walk all text nodes + key attributes under root and fix encoding artifacts.
  function fixDomEncoding(root) {
    if (!root || typeof document === 'undefined') return;
    // Fix document title separately (it is not a regular text node)
    if (document.title) {
      var fixedTitle = sanitizeStr(document.title);
      if (fixedTitle !== document.title) document.title = fixedTitle;
    }
    // Walk text nodes
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false);
    var node;
    while ((node = walker.nextNode())) {
      var v = node.nodeValue;
      if (!v) continue;
      var fixed = sanitizeStr(v);
      if (fixed !== v) node.nodeValue = fixed;
    }
    // Fix key attributes
    if (root.querySelectorAll) {
      var attrs = ['title', 'alt', 'placeholder', 'aria-label', 'data-tooltip'];
      var els = root.querySelectorAll('[title],[alt],[placeholder],[aria-label],[data-tooltip]');
      for (var j = 0; j < els.length; j++) {
        for (var k = 0; k < attrs.length; k++) {
          var val = els[j].getAttribute(attrs[k]);
          if (!val) continue;
          var fixedVal = sanitizeStr(val);
          if (fixedVal !== val) els[j].setAttribute(attrs[k], fixedVal);
        }
      }
    }
  }

  // ── Design System ──────────────────────────────────────────────────────────
  function getReportDesignSystemCss() {
    return '' +
      ':root{' +
      '--dd-ds-bg:#F2F5F0;' +
      '--dd-ds-surface:#ffffff;' +
      '--dd-ds-surface-soft:#f8fafc;' +
      '--dd-ds-accent:#DD1234;' +
      '--dd-ds-text:#1c1c1c;' +
      '--dd-ds-muted:#4a4a4a;' +
      '--dd-ds-line:#c7ccd1;' +
      '--dd-ds-radius-sm:10px;' +
      '--dd-ds-radius-md:14px;' +
      '--dd-ds-radius-lg:16px;' +
      '--dd-ds-space-1:4px;' +
      '--dd-ds-space-2:8px;' +
      '--dd-ds-space-3:12px;' +
      '--dd-ds-space-4:16px;' +
      '--dd-ds-space-5:20px;' +
      '--dd-ds-space-6:24px;' +
      '--dd-ds-space-7:32px;' +
      '--dd-ds-shadow-sm:0 3px 12px rgba(10,10,10,0.266);' +
      '}' +
      'html,body{background:var(--dd-ds-bg)!important;color:var(--dd-ds-text)!important;font-family:"Noto Sans",sans-serif!important;}' +
      '#seo-root,#lhr-root,#aeo-root,#ma-root,.page,.dd-container{max-width:960px;margin:0 auto;padding:24px 20px 64px 20px;}' +
      '.ma-page{max-width:none!important;margin:0!important;padding:0!important;}' +
      '.seo-header,.lhr-header,.aeo-header,.ma-header,.app-header,.header,.dd-header{border-bottom:1px solid var(--dd-ds-line)!important;padding-bottom:18px!important;margin-bottom:24px!important;}' +
      '.seo-url-link,.lhr-url-link,.aeo-url,.ma-url-link,.app-url,.report-url-link,.dd-report-url a{color:var(--dd-ds-accent)!important;}' +
      '.seo-btn,.lhr-btn,.aeo-btn,.ma-save-btn,.ma-reload-btn,.ma-preview-btn,.sm-save-btn,.header-btn,.primary-btn,.ghost-btn,.dd-btn,.btn,.modal-close,.panel-toggle,.panel-collapse-btn,.ma-collapse-btn,.seo-section-toggle,.lhr-section-toggle,.aeo-section-toggle,.preview-btn,.asset-btn,.edit-btn,.dd-pdf-btn{border-radius:999px!important;font-size:11px!important;font-weight:700!important;padding:8px 16px!important;line-height:1.2!important;}' +
      '.panel-toggle,.panel-collapse-btn,.ma-collapse-btn,.seo-section-toggle,.lhr-section-toggle,.aeo-section-toggle{padding:0!important;width:24px!important;height:24px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;}' +
      '.seo-btn.primary,.lhr-btn.primary,.aeo-btn.primary,.ma-save-btn,.primary-btn,.dd-btn.primary,.btn:not(.ghost),#saveReport{background:var(--dd-ds-accent)!important;color:#fff!important;border:none!important;}' +
      '.dd-pdf-btn{background:#168A3A!important;color:#fff!important;border:none!important;}' +
      '.dd-pdf-btn:hover{background:#0F6F2E!important;color:#fff!important;}' +
      '.dd-pdf-btn[disabled]{opacity:.48!important;cursor:not-allowed!important;}' +
      '.seo-btn:not(.primary),.lhr-btn:not(.primary),.aeo-btn:not(.primary),.ma-reload-btn,.ma-preview-btn,.header-btn:not(.primary),.ghost-btn,.dd-btn:not(.primary),.btn.ghost,.modal-close,.preview-btn,.asset-btn,.edit-btn,.panel-toggle,.panel-collapse-btn,.ma-collapse-btn,.seo-section-toggle,.lhr-section-toggle,.aeo-section-toggle{background:#fff!important;color:var(--dd-ds-text)!important;border:1px solid var(--dd-ds-line)!important;}' +
      '.seo-btn:not(.primary):hover,.lhr-btn:not(.primary):hover,.aeo-btn:not(.primary):hover,.ma-reload-btn:hover,.ma-preview-btn:hover,.header-btn:not(.primary):hover,.ghost-btn:hover,.dd-btn:not(.primary):hover,.btn.ghost:hover,.modal-close:hover,.preview-btn:hover,.asset-btn:hover,.edit-btn:hover,.panel-toggle:hover,.panel-collapse-btn:hover,.ma-collapse-btn:hover,.seo-section-toggle:hover,.lhr-section-toggle:hover,.aeo-section-toggle:hover{background:#DEE2E6!important;}' +
      '.seo-summary-card,.seo-pillars-card,.seo-section,.seo-success-banner,.aeo-summary-card,.aeo-card,.aeo-section,.lhr-score-card,.lhr-section,.ma-score-card,.ma-block,.ma-loading-box,.panel,.card,.scope-card,.status,.modal-content,.preview-box,.asset,.copy-item{background:var(--dd-ds-surface)!important;border:none!important;border-radius:var(--dd-ds-radius-md)!important;box-shadow:var(--dd-ds-shadow-sm)!important;}' +
      '.seo-section-head,.lhr-section-head,.aeo-section-head,.ma-block-head,.panel-head{background:var(--dd-ds-surface)!important;border-bottom:1px solid var(--dd-ds-line)!important;padding:14px 20px!important;}' +
      '.seo-section-body,.lhr-section-body,.aeo-section-body,.panel-content,.panel-body{padding:16px 20px!important;}' +
      '.ma-col,.lhr-col,.seo-check-item,.aeo-check-item,.lhr-audit-item,.ma-row{border-bottom:1px solid var(--dd-ds-line)!important;}' +
      '.ma-col:last-child,.seo-check-item:last-child,.aeo-check-item:last-child,.lhr-audit-item:last-child,.ma-row:last-child{border-bottom:none!important;}' +
      '.seo-footer,.lhr-footer,.aeo-footer,.ma-footer,.app-footer{margin-top:32px!important;padding-top:16px!important;border-top:1px solid var(--dd-ds-line)!important;font-size:10px!important;color:#7a7f86!important;text-align:center!important;}' +
      '.app-footer{position:static!important;background:transparent!important;}' +
      '.shell .status{max-width:420px;margin:0 auto;}' +
      '@media print{' +
      '@page{size:auto;margin:12mm;}' +
      'html,body{background:#fff!important;color:#111!important;}' +
      '#seo-root,#lhr-root,#aeo-root,#ma-root,.page,.dd-container,.sm-page{max-width:none!important;width:auto!important;margin:0!important;padding:0!important;}' +
      '.seo-header-btns,.lhr-header-btns,.aeo-header-btns,.ma-header-btns,.app-header-btns,.dd-header-actions,.dd-header-btns,.header-btns,.sm-header-btns,#seo-loading,#lhr-loading,#aeo-loading,#sm-loading,#qa-progress,.dd-status,.modal{display:none!important;}' +
      '.seo-summary-card,.seo-pillars-card,.seo-section,.seo-success-banner,.aeo-summary-card,.aeo-card,.aeo-section,.lhr-score-card,.lhr-section,.ma-score-card,.ma-block,.ma-loading-box,.panel,.card,.scope-card,.status,.preview-box,.asset,.copy-item{box-shadow:none!important;border:1px solid #ddd!important;break-inside:avoid-page!important;page-break-inside:avoid!important;}' +
      '.ma-score-card{position:static!important;top:auto!important;}' +
      '.seo-section-body,.lhr-section-body,.aeo-section-body,.panel-content,.panel-body,.dd-section-body,.ma-block-body,.ma-two-col,.ma-infra-note{display:block!important;max-height:none!important;height:auto!important;overflow:visible!important;visibility:visible!important;opacity:1!important;}' +
      '.seo-collapsed .seo-section-body,.lhr-collapsed .lhr-section-body,.aeo-collapsed .aeo-section-body,.is-collapsed .panel-body,.is-collapsed .dd-section-body,.ma-collapsed .ma-block-body,.ma-collapsed .ma-two-col,.ma-collapsed .ma-infra-note{display:block!important;max-height:none!important;height:auto!important;overflow:visible!important;visibility:visible!important;opacity:1!important;}' +
      'a{color:#111!important;text-decoration:none!important;}' +
      '}' +
      '@media (max-width:900px){.seo-summary-card,.lhr-score-card,.aeo-summary-card,.ma-score-card{padding:16px!important;}.lhr-score-card,.ma-two-col,.lhr-two-col{grid-template-columns:1fr!important;display:grid!important;}.lhr-score-half+.lhr-score-half,.ma-col:first-child{border-left:none!important;border-right:none!important;padding-left:0!important;}}';
  }

  function applyReportDesignSystem() {
    if (!document || !document.head) return;
    if (document.getElementById(REPORT_DS_STYLE_ID)) return;
    var styleEl = document.createElement('style');
    styleEl.id = REPORT_DS_STYLE_ID;
    styleEl.textContent = getReportDesignSystemCss();
    document.head.appendChild(styleEl);
  }

  function setArrowForButton(btn, section, collapsedClass) {
    if (!btn || !section) return;
    var collapsed = section.classList.contains(collapsedClass);
    var nextArrow = collapsed ? '\u25BC' : '\u25B2';
    var nextLabel = collapsed ? 'Expand section' : 'Collapse section';
    if (btn.textContent !== nextArrow) btn.textContent = nextArrow;
    if (btn.getAttribute('aria-label') !== nextLabel) btn.setAttribute('aria-label', nextLabel);
  }

  function bindArrowButtons(selector, sectionSelector, collapsedClass) {
    var buttons = document.querySelectorAll(selector);
    Array.prototype.slice.call(buttons).forEach(function (btn) {
      var section = btn.closest(sectionSelector);
      if (!section) return;
      setArrowForButton(btn, section, collapsedClass);
      if (btn.dataset && btn.dataset[REPORT_DS_ARROW_BOUND]) return;
      if (btn.dataset) btn.dataset[REPORT_DS_ARROW_BOUND] = '1';
      btn.addEventListener('click', function () {
        setTimeout(function () { setArrowForButton(btn, section, collapsedClass); }, 0);
      });
    });
  }

  function syncCollapseArrows() {
    bindArrowButtons('.seo-section-toggle', '.seo-section', 'seo-collapsed');
    bindArrowButtons('.lhr-section-toggle', '.lhr-section', 'lhr-collapsed');
    bindArrowButtons('.aeo-section-toggle', '.aeo-section', 'aeo-collapsed');
    bindArrowButtons('.ma-collapse-btn', '.ma-block', 'ma-collapsed');
    bindArrowButtons('.panel-toggle', '.panel', 'is-collapsed');
    bindArrowButtons('.dd-section-toggle', '.dd-section', 'is-collapsed');
    bindArrowButtons('.panel-collapse-btn', '.panel', 'is-collapsed');
  }

  function initReportDesignSystem() {
    applyReportDesignSystem();
    syncCollapseArrows();
    // First encoding pass: fix static HTML already in the DOM
    fixDomEncoding(document.body);
    setTimeout(syncCollapseArrows, 80);
    setTimeout(syncCollapseArrows, 300);
    // Second encoding pass: catch content rendered by JS after DOMContentLoaded
    setTimeout(function () { fixDomEncoding(document.body); }, 150);
    // Third pass: late safety net for any async-rendered content
    setTimeout(function () { fixDomEncoding(document.body); }, 800);

    if (!document || !document.body || window.__ddDsObserverActive || typeof MutationObserver === 'undefined') return;
    window.__ddDsObserverActive = true;

    var scheduled = false;
    var syncing = false;
    function scheduleSync() {
      if (scheduled) return;
      scheduled = true;
      setTimeout(function () {
        scheduled = false;
        if (syncing) return;
        syncing = true;
        try {
          syncCollapseArrows();
          fixDomEncoding(document.body);
        } finally {
          syncing = false;
        }
      }, 0);
    }

    var obs = new MutationObserver(function () {
      scheduleSync();
    });
    obs.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  // ── Download / Save utilities ──────────────────────────────────────────────
  function downloadBlob(blob, filename) {
    if (!blob) return;
    try {
      var blobUrl = URL.createObjectURL(blob);
      if (typeof chrome !== 'undefined' && chrome.downloads && chrome.downloads.download) {
        chrome.downloads.download({ url: blobUrl, filename: filename || '', saveAs: true }, function () {
          setTimeout(function () { try { URL.revokeObjectURL(blobUrl); } catch (e) {} }, 10000);
        });
        return;
      }
      var a = document.createElement('a');
      a.href = blobUrl;
      if (filename) a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { try { URL.revokeObjectURL(blobUrl); } catch (e) {} }, 10000);
    } catch (e2) {}
  }

  function filenameWithoutHtmlExtension(filename) {
    var name = String(filename || '').trim() || 'report.html';
    return name.replace(/\.html?$/i, '');
  }

  function getPdfFilename(filename) {
    var name = filenameWithoutHtmlExtension(filename || document.title || 'report');
    if (!name) name = 'report';
    return name.replace(/\.pdf$/i, '') + '.pdf';
  }

  function saveDocumentAsHtml(filename) {
    var html = '<!doctype html>\n' + document.documentElement.outerHTML;
    var blob = new Blob([html], { type: 'text/html' });
    if (typeof chrome !== 'undefined' && chrome.downloads && chrome.downloads.download) {
      downloadBlob(blob, filename || 'report.html');
      return;
    }
    if (window.showSaveFilePicker) {
      window.showSaveFilePicker({
        suggestedName: filename || 'report.html',
        types: [{ description: 'HTML', accept: { 'text/html': ['.html'] } }]
      }).then(function (handle) {
        return handle.createWritable().then(function (writable) {
          return writable.write(blob).then(function () { return writable.close(); });
        });
      }).catch(function () { downloadBlob(blob, filename || 'report.html'); });
      return;
    }
    downloadBlob(blob, filename || 'report.html');
  }

  function expandReportForPdf() {
    var classNames = [
      'seo-collapsed',
      'lhr-collapsed',
      'aeo-collapsed',
      'ma-collapsed',
      'is-collapsed'
    ];
    classNames.forEach(function (className) {
      var nodes = document.querySelectorAll('.' + className);
      Array.prototype.slice.call(nodes).forEach(function (node) {
        node.classList.remove(className);
      });
    });

    var arrowSelectors = [
      '.seo-section-toggle',
      '.lhr-section-toggle',
      '.aeo-section-toggle',
      '.ma-collapse-btn',
      '.panel-toggle',
      '.panel-collapse-btn',
      '.dd-section-toggle'
    ];
    arrowSelectors.forEach(function (selector) {
      Array.prototype.slice.call(document.querySelectorAll(selector)).forEach(function (btn) {
        btn.textContent = '\u25B2';
        btn.setAttribute('aria-label', 'Collapse section');
      });
    });
  }

  function saveDocumentAsPdf(filename) {
    var previousTitle = document.title;
    var pdfName = getPdfFilename(filename || previousTitle || 'report.pdf');
    var restoredTitle = false;

    function restoreTitle() {
      if (restoredTitle) return;
      restoredTitle = true;
      try { document.title = previousTitle; } catch (e) {}
      try { window.removeEventListener('afterprint', restoreTitle); } catch (e2) {}
    }

    expandReportForPdf();

    try {
      document.title = pdfName;
    } catch (e) {}

    try { window.addEventListener('afterprint', restoreTitle); } catch (e3) {}

    setTimeout(function () {
      try {
        window.print();
      } finally {
        setTimeout(restoreTitle, 15000);
      }
    }, 80);
  }

  function bindPdfButton(btn, filename) {
    if (!btn) return;
    if (btn.dataset) btn.dataset.ddPdfFilename = filename || 'report.html';
    if (btn.dataset && btn.dataset[REPORT_PDF_BOUND]) return;
    if (btn.dataset) btn.dataset[REPORT_PDF_BOUND] = '1';
    btn.addEventListener('click', function () {
      if (btn.disabled) return;
      var name = btn.dataset ? (btn.dataset.ddPdfFilename || filename) : filename;
      saveDocumentAsPdf(name || 'report.html');
    });
  }

  function mirrorDisabledState(sourceBtn, targetBtn) {
    if (!sourceBtn || !targetBtn) return;
    function sync() {
      targetBtn.disabled = !!sourceBtn.disabled;
      if (sourceBtn.disabled) {
        targetBtn.setAttribute('disabled', 'disabled');
      } else {
        targetBtn.removeAttribute('disabled');
      }
    }
    sync();
    if (targetBtn.dataset && targetBtn.dataset[REPORT_PDF_MIRROR_BOUND]) return;
    if (targetBtn.dataset) targetBtn.dataset[REPORT_PDF_MIRROR_BOUND] = '1';
    if (typeof MutationObserver !== 'undefined') {
      var obs = new MutationObserver(sync);
      obs.observe(sourceBtn, { attributes: true, attributeFilter: ['disabled'] });
    }
  }

  function ensurePdfButton(saveBtn, filename) {
    if (!saveBtn || !saveBtn.parentNode) return null;

    var pdfBtn = null;
    var next = saveBtn.nextElementSibling;
    if (next && next.classList && next.classList.contains('dd-pdf-btn')) {
      pdfBtn = next;
    }

    if (!pdfBtn && saveBtn.dataset && saveBtn.dataset.ddPdfButtonId) {
      pdfBtn = document.getElementById(saveBtn.dataset.ddPdfButtonId);
    }

    if (!pdfBtn) {
      pdfBtn = document.createElement('button');
      pdfBtn.type = 'button';
      pdfBtn.textContent = 'SAVE PDF';
      pdfBtn.className = (saveBtn.className ? saveBtn.className + ' ' : '') + 'dd-pdf-btn';
      pdfBtn.setAttribute('aria-label', 'Save report as PDF');
      var id = 'dd-pdf-btn-' + Math.random().toString(36).slice(2, 10);
      pdfBtn.id = id;
      if (saveBtn.dataset) saveBtn.dataset.ddPdfButtonId = id;
      saveBtn.parentNode.insertBefore(pdfBtn, saveBtn.nextSibling);
    }

    bindPdfButton(pdfBtn, filename || 'report.html');
    mirrorDisabledState(saveBtn, pdfBtn);
    return pdfBtn;
  }

  function bindSaveButton(btn, filename) {
    if (!btn) return;
    if (btn.dataset) btn.dataset.ddSaveFilename = filename || 'report.html';
    if (!btn.dataset || !btn.dataset[REPORT_SAVE_BOUND]) {
      if (btn.dataset) btn.dataset[REPORT_SAVE_BOUND] = '1';
      btn.addEventListener('click', function () {
        var name = btn.dataset ? (btn.dataset.ddSaveFilename || filename) : filename;
        saveDocumentAsHtml(name || 'report.html');
      });
    }
    ensurePdfButton(btn, filename || 'report.html');
  }

  function bindCodeModal(opts) {
    var modal = opts && opts.modal;
    var openBtn = opts && opts.openBtn;
    var getHtml = opts && opts.getHtml;
    if (!modal || !openBtn) return;
    var codeView = modal.querySelector('[data-code-view]');
    var closeEls = modal.querySelectorAll('[data-close-code]');
    function openModal() {
      modal.classList.add('is-open');
      modal.setAttribute('aria-hidden', 'false');
      if (codeView) {
        var html = (typeof getHtml === 'function') ? (getHtml() || '') : '';
        codeView.textContent = html;
      }
    }
    function closeModal() {
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
    }
    openBtn.addEventListener('click', openModal);
    Array.prototype.slice.call(closeEls).forEach(function (el) { el.addEventListener('click', closeModal); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });
  }

  function getBodyAttrs(doc) {
    if (!doc || !doc.body || !doc.body.attributes) return '';
    var out = [];
    Array.prototype.slice.call(doc.body.attributes).forEach(function (a) {
      if (!a || !a.name) return;
      out.push(a.name + '="' + String(a.value).replace(/"/g, '&quot;') + '"');
    });
    return out.join(' ');
  }

  function getStyleText(doc) {
    if (!doc) return '';
    var css = '';
    var styles = doc.querySelectorAll('style');
    Array.prototype.slice.call(styles).forEach(function (s) { css += s.textContent || ''; });
    return css;
  }

  function buildPreviewSvg(doc, width, height) {
    if (!doc) return '';
    var html = doc.body ? doc.body.innerHTML : '';
    var css = getStyleText(doc);
    var bodyAttrs = getBodyAttrs(doc);
    var wrapperAttrs = bodyAttrs ? ' ' + bodyAttrs : '';
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' + width + '" height="' + height + '">' +
      '<foreignObject width="100%" height="100%">' +
      '<div xmlns="http://www.w3.org/1999/xhtml" style="width:' + width + 'px;height:' + height + 'px;">' +
      '<style>body{margin:0;}' + css + '</style>' +
      '<div' + wrapperAttrs + '>' + html + '</div>' +
      '</div>' +
      '</foreignObject>' +
      '</svg>';
  }

  function downloadIframeImage(frame, filenameBase) {
    if (!frame || !frame.contentDocument) return;
    var doc = frame.contentDocument;
    var rect = frame.getBoundingClientRect();
    var width = Math.max(Math.round(rect.width || 0), 320);
    var height = Math.max(Math.round(rect.height || 0), 200);
    try {
      height = Math.max(doc.body.scrollHeight, doc.documentElement.scrollHeight, height);
    } catch (e) {}
    var svg = buildPreviewSvg(doc, width, height);
    if (!svg) return;
    var svgBlob = new Blob([svg], { type: 'image/svg+xml;charset=utf-8' });
    var svgUrl = URL.createObjectURL(svgBlob);
    var img = new Image();
    img.onload = function () {
      try { URL.revokeObjectURL(svgUrl); } catch (e) {}
      var canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      var ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      canvas.toBlob(function (blob) {
        if (!blob) {
          downloadBlob(svgBlob, (filenameBase || 'component') + '.svg');
          return;
        }
        downloadBlob(blob, (filenameBase || 'component') + '.png');
      }, 'image/png', 0.92);
    };
    img.onerror = function () {
      try { URL.revokeObjectURL(svgUrl); } catch (e) {}
      downloadBlob(svgBlob, (filenameBase || 'component') + '.svg');
    };
    img.src = svgUrl;
  }

  function bindPreviewDownloads(opts) {
    if (!opts) return;
    var desktopBtn = opts.desktopBtn;
    var mobileBtn = opts.mobileBtn;
    var desktopFrame = opts.desktopFrame;
    var mobileFrame = opts.mobileFrame;
    var base = opts.filenameBase || 'component';
    if (desktopBtn && desktopFrame) {
      desktopBtn.addEventListener('click', function () {
        downloadIframeImage(desktopFrame, base + '-desktop');
      });
    }
    if (mobileBtn && mobileFrame) {
      mobileBtn.addEventListener('click', function () {
        downloadIframeImage(mobileFrame, base + '-mobile');
      });
    }
  }

  window.DDReportUtils = {
    downloadBlob: downloadBlob,
    saveDocumentAsHtml: saveDocumentAsHtml,
    saveDocumentAsPdf: saveDocumentAsPdf,
    bindSaveButton: bindSaveButton,
    bindPdfButton: bindPdfButton,
    ensurePdfButton: ensurePdfButton,
    bindCodeModal: bindCodeModal,
    bindPreviewDownloads: bindPreviewDownloads,
    applyReportDesignSystem: applyReportDesignSystem,
    syncCollapseArrows: syncCollapseArrows,
    initReportDesignSystem: initReportDesignSystem,
    sanitizeEncodingArtifacts: sanitizeEncodingArtifacts,
    decodeTextEntities: decodeTextEntities,
    sanitizeStr: sanitizeStr,
    fixDomEncoding: fixDomEncoding
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initReportDesignSystem);
  } else {
    initReportDesignSystem();
  }
})();
