(function () {
  'use strict';

  var params = new URLSearchParams(location.search);
  var sourceTabId = parseInt(params.get('tabId') || '0', 10) || 0;
  var sourceUrl = params.get('url') || '';
  var runProbe = params.get('probe') !== '0';

  var subtitleEl = document.getElementById('qa-subtitle');
  var statusEl = document.getElementById('qa-status');
  var rootEl = document.getElementById('qa-root');
  var bannerEl = document.getElementById('qa-banner');
  var openSourceBtn = document.getElementById('qa-open-source');
  var rerunBtn = document.getElementById('qa-rerun');
  var saveBtn = document.getElementById('qa-save');
  var progressWrap = document.getElementById('qa-progress');
  var progressLabelEl = document.getElementById('qa-progress-label');
  var progressValueEl = document.getElementById('qa-progress-value');
  var progressBarEl = document.getElementById('qa-progress-bar');

  function esc(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function setStatus(message, type) {
    if (!statusEl) return;
    statusEl.textContent = message || '';
    statusEl.className = 'dd-status' + (message ? ' is-active' : '') + (type ? (' is-' + type) : '');
  }

  function setSubtitle(message) {
    if (subtitleEl) subtitleEl.textContent = message || '';
  }

  function setProgress(percent, label, state) {
    if (!progressWrap || !progressLabelEl || !progressValueEl || !progressBarEl) return;
    var safePercent = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
    progressWrap.className = 'qa-progress is-active' + (state ? (' is-' + state) : '');
    progressLabelEl.textContent = label || 'Working...';
    progressValueEl.textContent = safePercent + '%';
    progressBarEl.style.width = safePercent + '%';
  }

  function formatDate(ts) {
    try {
      return new Date(ts).toLocaleString();
    } catch (e) {
      return String(ts || '');
    }
  }

  function formatScoreState(score) {
    if (score >= 85) return 'ok';
    if (score >= 65) return 'warn';
    return 'fail';
  }

  function describeScore(score) {
    if (score >= 85) {
      return {
        label: 'Good',
        summary: 'The page looks healthy in this QA pass.'
      };
    }
    if (score >= 65) {
      return {
        label: 'Needs Review',
        summary: 'The page works, but there are enough issues to justify review.'
      };
    }
    return {
      label: 'Poor',
      summary: 'The page has enough issues to be considered risky in this QA pass.'
    };
  }

  function sectionStatusLabel(failCount) {
    return failCount > 0 ? 'Needs Review' : 'Good';
  }

  function buildSectionTitle(baseTitle, parts) {
    return baseTitle + ' - ' + parts.join(', ');
  }

  function makeRuntimeMessage(err) {
    if (!err) return 'Unexpected error';
    if (typeof err === 'string') return err;
    if (err && typeof err.message === 'string') return err.message;
    return String(err);
  }

  function dedupeByUrl(list, limit) {
    var out = [];
    var seen = {};
    (Array.isArray(list) ? list : []).forEach(function (item) {
      if (!item || !item.url) return;
      var key = String(item.type || 'asset') + '|' + String(item.url || '');
      if (seen[key]) return;
      seen[key] = true;
      if (out.length < (limit || 120)) out.push(item);
    });
    return out;
  }

  function sendToTab(tabId, payload) {
    return new Promise(function (resolve) {
      chrome.tabs.sendMessage(tabId, payload, function (resp) {
        if (!chrome.runtime.lastError) {
          resolve(resp || { ok: false, error: 'No response' });
          return;
        }
        chrome.scripting.executeScript(
          { target: { tabId: tabId }, files: ['content.js'] },
          function () {
            if (chrome.runtime.lastError) {
              resolve({ ok: false, error: chrome.runtime.lastError.message || 'Cannot inject on this page.' });
              return;
            }
            chrome.tabs.sendMessage(tabId, payload, function (resp2) {
              resolve(resp2 || { ok: false, error: 'No response' });
            });
          }
        );
      });
    });
  }

  function sendRuntimeMessage(payload) {
    return new Promise(function (resolve) {
      chrome.runtime.sendMessage(payload, function (resp) {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message || 'Runtime request failed' });
          return;
        }
        resolve(resp || { ok: false, error: 'No response' });
      });
    });
  }

  function getSourceTab(tabId) {
    return new Promise(function (resolve) {
      chrome.tabs.get(tabId, function (tab) {
        if (chrome.runtime.lastError) {
          resolve(null);
          return;
        }
        resolve(tab || null);
      });
    });
  }

  function ensureQaBridgeInMainWorld(tabId) {
    return new Promise(function (resolve) {
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        world: 'MAIN',
        func: function () {
          if (window.__ddQaBridgeInstalled) return true;
          window.__ddQaBridgeInstalled = true;

          function emit(kind, payload) {
            try {
              window.postMessage({
                source: 'dd-qa-monitor',
                kind: kind,
                payload: payload || {},
                ts: Date.now()
              }, '*');
            } catch (e) {}
          }

          var originalError = console.error;
          console.error = function () {
            var args = Array.prototype.slice.call(arguments || []).map(function (item) {
              if (typeof item === 'string') return item;
              if (item && typeof item.message === 'string') return item.message;
              try { return JSON.stringify(item); } catch (e) { return String(item); }
            });
            emit('console_error', { message: args.join(' | ').slice(0, 600) });
            return originalError.apply(this, arguments);
          };

          window.addEventListener('error', function (evt) {
            var target = evt && evt.target && evt.target !== window ? evt.target : null;
            if (target && target.tagName) {
              emit('resource_error', {
                tag: String(target.tagName || '').toLowerCase(),
                url: target.currentSrc || target.src || target.href || target.data || '',
                message: 'Resource failed to load'
              });
              return;
            }
            emit('runtime_error', {
              message: (evt && evt.message) || 'Runtime error',
              filename: (evt && evt.filename) || '',
              lineno: (evt && evt.lineno) || 0,
              colno: (evt && evt.colno) || 0
            });
          }, true);

          window.addEventListener('unhandledrejection', function (evt) {
            var reason = evt ? evt.reason : null;
            emit('unhandled_rejection', {
              message: (reason && reason.message) || String(reason || 'Unhandled promise rejection')
            });
          });

          return true;
        }
      }, function () {
        resolve(!chrome.runtime.lastError);
      });
    });
  }

  function buildAssetProbeList(snapshot) {
    var assets = [];

    (snapshot.images || []).forEach(function (item) {
      if (!item || !item.src) return;
      assets.push({ url: item.src, type: 'image', label: item.alt || '' });
    });
    (snapshot.scripts || []).forEach(function (item) {
      if (!item || !item.src) return;
      assets.push({ url: item.src, type: 'script', label: item.vendor || '' });
    });
    (snapshot.stylesheets || []).forEach(function (item) {
      if (!item || !item.href) return;
      assets.push({ url: item.href, type: 'stylesheet', label: item.media || '' });
    });

    return dedupeByUrl(assets, 150);
  }

  function createAssetIndex(results) {
    var map = {};
    (Array.isArray(results) ? results : []).forEach(function (item) {
      if (!item || !item.url) return;
      map[String(item.type || 'asset') + '|' + String(item.url)] = item;
    });
    return map;
  }

  async function probeAssetsWithProgress(assets) {
    var queue = Array.isArray(assets) ? assets : [];
    var results = [];
    if (!queue.length) {
      setProgress(88, 'No assets to probe.', '');
      return results;
    }

    var batchSize = 12;
    for (var i = 0; i < queue.length; i += batchSize) {
      var batch = queue.slice(i, i + batchSize);
      var probeResp = await sendRuntimeMessage({ action: 'qa_probe_assets', assets: batch });
      if (probeResp && Array.isArray(probeResp.results)) {
        results = results.concat(probeResp.results);
      }

      var processed = Math.min(i + batch.length, queue.length);
      var ratio = processed / queue.length;
      setProgress(
        45 + Math.round(ratio * 43),
        'Probing referenced assets ' + processed + '/' + queue.length + '...',
        ''
      );
    }

    return results;
  }

  function collectFindings(snapshot, interactions, assetResults) {
    var assetIndex = createAssetIndex(assetResults);
    var assetFailures = [];

    (snapshot.images || []).forEach(function (img) {
      if (!img || !img.src) return;
      var probe = assetIndex['image|' + img.src];
      if (img.broken) {
        assetFailures.push({
          type: 'image',
          url: img.src,
          reason: 'Image is present in the DOM but failed to render.'
        });
        return;
      }
      if (probe && (!probe.ok || probe.status >= 400)) {
        assetFailures.push({
          type: 'image',
          url: img.src,
          reason: probe.error || ('HTTP ' + probe.status)
        });
      }
    });

    (snapshot.scripts || []).forEach(function (script) {
      if (!script || !script.src) return;
      var probe = assetIndex['script|' + script.src];
      if (probe && (!probe.ok || probe.status >= 400)) {
        assetFailures.push({
          type: 'script',
          url: script.src,
          reason: probe.error || ('HTTP ' + probe.status)
        });
      }
    });

    (snapshot.stylesheets || []).forEach(function (sheet) {
      if (!sheet || !sheet.href) return;
      var probe = assetIndex['stylesheet|' + sheet.href];
      if (probe && (!probe.ok || probe.status >= 400)) {
        assetFailures.push({
          type: 'stylesheet',
          url: sheet.href,
          reason: probe.error || ('HTTP ' + probe.status)
        });
      }
    });

    var qaEvents = Array.isArray(snapshot.qaEvents) ? snapshot.qaEvents : [];
    var consoleErrors = qaEvents.filter(function (item) { return item.kind === 'console_error'; });
    var runtimeErrors = qaEvents.filter(function (item) { return item.kind === 'runtime_error' || item.kind === 'unhandled_rejection'; });
    var resourceErrors = qaEvents.filter(function (item) { return item.kind === 'resource_error'; });

    var suspiciousLinks = (snapshot.links || []).filter(function (item) {
      return item && (item.isJavascript || !item.hasText);
    });

    var suspiciousButtons = (snapshot.buttons || []).filter(function (item) {
      return item && item.suspicious;
    });

    var formIssues = (snapshot.forms || []).filter(function (item) {
      return item && (item.unlabeledCount > 0 || item.invalidCount > 0 || (item.fieldCount > 0 && item.submitCount === 0));
    });

    var interactionIssues = (Array.isArray(interactions) ? interactions : []).filter(function (item) {
      return item && (item.error || item.newEvents > 0);
    });

    var penalty = 0;
    penalty += Math.min(assetFailures.length * 12, 30);
    penalty += Math.min(runtimeErrors.length * 15, 30);
    penalty += Math.min(consoleErrors.length * 8, 16);
    penalty += Math.min(formIssues.length * 5, 12);
    penalty += Math.min(suspiciousLinks.length * 2, 6);
    penalty += Math.min(interactionIssues.length * 5, 10);

    var score = Math.max(0, 100 - penalty);

    return {
      score: score,
      scoreState: formatScoreState(score),
      assetFailures: assetFailures.slice(0, 30),
      runtimeErrors: runtimeErrors.slice(0, 30),
      consoleErrors: consoleErrors.slice(0, 20),
      resourceErrors: resourceErrors.slice(0, 30),
      suspiciousLinks: suspiciousLinks.slice(0, 20),
      suspiciousButtons: suspiciousButtons.slice(0, 20),
      formIssues: formIssues.slice(0, 20),
      interactionIssues: interactionIssues.slice(0, 20)
    };
  }

  function bindSectionToggles() {
    Array.prototype.slice.call(document.querySelectorAll('.dd-section-toggle')).forEach(function (btn) {
      if (btn.dataset.bound === '1') return;
      btn.dataset.bound = '1';
      btn.addEventListener('click', function () {
        var section = btn.closest('.dd-section');
        if (!section) return;
        section.classList.toggle('is-collapsed');
        if (window.DDReportUtils && window.DDReportUtils.syncCollapseArrows) {
          window.DDReportUtils.syncCollapseArrows();
        }
      });
    });
  }

  function openReportSection(sectionId) {
    if (!sectionId) return;
    var section = document.querySelector('.dd-section[data-section-id="' + sectionId + '"]');
    if (!section) return;
    section.classList.remove('is-collapsed');
    if (window.DDReportUtils && window.DDReportUtils.syncCollapseArrows) {
      window.DDReportUtils.syncCollapseArrows();
    }
    window.requestAnimationFrame(function () {
      var stickyWrap = document.querySelector('.qa-summary-sticky');
      var stickyOffset = 18;
      if (stickyWrap) {
        var stickyStyles = window.getComputedStyle(stickyWrap);
        var stickyTop = parseFloat(stickyStyles.top || '0') || 0;
        stickyOffset = Math.ceil(stickyWrap.getBoundingClientRect().height + stickyTop + 14);
      }
      var targetTop = window.pageYOffset + section.getBoundingClientRect().top - stickyOffset;
      window.scrollTo({ top: Math.max(0, targetTop), behavior: 'smooth' });
    });
  }

  function bindSummaryCards() {
    Array.prototype.slice.call(document.querySelectorAll('.qa-card[data-scroll-target]')).forEach(function (card) {
      if (card.dataset.bound === '1') return;
      card.dataset.bound = '1';
      card.addEventListener('click', function () {
        openReportSection(card.getAttribute('data-scroll-target') || '');
      });
      card.addEventListener('keydown', function (evt) {
        if (evt.key !== 'Enter' && evt.key !== ' ') return;
        evt.preventDefault();
        openReportSection(card.getAttribute('data-scroll-target') || '');
      });
    });
  }

  function renderList(items, emptyMessage, mapper) {
    if (!items || !items.length) {
      return '<div class="qa-empty">' + esc(emptyMessage) + '</div>';
    }
    return '<div class="qa-list">' + items.map(mapper).join('') + '</div>';
  }

  function renderSection(sectionId, title, bodyHtml, collapsed) {
    return '' +
      '<section class="dd-section' + (collapsed ? ' is-collapsed' : '') + '" data-section-id="' + esc(sectionId || '') + '">' +
        '<div class="dd-section-head">' +
          '<h2 class="dd-section-title">' + esc(title) + '</h2>' +
          '<button class="dd-section-toggle" type="button" aria-label="Collapse section">&#9650;</button>' +
        '</div>' +
        '<div class="dd-section-body">' + bodyHtml + '</div>' +
      '</section>';
  }

  function renderReport(snapshot, interactions, assetResults, findings) {
    var formsLinksIssueCount = findings.formIssues.length + findings.suspiciousLinks.length;
    var formsLinksIssueLabel = formsLinksIssueCount === 1 ? '1 flagged item' : (formsLinksIssueCount + ' flagged items');
    var scoreInfo = describeScore(findings.score);
    var interactionErrorCount = interactions.filter(function (item) { return item && item.error; }).length;
    var interactionSignalCount = interactions.filter(function (item) { return item && item.newEvents > 0; }).length;
    var interactionReactionCount = interactions.filter(function (item) {
      return item && (item.hashChanged || item.ariaExpandedChanged || item.openChanged);
    }).length;
    var assetGoodCount = Math.max(0, assetResults.length - findings.assetFailures.length);
    var totalFormLinkItems = snapshot.counts.formCount + snapshot.counts.linkCount;
    var formLinkGoodCount = Math.max(0, totalFormLinkItems - formsLinksIssueCount);
    var jsLoadFailCount = findings.runtimeErrors.length + findings.consoleErrors.length + findings.resourceErrors.length;
    var safeClickFailCount = interactions.filter(function (item) {
      return item && (item.error || item.newEvents > 0);
    }).length;
    var safeClickGoodCount = Math.max(0, interactions.length - safeClickFailCount);
    var overviewTitle = buildSectionTitle('Overview', [
      'Score = ' + findings.score,
      'Result = ' + scoreInfo.label
    ]);
    var assetTitle = buildSectionTitle('Asset Failures', [
      'Checked = ' + assetResults.length,
      'Passed = ' + assetGoodCount,
      'Fails = ' + findings.assetFailures.length,
      'Result = ' + sectionStatusLabel(findings.assetFailures.length)
    ]);
    var runtimeTitle = buildSectionTitle('JS and Load Errors', [
      'JS Errors = ' + (findings.runtimeErrors.length + findings.consoleErrors.length),
      'Failed Loads = ' + findings.resourceErrors.length,
      'Result = ' + sectionStatusLabel(jsLoadFailCount)
    ]);
    var formsTitle = buildSectionTitle('Forms and UI Smoke', [
      'Checked = ' + totalFormLinkItems,
      'Passed = ' + formLinkGoodCount,
      'Fails = ' + formsLinksIssueCount,
      'Result = ' + sectionStatusLabel(formsLinksIssueCount)
    ]);
    var safeClickTitle = buildSectionTitle('Safe Click Tests', [
      'Checked = ' + interactions.length,
      'Passed = ' + safeClickGoodCount,
      'Fails = ' + safeClickFailCount,
      'Result = ' + sectionStatusLabel(safeClickFailCount)
    ]);

    var summaryCards = '' +
      '<div class="qa-summary-sticky"><div class="qa-summary-grid">' +
        '<div class="qa-card is-link" data-scroll-target="overview" tabindex="0" role="button" aria-label="Open overview section">' +
          '<div class="qa-card-head"><div class="qa-label">Health Score</div><span class="qa-card-icon" aria-hidden="true">touch_app</span></div>' +
          '<div class="qa-score ' + findings.scoreState + '">' + esc(findings.score) + '</div>' +
        '</div>' +
        '<div class="qa-card is-link" data-scroll-target="asset-failures" tabindex="0" role="button" aria-label="Open asset failures section">' +
          '<div class="qa-card-head"><div class="qa-label">Assets Checked</div><span class="qa-card-icon" aria-hidden="true">touch_app</span></div>' +
          '<div class="qa-value">' + esc(assetResults.length) + '</div>' +
        '</div>' +
        '<div class="qa-card is-link" data-scroll-target="runtime-signals" tabindex="0" role="button" aria-label="Open runtime and console signals section">' +
          '<div class="qa-card-head"><div class="qa-label">JS / Load Errors</div><span class="qa-card-icon" aria-hidden="true">touch_app</span></div>' +
          '<div class="qa-value">' + esc(findings.runtimeErrors.length + findings.consoleErrors.length) + '</div>' +
        '</div>' +
        '<div class="qa-card is-link" data-scroll-target="forms-links" tabindex="0" role="button" aria-label="Open forms and links issues section">' +
          '<div class="qa-card-head"><div class="qa-label">Forms/Links Issues</div><span class="qa-card-icon" aria-hidden="true">touch_app</span></div>' +
          '<div class="qa-value">' + esc(formsLinksIssueCount) + '</div>' +
        '</div>' +
        '<div class="qa-card is-link" data-scroll-target="interaction-probe" tabindex="0" role="button" aria-label="Open safe click tests section">' +
          '<div class="qa-card-head"><div class="qa-label">Safe Click Tests</div><span class="qa-card-icon" aria-hidden="true">touch_app</span></div>' +
          '<div class="qa-value">' + esc(interactions.length) + '</div>' +
        '</div>' +
      '</div></div>';

    var bannerHtml = '';
    if (!findings.assetFailures.length &&
        !findings.runtimeErrors.length &&
        !findings.consoleErrors.length &&
        !findings.formIssues.length &&
        !findings.suspiciousLinks.length &&
        !findings.interactionIssues.length) {
      bannerHtml = '<div class="qa-banner">No critical issues were detected in this deterministic QA pass.</div>';
    }
    if (bannerEl) bannerEl.innerHTML = bannerHtml;

    var overviewHtml = '' +
      '<div class="qa-section-note">Health Score = ' + esc(findings.score) + ' (' + esc(scoreInfo.label) + '). Overall Result = ' + esc(scoreInfo.label) + '.<br>' +
      esc(scoreInfo.summary) + '<br>' +
      'Rule of thumb: 85+ = Good, 65-84 = Needs Review, below 65 = Poor.<br>' +
      'This score is based on asset failures, JavaScript/load errors, suspicious forms/links, and safe-click results.</div>' +
      '<div class="qa-pill-row">' +
        '<span class="qa-pill ' + findings.scoreState + '">Score ' + esc(findings.score) + '</span>' +
        '<span class="qa-pill ' + findings.scoreState + '">' + esc(scoreInfo.label) + '</span>' +
        '<span class="qa-pill ' + (runProbe ? 'ok' : 'warn') + '">' + (runProbe ? 'Safe probe enabled' : 'Safe probe disabled') + '</span>' +
        '<span class="qa-pill">' + esc(snapshot.readyState || 'unknown readyState') + '</span>' +
        '<span class="qa-pill">' + esc((snapshot.lang || 'lang n/a').toLowerCase()) + '</span>' +
      '</div>' +
      '<table class="qa-table">' +
        '<tbody>' +
          '<tr><th>URL</th><td><a class="qa-link" href="' + esc(snapshot.url || sourceUrl) + '" target="_blank" rel="noreferrer">' + esc(snapshot.url || sourceUrl) + '</a></td></tr>' +
          '<tr><th>Title</th><td>' + esc(snapshot.title || '(untitled)') + '</td></tr>' +
          '<tr><th>Captured</th><td>' + esc(formatDate(snapshot.capturedAt)) + '</td></tr>' +
          '<tr><th>Inventory</th><td>' +
            'Available Images = ' + esc(snapshot.counts.imageCount) + ', ' +
            'Available Scripts = ' + esc(snapshot.counts.scriptCount) + ', ' +
            'Available Stylesheets = ' + esc(snapshot.counts.stylesheetCount) + ', ' +
            'Available Links = ' + esc(snapshot.counts.linkCount) + ', ' +
            'Available Buttons = ' + esc(snapshot.counts.buttonCount) + ', ' +
            'Available Forms = ' + esc(snapshot.counts.formCount) + '.' +
          '</td></tr>' +
        '</tbody>' +
      '</table>';

    var assetsHtml = renderList(
      findings.assetFailures,
      'No failing assets were detected in the probed set.',
      function (item) {
        return '' +
          '<div class="qa-item">' +
            '<div class="qa-item-title">' + esc(item.type.toUpperCase()) + ' | ' + esc(item.url) + '</div>' +
            '<div class="qa-item-meta">' + esc(item.reason) + '</div>' +
          '</div>';
      }
    );

    assetsHtml = '<div class="qa-section-note">Assets Checked = ' + esc(assetResults.length) + '.<br>' +
      'Passed = ' + esc(assetGoodCount) + ' | Fails = ' + esc(findings.assetFailures.length) + ' | Result = ' + esc(sectionStatusLabel(findings.assetFailures.length)) + '.<br>' +
      'Each item below is an asset that failed to load correctly or returned an error during deterministic probing.</div>' + assetsHtml;

    var runtimeItems = findings.runtimeErrors.concat(findings.consoleErrors).concat(findings.resourceErrors).slice(0, 40);
    var runtimeHtml = renderList(
      runtimeItems,
      'No runtime or console issues were captured during this scan window.',
      function (item) {
        var payload = item && item.payload ? item.payload : {};
        var title = payload.message || payload.url || item.kind;
        var meta = item.kind + (payload.filename ? (' | ' + payload.filename) : '') + (payload.tag ? (' | ' + payload.tag) : '');
        return '' +
          '<div class="qa-item">' +
            '<div class="qa-item-title">' + esc(title) + '</div>' +
            '<div class="qa-item-meta">' + esc(meta) + '</div>' +
          '</div>';
      }
    );

    runtimeHtml = '<div class="qa-section-note">JS Errors = ' + esc(findings.runtimeErrors.length + findings.consoleErrors.length) + ' | Failed Loads = ' + esc(findings.resourceErrors.length) + ' | Result = ' + esc(sectionStatusLabel(jsLoadFailCount)) + '.<br>' +
      'This section checks whether the page produced JavaScript errors, unhandled promise errors, console errors, or failed resource loads while QA was watching it.<br>' +
      'Good result = 0 fails.</div>' + runtimeHtml;

    var formsHtml = renderList(
      findings.formIssues,
      'No form-smoke issues were detected.',
      function (item) {
        return '' +
          '<div class="qa-item">' +
            '<div class="qa-item-title">' + esc((item.method || 'get').toUpperCase()) + ' ' + esc(item.action || '(same page)') + '</div>' +
            '<div class="qa-item-meta">' +
              'Fields: ' + esc(item.fieldCount) +
              ' | Required: ' + esc(item.requiredCount) +
              ' | Unlabeled: ' + esc(item.unlabeledCount) +
              ' | Invalid: ' + esc(item.invalidCount) +
              ' | Submit controls: ' + esc(item.submitCount) +
            '</div>' +
          '</div>';
      }
    );

    var linksHtml = renderList(
      findings.suspiciousLinks.concat(findings.suspiciousButtons).slice(0, 30),
      'No suspicious links or buttons were detected in the sampled set.',
      function (item) {
        var metaParts = [];
        if (item.href) metaParts.push(item.href);
        if (item.rawHref) metaParts.push('raw: ' + item.rawHref);
        if (item.tag) metaParts.push('tag: ' + item.tag);
        if (item.type) metaParts.push('type: ' + item.type);
        if (item.isJavascript) metaParts.push('javascript href');
        if (item.hasText === false || !item.label) metaParts.push('missing label');
        return '' +
          '<div class="qa-item">' +
            '<div class="qa-item-title">' + esc(item.label || '(empty label)') + '</div>' +
            '<div class="qa-item-meta">' + esc(metaParts.join(' | ')) + '</div>' +
          '</div>';
      }
    );

    formsHtml = '<div class="qa-section-note">Items Reviewed = ' + esc(totalFormLinkItems) + ' | Passed = ' + esc(formLinkGoodCount) + ' | Fails = ' + esc(formsLinksIssueCount) + ' | Result = ' + esc(sectionStatusLabel(formsLinksIssueCount)) + '.<br>' +
      'Flagged Forms = ' + esc(findings.formIssues.length) + ' | Flagged Links = ' + esc(findings.suspiciousLinks.length) + '.<br>' +
      'Available Forms = ' + esc(snapshot.counts.formCount) + ' | Available Links = ' + esc(snapshot.counts.linkCount) + '.<br>' +
      'Flagged links are links that look risky or low-quality for users and automation. In this scan, a link is flagged when it uses <code>javascript:</code> or has no visible text label.</div>' + formsHtml;
    linksHtml = '<div class="qa-section-note">This list shows the flagged links and suspicious buttons detected on the page.<br>' +
      'Use the item label, href, raw href, and the reason markers such as <code>missing label</code> or <code>javascript href</code> to identify them directly.</div>' + linksHtml;

    var interactionsHtml = renderList(
      interactions,
      'No safe interaction candidates were executed.',
      function (item) {
        var meta = [];
        meta.push('tag: ' + (item.tag || 'element'));
        if (item.error) meta.push('error: ' + item.error);
        else meta.push('captured events: ' + item.newEvents);
        if (item.hashChanged) meta.push('hash changed');
        if (item.ariaExpandedChanged) meta.push('expanded state changed');
        if (item.openChanged) meta.push('open state changed');
        if (!item.error && !item.hashChanged && !item.ariaExpandedChanged && !item.openChanged && !item.newEvents) {
          meta.push('no visible state change detected');
        }
        return '' +
          '<div class="qa-item">' +
            '<div class="qa-item-title">' + esc((item.tag === 'a' ? 'Link' : 'Element') + ': ' + (item.label || item.tag || 'element')) + '</div>' +
            '<div class="qa-item-meta">' + esc(meta.join(' | ')) + '</div>' +
          '</div>';
      }
    );

    interactionsHtml = '<div class="qa-section-note">This number is coverage, not a failure count.<br>' +
      'Good result = the tested clicks do not create JavaScript/load errors.<br>' +
      'In this run: click errors = ' + esc(interactionErrorCount) + ' | new page-error signals after click = ' + esc(interactionSignalCount) + ' | visible UI reactions = ' + esc(interactionReactionCount) + '.<br>' +
      '"No visible state change detected" is usually neutral here: it only means that the clicked element did not expand, collapse, or visibly change the current page during the observation window.</div>' + interactionsHtml;

    rootEl.innerHTML = summaryCards +
      renderSection('overview', overviewTitle, overviewHtml, false) +
      renderSection('asset-failures', assetTitle, assetsHtml, false) +
      renderSection('runtime-signals', runtimeTitle, runtimeHtml, false) +
      renderSection('forms-links', formsTitle, formsHtml + linksHtml, true) +
      renderSection('interaction-probe', safeClickTitle, interactionsHtml, true);

    bindSectionToggles();
    bindSummaryCards();
    if (window.DDReportUtils && window.DDReportUtils.syncCollapseArrows) {
      window.DDReportUtils.syncCollapseArrows();
    }
  }

  async function focusSourceTab() {
    var tab = await getSourceTab(sourceTabId);
    if (!tab) return;
    chrome.tabs.update(sourceTabId, { active: true }, function () {});
    if (typeof tab.windowId === 'number') {
      chrome.windows.update(tab.windowId, { focused: true }, function () {});
    }
  }

  async function runScan() {
    if (!sourceTabId) {
      setStatus('Source tab was not provided.', 'error');
      setProgress(100, 'Source tab was not provided.', 'error');
      return;
    }

    rerunBtn.disabled = true;
    openSourceBtn.disabled = true;
    setSubtitle('Scanning source tab ' + sourceTabId + '...');
    setProgress(5, 'Preparing QA scan...', '');
    setStatus('Collecting page signals...', '');

    try {
      setProgress(12, 'Checking source tab...', '');
      var tab = await getSourceTab(sourceTabId);
      if (!tab) throw new Error('Source tab is no longer available.');

      setProgress(18, 'Installing QA monitor...', '');
      await ensureQaBridgeInMainWorld(sourceTabId);
      setProgress(28, 'Collecting page signals...', '');
      var pageResp = await sendToTab(sourceTabId, { action: 'qa_scan_page', probe: runProbe });
      if (!pageResp || pageResp.ok === false || !pageResp.snapshot) {
        throw new Error((pageResp && pageResp.error) || 'Failed to collect QA signals from the page.');
      }

      setProgress(42, 'Page signals collected.', '');
      setStatus('Probing referenced assets...', '');
      var probeList = buildAssetProbeList(pageResp.snapshot);
      setProgress(45, 'Building asset probe list...', '');
      var assetResults = await probeAssetsWithProgress(probeList);
      setProgress(92, 'Calculating findings...', '');
      var findings = collectFindings(pageResp.snapshot, pageResp.interactions || [], assetResults);

      renderReport(pageResp.snapshot, pageResp.interactions || [], assetResults, findings);
      setSubtitle((pageResp.snapshot.url || sourceUrl || '') + ' | ' + formatDate(pageResp.snapshot.capturedAt));
      setStatus('', '');
      setProgress(100, 'QA scan completed.', 'success');
    } catch (err) {
      rootEl.innerHTML = '';
      if (bannerEl) bannerEl.innerHTML = '';
      setStatus(makeRuntimeMessage(err), 'error');
      setSubtitle('QA scan failed');
      setProgress(100, 'QA scan failed.', 'error');
    } finally {
      rerunBtn.disabled = false;
      openSourceBtn.disabled = false;
    }
  }

  if (window.DDReportUtils && window.DDReportUtils.bindSaveButton) {
    window.DDReportUtils.bindSaveButton(saveBtn, 'qa_scan_report.html');
  }

  if (rerunBtn) {
    rerunBtn.addEventListener('click', function () {
      runScan();
    });
  }

  if (openSourceBtn) {
    openSourceBtn.addEventListener('click', function () {
      focusSourceTab();
    });
  }

  runScan();
})();
