# fix_encoding.ps1
# Repairs double-encoded UTF-8 characters across ALL .html and .js project files.
# Run with: powershell -ExecutionPolicy Bypass -File fix_encoding.ps1

$base = 'C:\Users\camil\OneDrive\Documentos\Profissional\OutSystems2026\Automations\Digital Detective v2.0'

# Helper: build a string from an array of codepoints (avoids [char]+[char] arithmetic bug)
function Chars([int[]]$codepoints) {
  return [System.String]::new(($codepoints | ForEach-Object { [char]$_ }))
}

# Standard characters double-encoded as UTF-8 misread via CP1252
# Each entry: [corrupted-string, safe-replacement]
$replacements = @(
  # em-dash U+2014  (UTF-8: E2 80 94 -> CP1252: U+00E2 U+20AC U+201D)
  @( (Chars @(0x00E2, 0x20AC, 0x201D)),  '&mdash;'   ),
  # en-dash U+2013  (UTF-8: E2 80 93 -> CP1252: U+00E2 U+20AC U+201C)
  @( (Chars @(0x00E2, 0x20AC, 0x201C)),  '&ndash;'   ),
  # ellipsis U+2026 (UTF-8: E2 80 A6 -> CP1252: U+00E2 U+20AC U+00A6)
  @( (Chars @(0x00E2, 0x20AC, 0x00A6)),  '&hellip;'  ),
  # box-drawing horizontal U+2500 (UTF-8: E2 94 80 -> CP1252: U+00E2 U+201D U+20AC)
  # used in JS/CSS comments like /* ── Header ── */
  @( (Chars @(0x00E2, 0x201D, 0x20AC)),  '-'         ),
  # left double quote U+201C (UTF-8: E2 80 9C -> CP1252: U+00E2 U+20AC U+009C)
  @( (Chars @(0x00E2, 0x20AC, 0x009C)),  '&ldquo;'   ),
  # right double quote U+201D (UTF-8: E2 80 9D -> CP1252: U+00E2 U+20AC U+009D)
  @( (Chars @(0x00E2, 0x20AC, 0x009D)),  '&rdquo;'   ),
  # left single quote U+2018 (UTF-8: E2 80 98 -> CP1252: U+00E2 U+20AC U+02DC)
  @( (Chars @(0x00E2, 0x20AC, 0x02DC)),  '&lsquo;'   ),
  # right single quote U+2019 (UTF-8: E2 80 99 -> CP1252: U+00E2 U+20AC U+2122)
  @( (Chars @(0x00E2, 0x20AC, 0x2122)),  '&rsquo;'   ),
  # bullet U+2022 (UTF-8: E2 80 A2 -> CP1252: U+00E2 U+20AC U+00A2)
  @( (Chars @(0x00E2, 0x20AC, 0x00A2)),  '&bull;'    ),
  # middle dot U+00B7 (UTF-8: C2 B7 -> CP1252: U+00C2 U+00B7)
  @( (Chars @(0x00C2, 0x00B7)),          '&middot;'  ),
  # non-breaking space U+00A0 (UTF-8: C2 A0 -> CP1252: U+00C2 U+00A0)
  @( (Chars @(0x00C2, 0x00A0)),          ' '         ),
  # copyright U+00A9 (UTF-8: C2 A9 -> CP1252: U+00C2 U+00A9)
  @( (Chars @(0x00C2, 0x00A9)),          '&copy;'    ),
  # registered U+00AE (UTF-8: C2 AE -> CP1252: U+00C2 U+00AE)
  @( (Chars @(0x00C2, 0x00AE)),          '&reg;'     ),
  # degree U+00B0 (UTF-8: C2 B0 -> CP1252: U+00C2 U+00B0)
  @( (Chars @(0x00C2, 0x00B0)),          '&deg;'     ),

  # ── Emoji: 4-byte UTF-8 (F0 9F ...) misread via CP1252 ──
  # F0=0xF0(ð), 9F=0x9F(Ÿ), then next two bytes vary
  # 🚨 U+1F6A8 (F0 9F 9A A8): CP1252 -> U+00F0 U+0178 U+0161 U+00A8 BUT 9F in CP1252 = U+0178(Ÿ)
  @( (Chars @(0x00F0, 0x0178, 0x0161, 0x00A8)),  '&#x1F6A8;'  ),  # alert siren
  # ✅ U+2705 (E2 9C 85): CP1252 9C=U+0153, 85=U+2026? No: E2->â, 9C->œ(CP1252 0x9C=U+0153), 85->…(CP1252 0x85=U+2026)
  @( (Chars @(0x00E2, 0x0153, 0x2026)),           '&#x2705;'   ),  # green check
  # ⚠ U+26A0 (E2 9A A0): E2->â, 9A->š(CP1252 0x9A=U+0161), A0->U+00A0(nbsp)
  @( (Chars @(0x00E2, 0x0161, 0x00A0)),           '&#x26A0;&#xFE0F;' ),  # warning
  # ❌ U+274C (E2 9D 8C): E2->â, 9D->U+2019(CP1252 0x9D=U+2019), 8C->U+0152(CP1252 0x8C=U+0152)
  @( (Chars @(0x00E2, 0x2019, 0x0152)),           '&#x274C;'   ),  # red X
  # ✓ U+2713 (E2 9C 93): E2->â, 9C->U+0153(CP1252), 93->U+201C(CP1252 0x93=U+201C)
  @( (Chars @(0x00E2, 0x0153, 0x201C)),           '&#x2713;'   ),  # check mark
  # 🔺 U+1F53A (F0 9F 94 BA): F0->ð, 9F->Ÿ, 94->U+201D(CP1252), BA->U+00BA
  @( (Chars @(0x00F0, 0x0178, 0x201D, 0x00BA)),   '&#x1F53A;'  ),  # red triangle up
  # 🔍 U+1F50D (F0 9F 94 8D): F0->ð, 9F->Ÿ, 94->U+201D, 8D->U+017D(CP1252 0x8D=U+017D? no...)
  # Actually CP1252 0x8D is undefined, becomes U+FFFD
  # 👍 U+1F44D (F0 9F 91 8D): F0->ð, 9F->Ÿ, 91->U+2018(CP1252 0x91=U+2018), 8D->U+FFFD
  # skip undefined-byte emoji
  # 📊 U+1F4CA (F0 9F 93 8A): F0->ð, 9F->Ÿ, 93->U+201C(CP1252 0x93=U+201C), 8A->U+0160(CP1252)
  @( (Chars @(0x00F0, 0x0178, 0x201C, 0x0160)),   '&#x1F4CA;'  ),  # bar chart
  # 📋 U+1F4CB (F0 9F 93 8B): F0->ð, 9F->Ÿ, 93->U+201C, 8B->U+0161(CP1252 0x8B=U+2039? no, 0x8B=U+2039)
  # Let's skip complex ones and focus on what's actually corrupted in the screenshot
  # 🔗 U+1F517 (F0 9F 94 97): F0->ð, 9F->Ÿ, 94->U+201D, 97->U+2014(CP1252 0x97=U+2014)
  @( (Chars @(0x00F0, 0x0178, 0x201D, 0x2014)),   '&#x1F517;'  ),  # link
  # 🏷 U+1F3F7 (F0 9F 8F B7): F0->ð, 9F->Ÿ, 8F->U+FFFD(undefined), B7->U+00B7
  # skip: 8F is undefined in CP1252

  # arrow characters
  # → U+2192 (E2 86 92): E2->â, 86->U+2020(CP1252 0x86=U+2020), 92->U+2019(CP1252 0x92=U+2019)
  @( (Chars @(0x00E2, 0x2020, 0x2019)),           '->'         ),
  # ← U+2190 (E2 86 90): E2->â, 86->U+2020(CP1252 0x86=U+2020), 90->U+0090(CP1252 0x90 undefined)
  @( (Chars @(0x00E2, 0x2020, 0x0090)),           '\u2190'     ),  # left arrow (JS unicode escape)
  # ≥ U+2265 (E2 89 A5): E2->â, 89->U+2030(CP1252 0x89=U+2030), A5->U+00A5(CP1252 0xA5=yen)
  @( (Chars @(0x00E2, 0x2030, 0x00A5)),           '>='         ),  # greater-equal
  # ═ U+2550 (E2 95 90): E2->â, 95->U+2022(CP1252 0x95=U+2022 bullet), 90->U+0090 undefined
  @( (Chars @(0x00E2, 0x2022, 0x0090)),           '-'          ),  # double horizontal box-drawing
  # NOTE: euro/peso/rupee (E2 82 AC/B1/B9) are handled by fix_currency.ps1 separately
  # because U+00E2 U+201A U+00AC also appears as intentional pattern in content.js
  # ▲ U+25B2 (E2 96 B2): E2->â, 96->U+2013(CP1252 0x96=U+2013 en-dash), B2->U+00B2
  @( (Chars @(0x00E2, 0x2013, 0x00B2)),           '&#x25B2;'   ),
  # ▼ U+25BC (E2 96 BC): E2->â, 96->U+2013, BC->U+00BC
  @( (Chars @(0x00E2, 0x2013, 0x00BC)),           '&#x25BC;'   ),
  # Orphaned corrupted U+FE0F variation selector: EF B8 8F -> U+00EF U+00B8 U+008F
  # Appears after already-fixed &#x26A0;&#xFE0F; (the ⚠ part was fixed but FE0F bytes lingered)
  @( (Chars @(0x00EF, 0x00B8, 0x008F)),           ''           ),  # remove orphaned 3-byte form
  @( (Chars @(0x00EF, 0x00B8)),                   ''           ),  # remove partial orphan fallback
  # 4-byte emoji visible in seo_report.html section icons (all 4 bytes defined in CP1252)
  # 🔴 U+1F534 (F0 9F 94 B4): F0->U+00F0, 9F->U+0178, 94->U+201D, B4->U+00B4
  @( (Chars @(0x00F0, 0x0178, 0x201D, 0x00B4)),   '&#x1F534;'  ),  # red circle
  # 🟡 U+1F7E1 (F0 9F 9F A1): F0->U+00F0, 9F->U+0178(x2), A1->U+00A1
  @( (Chars @(0x00F0, 0x0178, 0x0178, 0x00A1)),   '&#x1F7E1;'  ),  # yellow circle
  # 💡 U+1F4A1 (F0 9F 92 A1): F0->U+00F0, 9F->U+0178, 92->U+2019, A1->U+00A1
  @( (Chars @(0x00F0, 0x0178, 0x2019, 0x00A1)),   '&#x1F4A1;'  ),  # light bulb
  # 🧩 U+1F9E9 (F0 9F A7 A9): F0->U+00F0, 9F->U+0178, A7->U+00A7, A9->U+00A9
  @( (Chars @(0x00F0, 0x0178, 0x00A7, 0x00A9)),   '&#x1F9E9;'  )   # puzzle piece
)

# Collect .html and .js files (skip fix_encoding.ps1 and inspect_bytes.ps1)
$files = Get-ChildItem -Path "$base\*" -Include @('*.html','*.js') -ErrorAction SilentlyContinue |
         Where-Object { $_.Name -notmatch '^(fix_encoding|inspect_bytes)' }

$totalFixed = 0

foreach ($file in $files) {
  $content = [System.IO.File]::ReadAllText($file.FullName, [System.Text.Encoding]::UTF8)
  $original = $content

  foreach ($pair in $replacements) {
    if ($content.Contains($pair[0])) {
      $count = ([regex]::Matches($content, [regex]::Escape($pair[0]))).Count
      $content = $content.Replace($pair[0], $pair[1])
      Write-Host "  -> $($file.Name): replaced $count x '$($pair[0])' with '$($pair[1])'"
    }
  }

  if ($content -ne $original) {
    [System.IO.File]::WriteAllText($file.FullName, $content, (New-Object System.Text.UTF8Encoding $false))
    $totalFixed++
    Write-Host "FIXED: $($file.Name)"
  }
}

Write-Host ""
Write-Host "Done. Files with at least 1 replacement: $totalFixed / $($files.Count)"
