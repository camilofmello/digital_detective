$base = 'C:\Users\camil\OneDrive\Documentos\Profissional\OutSystems2026\Automations\Digital Detective v2.0'
$files = Get-ChildItem -Path "$base\*" -Include @('*.html','*.js') | Where-Object { $_.Name -notmatch '^(fix_encoding|fix_currency|verify_encoding|inspect_bytes|find_emoji|diagnose_remaining)' }

foreach ($f in $files) {
  $text = [System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::UTF8)
  $hasF0 = $text.IndexOf([char]0x00F0) -ge 0
  $hasEF = $text.IndexOf([char]0x00EF) -ge 0
  if ($hasF0 -or $hasEF) {
    Write-Host "=== $($f.Name) ==="
    $lines = $text -split "`n"
    for ($i = 0; $i -lt $lines.Length; $i++) {
      $line = $lines[$i]
      if ($line.IndexOf([char]0x00F0) -ge 0 -or $line.IndexOf([char]0x00EF) -ge 0) {
        $short = $line.Substring(0, [Math]::Min(120, $line.Length)).Trim()
        Write-Host "  L$($i+1): $short"
        # Show codepoints of problem chars
        for ($j = 0; $j -lt [Math]::Min($line.Length, 200); $j++) {
          $cp = [int]$line[$j]
          if ($cp -eq 0x00F0 -or $cp -eq 0x00EF) {
            $ctx = ''
            for ($k = $j; $k -lt [Math]::Min($j+5, $line.Length); $k++) {
              $ctx += 'U+' + ([int]$line[$k]).ToString('X4') + ' '
            }
            Write-Host "    @${j}: $ctx"
            $j += 3
          }
        }
      }
    }
  }
}
