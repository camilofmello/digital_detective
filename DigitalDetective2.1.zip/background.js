(function () {
  'use strict';

  function getUrlProtocol(url) {
    try {
      var u = new URL(String(url || '').trim());
      return (u.protocol || '').toLowerCase();
    } catch (e) {
      return '';
    }
  }

  function isHttpNetworkUrl(url) {
    var p = getUrlProtocol(url);
    return p === 'http:' || p === 'https:';
  }

  function isPageFetchableUrl(url) {
    var p = getUrlProtocol(url);
    return p === 'http:' || p === 'https:' || p === 'file:';
  }

  function isTextFetchableUrl(url) {
    try {
      var p = getUrlProtocol(url);
      return p === 'http:' || p === 'https:' || p === 'file:';
    } catch (e) {
      return false;
    }
  }

  function safeFetch(url) {
    if (!isPageFetchableUrl(url)) return Promise.resolve('');
    var protocol = getUrlProtocol(url);
    var opts = (protocol === 'file:')
      ? { cache: 'no-store' }
      : { credentials: 'include', cache: 'no-store' };
    return fetch(url, opts)
      .then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.text();
      })
      .catch(function () { return ''; });
  }

  function isFileSchemeAccessAllowed() {
    return new Promise(function (resolve) {
      try {
        if (!chrome.extension || !chrome.extension.isAllowedFileSchemeAccess) {
          resolve(null);
          return;
        }
        chrome.extension.isAllowedFileSchemeAccess(function (allowed) {
          if (chrome.runtime.lastError) {
            resolve(null);
            return;
          }
          resolve(!!allowed);
        });
      } catch (e) {
        resolve(null);
      }
    });
  }

  function captureRenderedPageHtml(url, waitMs) {
    return new Promise(function (resolve) {
      var captureUrl = String(url || '').trim();
      if (!captureUrl) {
        resolve({ ok: false, error: 'No URL provided' });
        return;
      }

      var settle = false;
      var tabId = null;
      var scheduled = false;
      var timeoutHandle = null;
      var delay = Number.isFinite(waitMs) ? waitMs : 2500;
      delay = Math.max(300, Math.min(12000, Math.round(delay)));

      function cleanup() {
        try { chrome.tabs.onUpdated.removeListener(onUpdated); } catch (e0) {}
        if (timeoutHandle) {
          clearTimeout(timeoutHandle);
          timeoutHandle = null;
        }
      }

      function finish(payload) {
        if (settle) return;
        settle = true;
        cleanup();
        if (tabId) {
          try { chrome.tabs.remove(tabId, function () {}); } catch (e1) {}
        }
        resolve(payload);
      }

      function serializeAndCapture() {
        if (settle || !tabId) return;
        chrome.scripting.executeScript({
          target: { tabId: tabId },
          world: 'MAIN',
          func: function () {
            function serializeDoctype(doc) {
              if (!doc || !doc.doctype) return '<!DOCTYPE html>';
              var dt = doc.doctype;
              var name = dt.name || 'html';
              var publicId = dt.publicId || '';
              var systemId = dt.systemId || '';
              if (publicId) {
                return '<!DOCTYPE ' + name + ' PUBLIC "' + publicId + '"' + (systemId ? (' "' + systemId + '"') : '') + '>';
              }
              if (systemId) {
                return '<!DOCTYPE ' + name + ' SYSTEM "' + systemId + '">';
              }
              return '<!DOCTYPE ' + name + '>';
            }

            try {
              var html = document.documentElement ? document.documentElement.outerHTML : '';
              if (!html) return { ok: false, error: 'Empty DOM snapshot' };
              return {
                ok: true,
                url: location.href || '',
                doctype: serializeDoctype(document),
                html: html
              };
            } catch (err) {
              return { ok: false, error: (err && err.message) ? err.message : String(err) };
            }
          }
        }, function (results) {
          if (chrome.runtime.lastError) {
            finish({ ok: false, error: chrome.runtime.lastError.message || 'Snapshot failed' });
            return;
          }
          var snap = results && results[0] ? results[0].result : null;
          if (!snap || !snap.ok || !snap.html) {
            finish({ ok: false, error: (snap && snap.error) ? snap.error : 'Snapshot failed' });
            return;
          }
          finish({ ok: true, doctype: snap.doctype || '<!DOCTYPE html>', html: snap.html, url: snap.url || captureUrl });
        });
      }

      function scheduleCapture() {
        if (scheduled || settle) return;
        scheduled = true;
        setTimeout(serializeAndCapture, delay);
      }

      function onUpdated(updatedTabId, changeInfo) {
        if (updatedTabId !== tabId) return;
        if (changeInfo && changeInfo.status === 'complete') scheduleCapture();
      }

      timeoutHandle = setTimeout(function () {
        finish({ ok: false, error: 'Timed out while loading file URL.' });
      }, 30000);

      chrome.tabs.onUpdated.addListener(onUpdated);
      chrome.tabs.create({ url: captureUrl, active: false }, function (tab) {
        if (chrome.runtime.lastError || !tab || !tab.id) {
          finish({ ok: false, error: 'Unable to open URL for fallback snapshot.' });
          return;
        }
        tabId = tab.id;
        if (tab.status === 'complete') scheduleCapture();
      });
    });
  }

  function arrayBufferToBase64(buffer) {
    if (!buffer) return '';
    var bytes = new Uint8Array(buffer);
    var chunkSize = 0x8000;
    var binary = '';
    for (var i = 0; i < bytes.length; i += chunkSize) {
      var chunk = bytes.subarray(i, i + chunkSize);
      binary += String.fromCharCode.apply(null, chunk);
    }
    return btoa(binary);
  }

  function safeFetchAssetAsDataUri(url, maxBytes) {
    var limit = Number(maxBytes);
    if (!Number.isFinite(limit) || limit <= 0) limit = 3 * 1024 * 1024;
    if (!isHttpNetworkUrl(url)) {
      return Promise.resolve({ ok: false, url: url, error: 'unsupported_scheme' });
    }
    return fetch(url, { credentials: 'include' })
      .then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        var mime = (res.headers.get('content-type') || '').split(';')[0].trim() || 'application/octet-stream';
        return res.arrayBuffer().then(function (buf) {
          var size = (buf && buf.byteLength) ? buf.byteLength : 0;
          if (!size) throw new Error('Empty asset');
          if (size > limit) {
            return { ok: false, url: url, error: 'asset_too_large', size: size, mime: mime };
          }
          var b64 = arrayBufferToBase64(buf);
          return {
            ok: true,
            url: url,
            size: size,
            mime: mime,
            dataUri: 'data:' + mime + ';base64,' + b64
          };
        });
      })
      .catch(function (err) {
        return { ok: false, url: url, error: (err && err.message) ? err.message : 'fetch_failed' };
      });
  }

  function finalizeQaProbeResponse(url, type, label, method, res) {
    var out = {
      ok: !!(res && res.ok),
      url: url,
      type: type || 'asset',
      label: label || '',
      method: method || 'GET',
      status: res ? Number(res.status || 0) : 0,
      redirected: !!(res && res.redirected),
      finalUrl: res ? (res.url || url) : url,
      contentType: res ? ((res.headers && res.headers.get('content-type')) || '') : ''
    };
    try {
      if (res && res.body && typeof res.body.cancel === 'function') res.body.cancel();
    } catch (e) {}
    return out;
  }

  function qaProbeAsset(item) {
    var url = item && item.url ? String(item.url).trim() : '';
    var type = item && item.type ? String(item.type).trim() : 'asset';
    var label = item && item.label ? String(item.label).trim() : '';
    if (!url) {
      return Promise.resolve({ ok: false, url: '', type: type, label: label, error: 'missing_url' });
    }

    var protocol = getUrlProtocol(url);
    if (protocol !== 'http:' && protocol !== 'https:' && protocol !== 'file:') {
      return Promise.resolve({ ok: false, url: url, type: type, label: label, error: 'unsupported_scheme' });
    }

    function run(method) {
      var opts = { method: method, cache: 'no-store' };
      if (protocol !== 'file:') opts.credentials = 'include';
      return fetch(url, opts)
        .then(function (res) {
          return finalizeQaProbeResponse(url, type, label, method, res);
        })
        .catch(function (err) {
          return {
            ok: false,
            url: url,
            type: type,
            label: label,
            method: method,
            status: 0,
            error: (err && err.message) ? err.message : 'fetch_failed'
          };
        });
    }

    if (protocol === 'file:') return run('GET');

    return run('HEAD').then(function (headResult) {
      if (headResult && (headResult.ok || headResult.status >= 200 || headResult.status === 304)) {
        return headResult;
      }
      return run('GET');
    });
  }

  function getStorageArea() {
    if (chrome.storage && chrome.storage.session) return chrome.storage.session;
    return chrome.storage.local;
  }

  function getBlockedMap(cb) {
    var storage = getStorageArea();
    storage.get('dd_blocked', function (res) {
      cb((res && res.dd_blocked) ? res.dd_blocked : {});
    });
  }

  function setBlockedMap(map, cb) {
    var storage = getStorageArea();
    storage.set({ dd_blocked: map || {} }, function () {
      if (cb) cb();
    });
  }

  function hashText(str) {
    var h = 0;
    var s = String(str || '');
    for (var i = 0; i < s.length; i++) {
      h = ((h << 5) - h) + s.charCodeAt(i);
      h |= 0;
    }
    return Math.abs(h);
  }

  function ruleIdFor(url, tabId) {
    var base = String(tabId || '') + '|' + String(url || '');
    var id = hashText(base);
    if (id === 0) id = 1;
    return id % 100000000;
  }

  var previewFrameRuleIdsByTab = {};
  var PREVIEW_IFRAME_RULE_KEY = '__preview_iframe_unblock__';

  function normalizeHostsFromUrls(urls) {
    var out = {};
    (Array.isArray(urls) ? urls : []).forEach(function (raw) {
      try {
        var u = new URL(String(raw || '').trim());
        var p = (u.protocol || '').toLowerCase();
        if (p !== 'http:' && p !== 'https:') return;
        var h = String(u.hostname || '').toLowerCase().trim();
        if (!h) return;
        out[h] = true;
        if (h.indexOf('www.') === 0 && h.length > 4) out[h.slice(4)] = true;
        else out['www.' + h] = true;
      } catch (e) {}
    });
    return Object.keys(out);
  }

  function clearPreviewFrameRules(tabId, cb) {
    var key = PREVIEW_IFRAME_RULE_KEY;
    var ids = previewFrameRuleIdsByTab[key] || [];
    if (!ids.length) {
      if (cb) cb({ ok: true, removed: 0 });
      return;
    }
    try {
      chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: ids }, function () {
        delete previewFrameRuleIdsByTab[key];
        if (chrome.runtime.lastError) {
          if (cb) cb({ ok: false, error: chrome.runtime.lastError.message || 'Failed to remove preview rules' });
          return;
        }
        if (cb) cb({ ok: true, removed: ids.length });
      });
    } catch (e0) {
      if (cb) cb({ ok: false, error: String(e0 && e0.message ? e0.message : e0) });
    }
  }

  function enablePreviewFrameRules(tabId, urls, cb) {
    var hosts = normalizeHostsFromUrls(urls);
    if (!hosts.length) {
      clearPreviewFrameRules(tabId, function (res0) { if (cb) cb(res0); });
      return;
    }

    clearPreviewFrameRules(tabId, function () {
      var key = PREVIEW_IFRAME_RULE_KEY;
      var rules = [];
      var ids = [];
      hosts.forEach(function (host) {
        var id = ruleIdFor('dd_iframe_unblock|' + host, PREVIEW_IFRAME_RULE_KEY);
        ids.push(id);
        var condition = {
          resourceTypes: ['main_frame', 'sub_frame'],
          urlFilter: '||' + host + '/'
        };
        rules.push({
          id: id,
          priority: 1,
          action: {
            type: 'modifyHeaders',
            responseHeaders: [
              { header: 'x-frame-options', operation: 'remove' },
              { header: 'content-security-policy', operation: 'remove' },
              { header: 'content-security-policy-report-only', operation: 'remove' },
              { header: 'cross-origin-resource-policy', operation: 'remove' },
              { header: 'cross-origin-embedder-policy', operation: 'remove' },
              { header: 'cross-origin-opener-policy', operation: 'remove' }
            ]
          },
          condition: condition
        });
      });

      try {
        chrome.declarativeNetRequest.updateSessionRules({
          removeRuleIds: ids,
          addRules: rules
        }, function () {
          if (chrome.runtime.lastError) {
            if (cb) cb({ ok: false, error: chrome.runtime.lastError.message || 'Failed to enable preview rules' });
            return;
          }
          previewFrameRuleIdsByTab[key] = ids;
          if (cb) cb({ ok: true, hosts: hosts, ruleCount: ids.length });
        });
      } catch (e1) {
        if (cb) cb({ ok: false, error: String(e1 && e1.message ? e1.message : e1) });
      }
    });
  }

  function normalizeBaseUrl(url) {
    return String(url || '').split('#')[0].split('?')[0];
  }

  function injectCompanionScrollBridge(tabId, reportTabId, cb) {
    if (!tabId) {
      if (cb) cb({ ok: false, error: 'invalid_tab' });
      return;
    }
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: function (reportTabIdArg) {
        var reportId = Number(reportTabIdArg) || 0;
        if (!reportId) return { ok: false, error: 'invalid_report' };

        if (window.__ddCompanionBridgeInstalledFor === reportId) {
          return { ok: true, installed: true, reportTabId: reportId };
        }
        window.__ddCompanionBridgeInstalledFor = reportId;

        function getScrollInfo() {
          var de = document.documentElement || document.body;
          var body = document.body || de;
          var top = window.scrollY || de.scrollTop || body.scrollTop || 0;
          var max = Math.max(
            0,
            (de.scrollHeight || 0) - (de.clientHeight || 0),
            (body.scrollHeight || 0) - (body.clientHeight || 0)
          );
          return { top: top, max: max };
        }

        function emit() {
          try {
            var sup = Number(window.__ddCompanionSuppressUntil || 0);
            if (Date.now() < sup) return;
          } catch (e0) {}

          var info = getScrollInfo();
          var ratio = (info.max > 0) ? (info.top / info.max) : 0;
          if (!Number.isFinite(ratio) || ratio < 0) ratio = 0;
          if (ratio > 1) ratio = 1;

          try {
            chrome.runtime.sendMessage({
              action: 'preview_companion_scroll_emit',
              reportTabId: reportId,
              ratio: ratio,
              top: info.top,
              max: info.max,
              url: location.href || ''
            });
          } catch (e1) {}
        }

        var ticking = false;
        window.addEventListener('scroll', function () {
          if (ticking) return;
          ticking = true;
          requestAnimationFrame(function () {
            ticking = false;
            emit();
          });
        }, { passive: true });

        setTimeout(emit, 250);
        window.addEventListener('load', function () {
          setTimeout(emit, 150);
        });
        return { ok: true, installed: true, reportTabId: reportId };
      },
      args: [reportTabId]
    }, function (results) {
      if (chrome.runtime.lastError) {
        if (cb) cb({ ok: false, error: chrome.runtime.lastError.message || 'bridge_inject_failed' });
        return;
      }
      var out = results && results[0] ? results[0].result : null;
      if (cb) cb(out && out.ok ? out : { ok: false, error: (out && out.error) ? out.error : 'bridge_inject_failed' });
    });
  }

  function injectCompanionScrollBridgeWhenReady(tabId, reportTabId, cb) {
    var done = false;
    var timeoutHandle = null;

    function finish(res) {
      if (done) return;
      done = true;
      try { chrome.tabs.onUpdated.removeListener(onUpdated); } catch (e0) {}
      if (timeoutHandle) clearTimeout(timeoutHandle);
      if (cb) cb(res);
    }

    function onUpdated(updatedTabId, changeInfo) {
      if (updatedTabId !== tabId) return;
      if (changeInfo && changeInfo.status === 'complete') {
        injectCompanionScrollBridge(tabId, reportTabId, finish);
      }
    }

    timeoutHandle = setTimeout(function () {
      injectCompanionScrollBridge(tabId, reportTabId, finish);
    }, 2400);

    try { chrome.tabs.onUpdated.addListener(onUpdated); } catch (e1) {}
    chrome.tabs.get(tabId, function (tab) {
      if (chrome.runtime.lastError || !tab || !tab.id) {
        finish({ ok: false, error: 'companion_tab_missing' });
        return;
      }
      if (tab.status === 'complete') {
        injectCompanionScrollBridge(tabId, reportTabId, finish);
      }
    });
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {

    // -- Event Tracker Inject
    if (msg.action === 'event_tracker_inject') {
      var tabId = sender && sender.tab ? sender.tab.id : null;
      if (!tabId) {
        sendResponse({ ok: false });
        return;
      }
      try {
        chrome.scripting.executeScript({
          target: { tabId: tabId },
          world: 'MAIN',
          func: function () {
            if (window.__ddEventTrackerInjected) return;
            window.__ddEventTrackerInjected = true;

            // -- Post message to content script --
            function post(provider, method, args, payload) {
              try {
                window.postMessage({
                  source:   'dd-event-tracker',
                  provider: provider || 'page',
                  method:   method   || 'event',
                  args:     Array.prototype.slice.call(args || []),
                  payload:  payload  || null,
                  ts:       Date.now()
                }, '*');
              } catch (e) {}
            }

            // -- Wrap all standard analytics methods on a provider object --
            var TRACK_METHODS = ['track', 'page', 'identify', 'group', 'alias', 'screen'];

            function wrapProvider(obj, provider) {
              if (!obj || obj.__ddWrapped) return;
              TRACK_METHODS.forEach(function (m) {
                try {
                  var fn = obj[m];
                  if (typeof fn === 'function' && !fn.__ddWrapped) {
                    var wrapped = (function (mName, origFn) {
                      var w = function () {
                        post(provider, mName, arguments);
                        return origFn.apply(this, arguments);
                      };
                      w.__ddWrapped = true;
                      return w;
                    })(m, fn);
                    obj[m] = wrapped;
                  }
                } catch (e) {}
              });
              // Intercept stub-queue push (Segment classic snippet initialises analytics as array)
              try {
                var origPush = obj.push;
                if (typeof origPush === 'function' && !origPush.__ddWrapped) {
                  obj.push = function () {
                    try {
                      var item = arguments[0];
                      if (Array.isArray(item) && item.length >= 1 &&
                          TRACK_METHODS.indexOf(item[0]) !== -1) {
                        post(provider, item[0], Array.prototype.slice.call(item, 1));
                      }
                    } catch (e) {}
                    return origPush.apply(this, arguments);
                  };
                  obj.push.__ddWrapped = true;
                }
              } catch (e) {}
              obj.__ddWrapped = true;
            }

            // -- Hook a global using Object.defineProperty so replacements are caught --
            // This covers Segment analytics-next which replaces window.analytics entirely
            function hookGlobal(globalName, provider) {
              try {
                var _val = window[globalName];
                if (_val) wrapProvider(_val, provider);

                var desc = Object.getOwnPropertyDescriptor(window, globalName);
                if (desc && !desc.configurable) {
                  // Property is non-configurable, fall back to interval
                  throw new Error('non-configurable');
                }

                Object.defineProperty(window, globalName, {
                  configurable: true,
                  enumerable:   true,
                  get: function () { return _val; },
                  set: function (newVal) {
                    _val = newVal;
                    if (newVal && !newVal.__ddWrapped) {
                      wrapProvider(newVal, provider);
                    }
                  }
                });
              } catch (e) {
                // Fallback: poll every 500 ms for up to 60 iterations (30 s)
                var tries = 0;
                var timer = setInterval(function () {
                  if (window[globalName] && !window[globalName].__ddWrapped) {
                    wrapProvider(window[globalName], provider);
                  }
                  tries++;
                  if (tries > 60) clearInterval(timer);
                }, 500);
              }
            }

            hookGlobal('analytics',      'segment');
            hookGlobal('rudderanalytics', 'rudderstack');

            // -- GTM / dataLayer interception --
            function hookDataLayer(obj) {
              if (!obj || obj.__ddDLWrapped) return;
              var origPush = obj.push;
              if (typeof origPush !== 'function' || origPush.__ddWrapped) return;
              obj.push = function () {
                try {
                  for (var i = 0; i < arguments.length; i++) {
                    var item = arguments[i];
                    if (item && typeof item === 'object' && item.event) {
                      post('gtm', 'track', [], { event: item });
                    }
                  }
                } catch (e) {}
                return origPush.apply(this, arguments);
              };
              obj.push.__ddWrapped  = true;
              obj.__ddDLWrapped     = true;
            }

            try {
              if (window.dataLayer) hookDataLayer(window.dataLayer);
              var _dl = window.dataLayer;
              var dlDesc = Object.getOwnPropertyDescriptor(window, 'dataLayer');
              if (!dlDesc || dlDesc.configurable) {
                Object.defineProperty(window, 'dataLayer', {
                  configurable: true,
                  enumerable:   true,
                  get: function () { return _dl; },
                  set: function (newVal) { _dl = newVal; if (newVal) hookDataLayer(newVal); }
                });
              }
            } catch (e) {}

            // -- Network helpers --
            function isTrackedEndpoint(url) {
              try {
                var u = String(url || '');
                // Segment CDN / API (covers all short and long forms)
                if (/api\.segment\.io\/v1\/|\.segment\.com\/v1\/|\.segment\.io\/v1\//.test(u)) return true;
                // Generic v1 analytics paths (long form)
                if (/\/v1\/(?:batch|track|page|identify|screen|group|alias)(?:[/?#]|$)/.test(u)) return true;
                // Short-form Segment API endpoints (/v1/b, /v1/t, /v1/p, /v1/i, /v1/g, /v1/s)
                if (/\/v1\/[btpigs](?:[/?#]|$)/.test(u)) return true;
                return false;
              } catch (e) { return false; }
            }

            function parsePayload(text) {
              if (!text) return null;
              try { return JSON.parse(text); } catch (e) { return null; }
            }

            function emitFromPayload(payload, url) {
              if (!payload) return;
              if (Array.isArray(payload.batch)) {
                payload.batch.forEach(function (item) {
                  post(payload.provider || 'network', item.type || 'batch', [], { url: url, event: item });
                });
                return;
              }
              post(payload.provider || 'network', payload.type || 'event', [], { url: url, event: payload });
            }

            // -- Fetch interception --
            // Read body BEFORE origFetch to avoid Request-body-consumed issues
            try {
              var origFetch = window.fetch;
              if (origFetch && !origFetch.__ddWrapped) {
                var wrappedFetch = function (input, init) {
                  var url = '';
                  try { url = (typeof input === 'string') ? input : (input && input.url ? input.url : ''); } catch (e) {}
                  if (url && isTrackedEndpoint(url)) {
                    try {
                      if (init && typeof init.body === 'string') {
                        // Most common case: fetch(url, { body: JSON.stringify(...) })
                        emitFromPayload(parsePayload(init.body), url);
                      } else if (input instanceof Request) {
                        // Clone before origFetch consumes it
                        input.clone().text().then(function (text) {
                          emitFromPayload(parsePayload(text), url);
                        }).catch(function () {});
                      }
                    } catch (e) {}
                  }
                  return origFetch.apply(this, arguments);
                };
                wrappedFetch.__ddWrapped = true;
                window.fetch = wrappedFetch;
              }
            } catch (e) {}

            // -- XHR interception --
            try {
              var origOpen = XMLHttpRequest.prototype.open;
              var origSend = XMLHttpRequest.prototype.send;
              if (!origOpen.__ddWrapped) {
                XMLHttpRequest.prototype.open = function (method, url) {
                  this.__ddUrl = url;
                  return origOpen.apply(this, arguments);
                };
                XMLHttpRequest.prototype.open.__ddWrapped = true;
              }
              if (!origSend.__ddWrapped) {
                XMLHttpRequest.prototype.send = function (body) {
                  try {
                    if (this.__ddUrl && isTrackedEndpoint(this.__ddUrl)) {
                      var text = body && typeof body === 'string' ? body : '';
                      emitFromPayload(parsePayload(text), this.__ddUrl);
                    }
                  } catch (e) {}
                  return origSend.apply(this, arguments);
                };
                XMLHttpRequest.prototype.send.__ddWrapped = true;
              }
            } catch (e) {}

            // -- Beacon interception --
            try {
              var origBeacon = navigator.sendBeacon;
              if (origBeacon && !origBeacon.__ddWrapped) {
                var wrappedBeacon = function (url, data) {
                  try {
                    if (url && isTrackedEndpoint(url)) {
                      var text = typeof data === 'string' ? data : '';
                      if (text) emitFromPayload(parsePayload(text), url);
                    }
                  } catch (e) {}
                  return origBeacon.apply(this, arguments);
                };
                wrappedBeacon.__ddWrapped = true;
                navigator.sendBeacon = wrappedBeacon;
              }
            } catch (e) {}
          }
        }, function () {
          sendResponse({ ok: !chrome.runtime.lastError });
        });
      } catch (e) {
        sendResponse({ ok: false });
      }
      return true;
    }

    // -- Capture Tab (Screenshot)
    if (msg.action === 'capture_tab') {
      var tab = sender && sender.tab;
      var windowId = tab && tab.windowId ? tab.windowId : chrome.windows.WINDOW_ID_CURRENT;
      chrome.tabs.captureVisibleTab(windowId, { format: 'png' }, function (dataUrl) {
        if (chrome.runtime.lastError || !dataUrl) {
          sendResponse({ ok: false, error: chrome.runtime.lastError ? chrome.runtime.lastError.message : 'capture_failed' });
          return;
        }
        sendResponse({ ok: true, dataUrl: dataUrl });
      });
      return true;
    }

    // -- Download Image
    if (msg.action === 'download_image') {
      var dataUrl = msg.dataUrl || '';
      var filename = msg.filename || 'screenshot.png';
      if (!dataUrl) { sendResponse({ ok: false }); return; }
      try {
        chrome.downloads.download({ url: dataUrl, filename: filename, saveAs: true }, function () {
          sendResponse({ ok: true });
        });
      } catch (e0) {
        sendResponse({ ok: false });
      }
      return true;
    }

    // -- Fetch Script Text
    if (msg.action === 'fetch_script_text') {
      var scriptUrl = msg.url || '';
      if (!scriptUrl) { sendResponse({ ok: false }); return; }
      safeFetch(scriptUrl).then(function (text) {
        sendResponse({ ok: true, text: text || '' });
      }).catch(function () {
        sendResponse({ ok: false });
      });
      return true;
    }

    // -- Get Blocked Scripts
    if (msg.action === 'get_blocked_scripts') {
      var tabId = msg.tabId;
      getBlockedMap(function (map) {
        var blocked = (tabId && map[String(tabId)]) ? map[String(tabId)] : {};
        sendResponse({ blocked: blocked });
      });
      return true;
    }

    // -- Block Script
    if (msg.action === 'block_script') {
      var url = msg.url || '';
      var tabId = msg.tabId;
      if (!url || !tabId) { sendResponse({ ok: false }); return; }
      var baseUrl = normalizeBaseUrl(url);
      var ruleId  = ruleIdFor(baseUrl, tabId);
      try {
        chrome.declarativeNetRequest.updateSessionRules({
          removeRuleIds: [ruleId],
          addRules: [{
            id: ruleId,
            priority: 1,
            action: { type: 'block' },
            condition: { urlFilter: baseUrl, resourceTypes: ['script'], tabIds: [tabId] }
          }]
        }, function () {
          getBlockedMap(function (map) {
            var key = String(tabId);
            if (!map[key]) map[key] = {};
            map[key][baseUrl] = true;
            setBlockedMap(map, function () { sendResponse({ ok: true }); });
          });
        });
      } catch (e) {
        sendResponse({ ok: false });
      }
      return true;
    }

    // -- Unblock Script
    if (msg.action === 'preview_iframe_unblock_enable') {
      var unblockTabId = parseInt(msg.tabId || '0', 10) || 0;
      var unblockUrls = Array.isArray(msg.urls) ? msg.urls : [];
      if (!chrome.declarativeNetRequest) {
        sendResponse({ ok: false, error: 'preview_unblock_unavailable' });
        return;
      }
      enablePreviewFrameRules(unblockTabId, unblockUrls, function (res) {
        sendResponse(res || { ok: false, error: 'preview_unblock_failed' });
      });
      return true;
    }

    if (msg.action === 'preview_iframe_unblock_disable') {
      var clearTabId = parseInt(msg.tabId || '0', 10) || 0;
      if (!chrome.declarativeNetRequest) {
        sendResponse({ ok: true, removed: 0 });
        return;
      }
      clearPreviewFrameRules(clearTabId, function (res2) {
        sendResponse(res2 || { ok: true, removed: 0 });
      });
      return true;
    }

    if (msg.action === 'preview_open_companion_tab') {
      var companionUrl = String(msg.url || '').trim();
      var reportTabId = parseInt(msg.reportTabId || '0', 10) || 0;
      var existingCompanionTabId = parseInt(msg.existingTabId || '0', 10) || 0;
      if (!companionUrl) {
        sendResponse({ ok: false, error: 'missing_url' });
        return;
      }

      function attachBridgeAndRespond(tabObj) {
        if (!tabObj || !tabObj.id) {
          sendResponse({ ok: false, error: 'companion_tab_invalid' });
          return;
        }
        injectCompanionScrollBridgeWhenReady(tabObj.id, reportTabId, function (bridgeRes) {
          sendResponse({
            ok: true,
            tabId: tabObj.id,
            windowId: tabObj.windowId || 0,
            url: tabObj.url || companionUrl,
            bridgeOk: !!(bridgeRes && bridgeRes.ok),
            bridgeError: bridgeRes && bridgeRes.ok ? '' : String((bridgeRes && bridgeRes.error) || '')
          });
        });
      }

      if (existingCompanionTabId) {
        chrome.tabs.get(existingCompanionTabId, function (existingTab) {
          if (!chrome.runtime.lastError && existingTab && existingTab.id) {
            chrome.tabs.update(existingTab.id, { url: companionUrl, active: false }, function (updatedTab) {
              if (chrome.runtime.lastError || !updatedTab || !updatedTab.id) {
                sendResponse({ ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'companion_update_failed' });
                return;
              }
              attachBridgeAndRespond(updatedTab);
            });
            return;
          }
          chrome.tabs.create({ url: companionUrl, active: false }, function (createdTab) {
            if (chrome.runtime.lastError || !createdTab || !createdTab.id) {
              sendResponse({ ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'companion_create_failed' });
              return;
            }
            attachBridgeAndRespond(createdTab);
          });
        });
        return true;
      }

      chrome.tabs.create({ url: companionUrl, active: false }, function (createdTab2) {
        if (chrome.runtime.lastError || !createdTab2 || !createdTab2.id) {
          sendResponse({ ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'companion_create_failed' });
          return;
        }
        attachBridgeAndRespond(createdTab2);
      });
      return true;
    }

    if (msg.action === 'preview_focus_companion_tab') {
      var focusTabId = parseInt(msg.tabId || '0', 10) || 0;
      if (!focusTabId) {
        sendResponse({ ok: false, error: 'invalid_tab' });
        return;
      }
      chrome.tabs.get(focusTabId, function (tab0) {
        if (chrome.runtime.lastError || !tab0 || !tab0.id) {
          sendResponse({ ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'tab_not_found' });
          return;
        }
        chrome.tabs.update(focusTabId, { active: true }, function (tab1) {
          if (chrome.runtime.lastError || !tab1 || !tab1.id) {
            sendResponse({ ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'focus_failed' });
            return;
          }
          if (tab1.windowId) {
            chrome.windows.update(tab1.windowId, { focused: true }, function () {
              sendResponse({ ok: true, tabId: tab1.id, windowId: tab1.windowId });
            });
            return;
          }
          sendResponse({ ok: true, tabId: tab1.id, windowId: 0 });
        });
      });
      return true;
    }

    if (msg.action === 'preview_set_companion_scroll') {
      var companionTabId = parseInt(msg.tabId || '0', 10) || 0;
      var ratioValue = Number(msg.ratio);
      if (!companionTabId) {
        sendResponse({ ok: false, error: 'invalid_tab' });
        return;
      }
      if (!Number.isFinite(ratioValue)) ratioValue = 0;
      if (ratioValue < 0) ratioValue = 0;
      if (ratioValue > 1) ratioValue = 1;

      chrome.tabs.get(companionTabId, function (tab2) {
        if (chrome.runtime.lastError || !tab2 || !tab2.id) {
          sendResponse({ ok: false, error: 'tab_not_found' });
          return;
        }
        chrome.scripting.executeScript({
          target: { tabId: companionTabId },
          func: function (ratioArg) {
            var ratio = Number(ratioArg);
            if (!Number.isFinite(ratio)) ratio = 0;
            if (ratio < 0) ratio = 0;
            if (ratio > 1) ratio = 1;
            var de = document.documentElement || document.body;
            var body = document.body || de;
            var max = Math.max(
              0,
              (de.scrollHeight || 0) - (de.clientHeight || 0),
              (body.scrollHeight || 0) - (body.clientHeight || 0)
            );
            window.__ddCompanionSuppressUntil = Date.now() + 160;
            window.scrollTo(0, Math.round(max * ratio));
            return { ok: true, max: max };
          },
          args: [ratioValue]
        }, function () {
          if (chrome.runtime.lastError) {
            sendResponse({ ok: false, error: chrome.runtime.lastError.message || 'scroll_failed' });
            return;
          }
          sendResponse({ ok: true });
        });
      });
      return true;
    }

    if (msg.action === 'preview_companion_scroll_emit') {
      var reportTabIdForward = parseInt(msg.reportTabId || '0', 10) || 0;
      var ratioForward = Number(msg.ratio);
      if (!Number.isFinite(ratioForward)) ratioForward = 0;
      if (ratioForward < 0) ratioForward = 0;
      if (ratioForward > 1) ratioForward = 1;

      try {
        chrome.runtime.sendMessage({
          action: 'preview_companion_scroll',
          reportTabId: reportTabIdForward,
          ratio: ratioForward,
          top: Number(msg.top) || 0,
          max: Number(msg.max) || 0,
          url: String(msg.url || '')
        }, function () {});
      } catch (e2) {}
      sendResponse({ ok: true });
      return;
    }

    if (msg.action === 'unblock_script') {
      var url2   = msg.url || '';
      var tabId2 = msg.tabId;
      if (!url2 || !tabId2) { sendResponse({ ok: false }); return; }
      var baseUrl2 = normalizeBaseUrl(url2);
      var ruleId2  = ruleIdFor(baseUrl2, tabId2);
      try {
        chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [ruleId2] }, function () {
          getBlockedMap(function (map) {
            var key2 = String(tabId2);
            if (map[key2] && map[key2][baseUrl2]) {
              delete map[key2][baseUrl2];
              if (!Object.keys(map[key2]).length) delete map[key2];
            }
            setBlockedMap(map, function () { sendResponse({ ok: true }); });
          });
        });
      } catch (e3) {
        sendResponse({ ok: false });
      }
      return true;
    }

    // -- Open Screenshot Preview (auto-open after capture)
    if (msg.action === 'open_screenshot_preview') {
      var imgDataUrl = msg.dataUrl || '';
      var imgName    = String(msg.filename || 'screenshot.png').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
      if (!imgDataUrl) { sendResponse({ ok: false }); return; }
      try {
        var imgHtml = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>' + imgName + '</title>' +
          '<style>*{margin:0;padding:0;box-sizing:border-box;}' +
          'body{background:#111;display:flex;flex-direction:column;align-items:center;padding:24px;min-height:100vh;}' +
          '.img-name{color:#888;font-family:system-ui,-apple-system,sans-serif;font-size:12px;margin-bottom:14px;}' +
          'img{max-width:100%;border-radius:6px;box-shadow:0 8px 40px rgba(0,0,0,.65);}' +
          '</style></head><body>' +
          '<div class="img-name">' + imgName + '</div>' +
          '<img src="' + imgDataUrl + '" alt="' + imgName + '">' +
          '</body></html>';
        var reportId2  = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
        var imgKey     = 'dd_report_' + reportId2;
        var imgPayload = {};
        imgPayload[imgKey] = { html: imgHtml, filename: imgName };
        var imgStorage = (chrome.storage && chrome.storage.session) ? chrome.storage.session : chrome.storage.local;
        imgStorage.set(imgPayload, function () {
          var viewUrl = chrome.runtime.getURL('report_viewer.html?rid=' + reportId2);
          chrome.tabs.create({ url: viewUrl }, function () { sendResponse({ ok: true }); });
        });
      } catch (eImg) {
        sendResponse({ ok: false });
      }
      return true;
    }

    // -- Open Report Viewer
    if (msg.action === 'open_report_viewer') {
      var html     = msg.html || '';
      var filename = msg.filename || 'report.html';
      var reportId = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      var key      = 'dd_report_' + reportId;
      var payload  = {};
      payload[key] = { html: html, filename: filename };
      var storage  = (chrome.storage && chrome.storage.session) ? chrome.storage.session : chrome.storage.local;
      storage.set(payload, function () {
        var url = chrome.runtime.getURL('report_viewer.html?rid=' + reportId);
        chrome.tabs.create({ url: url }, function () { sendResponse({ ok: true }); });
      });
      return true;
    }

    // -- Download Report
    if (msg.action === 'download_report') {
      var html     = msg.html || '';
      var filename = msg.filename || 'design_system_report.html';
      try {
        var blob = new Blob([html], { type: 'text/html;charset=utf-8' });
        var url  = URL.createObjectURL(blob);
        chrome.downloads.download({ url: url, filename: filename, saveAs: true }, function () {
          setTimeout(function () { URL.revokeObjectURL(url); }, 10000);
        });
      } catch (e) {}
      sendResponse({ ok: true });
      return;
    }

    // -- Download Asset
    if (msg.action === 'download_asset') {
      var assetUrl = msg.url || '';
      if (!assetUrl) { sendResponse({ ok: false }); return; }
      var assetName = msg.filename || '';
      try {
        var options = { url: assetUrl, saveAs: true };
        if (assetName) options.filename = assetName;
        chrome.downloads.download(options);
      } catch (e2) {}
      sendResponse({ ok: true });
      return;
    }

    if (msg.action === 'qa_probe_assets') {
      var rawAssets = Array.isArray(msg.assets) ? msg.assets : [];
      var seenAssets = {};
      var assets = [];

      rawAssets.forEach(function (item) {
        if (!item || !item.url) return;
        var url = String(item.url || '').trim();
        var type = String(item.type || 'asset').trim();
        if (!url) return;
        var key = type + '|' + url;
        if (seenAssets[key]) return;
        seenAssets[key] = true;
        if (assets.length < 160) assets.push({ url: url, type: type, label: item.label || '' });
      });

      Promise.all(assets.map(qaProbeAsset)).then(function (results) {
        sendResponse({ ok: true, results: results || [] });
      }).catch(function (err) {
        sendResponse({
          ok: false,
          error: (err && err.message) ? err.message : 'qa_probe_failed',
          results: []
        });
      });
      return true;
    }

    // -- Fetch Page for Match Analysis
    if (msg.action === 'fetch_page_for_match') {
      var pageUrl = msg.url || '';
      if (!pageUrl) {
        sendResponse({ ok: false, error: 'No URL provided' });
        return;
      }
      if (!isPageFetchableUrl(pageUrl)) {
        sendResponse({ ok: false, error: 'Unsupported URL. Use https:// or file:// (or full local path via popup).' });
        return;
      }
      safeFetch(pageUrl).then(function (html) {
        if (html) {
          sendResponse({ ok: true, html: html, url: pageUrl });
          return;
        }

        var isFile = getUrlProtocol(pageUrl) === 'file:';
        if (!isFile) {
          sendResponse({ ok: false, error: 'Empty response while fetching page.' });
          return;
        }

        captureRenderedPageHtml(pageUrl, 1200).then(function (snap) {
          if (snap && snap.ok && snap.html) {
            sendResponse({ ok: true, html: snap.html, url: snap.url || pageUrl });
            return;
          }

          isFileSchemeAccessAllowed().then(function (allowed) {
            if (allowed === false) {
              sendResponse({
                ok: false,
                error: 'Could not read local file. Enable "Allow access to file URLs" for this extension in chrome://extensions.'
              });
              return;
            }

            if (allowed === true) {
              sendResponse({
                ok: false,
                error: 'Local file access is enabled, but this file could not be read. Check file path/availability and open the file directly in Chrome once.'
              });
              return;
            }

            sendResponse({
              ok: false,
              error: 'Could not read local file. Verify extension file access and that the file exists.'
            });
          });
        });
      }).catch(function () {
        sendResponse({ ok: false, error: 'Fetch failed' });
      });
      return true;
    }

    // -- Fetch CSS URLs
    if (msg.action === 'capture_rendered_page') {
      var captureUrl = String(msg.url || '').trim();
      var waitMsRaw = Number(msg.waitMs);
      var waitMs = Number.isFinite(waitMsRaw) ? waitMsRaw : 3500;
      waitMs = Math.max(500, Math.min(15000, Math.round(waitMs)));
      if (!captureUrl) {
        sendResponse({ ok: false, error: 'No URL provided' });
        return;
      }

      var captureTabId = null;
      var settled = false;
      var captureScheduled = false;
      var timeoutHandle = null;

      function cleanupCaptureListener() {
        try { chrome.tabs.onUpdated.removeListener(onCaptureTabUpdated); } catch (e0) {}
        if (timeoutHandle) {
          clearTimeout(timeoutHandle);
          timeoutHandle = null;
        }
      }

      function closeCaptureTabIfNeeded() {
        if (!captureTabId || msg.keepTab) return;
        try { chrome.tabs.remove(captureTabId, function () {}); } catch (e1) {}
      }

      function finishCapture(payload) {
        if (settled) return;
        settled = true;
        cleanupCaptureListener();
        closeCaptureTabIfNeeded();
        sendResponse(payload);
      }

      function captureRenderedDomNow() {
        if (settled || !captureTabId) return;
        chrome.scripting.executeScript({
          target: { tabId: captureTabId },
          world: 'MAIN',
          func: function () {
            function serializeDoctype(doc) {
              if (!doc || !doc.doctype) return '<!DOCTYPE html>';
              var dt = doc.doctype;
              var name = dt.name || 'html';
              var publicId = dt.publicId || '';
              var systemId = dt.systemId || '';
              if (publicId) {
                return '<!DOCTYPE ' + name + ' PUBLIC "' + publicId + '"' + (systemId ? (' "' + systemId + '"') : '') + '>';
              }
              if (systemId) {
                return '<!DOCTYPE ' + name + ' SYSTEM "' + systemId + '">';
              }
              return '<!DOCTYPE ' + name + '>';
            }

            try {
              var html = document.documentElement ? document.documentElement.outerHTML : '';
              if (!html) return { ok: false, error: 'Empty DOM snapshot' };
              return {
                ok: true,
                url: location.href,
                title: document.title || '',
                readyState: document.readyState || '',
                doctype: serializeDoctype(document),
                html: html
              };
            } catch (err) {
              return { ok: false, error: (err && err.message) ? err.message : String(err) };
            }
          }
        }, function (results) {
          if (chrome.runtime.lastError) {
            finishCapture({ ok: false, error: 'Snapshot failed: ' + chrome.runtime.lastError.message });
            return;
          }
          var snap = results && results[0] ? results[0].result : null;
          if (!snap || !snap.ok || !snap.html) {
            finishCapture({ ok: false, error: (snap && snap.error) ? snap.error : 'Snapshot failed' });
            return;
          }
          finishCapture({
            ok: true,
            source: 'rendered',
            url: snap.url || captureUrl,
            title: snap.title || '',
            readyState: snap.readyState || '',
            doctype: snap.doctype || '<!DOCTYPE html>',
            html: snap.html
          });
        });
      }

      function scheduleCapture() {
        if (captureScheduled || settled) return;
        captureScheduled = true;
        setTimeout(captureRenderedDomNow, waitMs);
      }

      function onCaptureTabUpdated(tabId, changeInfo) {
        if (tabId !== captureTabId) return;
        if (changeInfo && changeInfo.status === 'complete') scheduleCapture();
      }

      timeoutHandle = setTimeout(function () {
        finishCapture({ ok: false, error: 'Timed out while rendering page snapshot.' });
      }, 45000);

      chrome.tabs.onUpdated.addListener(onCaptureTabUpdated);
      chrome.tabs.create({ url: captureUrl, active: false }, function (tab) {
        if (chrome.runtime.lastError || !tab || !tab.id) {
          finishCapture({ ok: false, error: 'Unable to open URL for rendered capture.' });
          return;
        }
        captureTabId = tab.id;
        if (tab.status === 'complete') scheduleCapture();
      });

      return true;
    }

    if (msg.action === 'fetch_text_urls') {
      var textUrls = Array.isArray(msg.urls) ? msg.urls : [];
      if (!textUrls.length) { sendResponse({ items: [] }); return; }
      Promise.all(textUrls.map(function (url) {
        if (!isTextFetchableUrl(url)) {
          return Promise.resolve({ url: url, ok: false, text: '', error: 'unsupported_scheme' });
        }
        return safeFetch(url).then(function (text) {
          return { url: url, ok: !!text, text: text || '' };
        }).catch(function () {
          return { url: url, ok: false, text: '' };
        });
      })).then(function (items) {
        sendResponse({ items: items });
      }).catch(function () {
        sendResponse({ items: [] });
      });
      return true;
    }

    if (msg.action === 'fetch_assets_datauri') {
      var assetUrls = Array.isArray(msg.urls) ? msg.urls : [];
      var maxBytes = Number(msg.maxBytes);
      if (!assetUrls.length) { sendResponse({ items: [] }); return; }
      Promise.all(assetUrls.map(function (url) {
        if (!isHttpNetworkUrl(url)) {
          return Promise.resolve({ ok: false, url: url, error: 'unsupported_scheme' });
        }
        return safeFetchAssetAsDataUri(url, maxBytes);
      })).then(function (items) {
        sendResponse({ items: items });
      }).catch(function () {
        sendResponse({ items: [] });
      });
      return true;
    }

    if (msg.action !== 'fetch_css_urls') return;
    var urls = Array.isArray(msg.urls) ? msg.urls : [];
    if (!urls.length) { sendResponse({ items: [] }); return; }
    Promise.all(urls.map(function (url) {
      if (!isTextFetchableUrl(url)) {
        return Promise.resolve({ url: url, css: '' });
      }
      return safeFetch(url).then(function (css) { return { url: url, css: css || '' }; });
    })).then(function (items) {
      sendResponse({ items: items });
    }).catch(function () {
      sendResponse({ items: [] });
    });
    return true;
  });
})();
