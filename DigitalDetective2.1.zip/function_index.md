﻿# FUNCTION INDEX - Digital Detective v2.1.0

> **Arquitetura:** Chrome Extension Manifest V3 (popup + content script + service worker + paginas de relatorio)
> **Status deste indice:** alinhado com o build atual `v2.1.0`
> **Atualizado em:** 2026-04-20

---

## BUSCA RAPIDA

**Precisa mexer em:**
- **Versao, permissoes MV3 e recursos expostos?** -> `manifest.json`
- **Mensageria global, downloads, fetch e bloqueio de scripts?** -> `background.js`
- **UI principal do popup (16 ferramentas + paineis)?** -> `popup.html`, `popup.js`
- **Picker, color picker, screenshot, DS extraction, coleta de scripts/CSS e QA snapshot?** -> `content.js`
- **Design system visual compartilhado dos relatorios?** -> `report_utils.js`, `template_ds.html`
- **Abrir relatorio salvo em nova aba?** -> `report_viewer.html`, `report_viewer.js`
- **DS Extractor dedicado?** -> `ds_extractor.html`, `ds_extractor.js`
- **Component Blueprinter?** -> `blueprinter.html`, `blueprinter.js`
- **Match Analysis?** -> `match_analysis.html`, `match_analysis.js`
- **Script Match?** -> `script_match.html`, `script_match.js`
- **Static Builder?** -> `static_builder.html`, `static_builder.js`
- **Quick Updater?** -> `quick_updater.html`, `quick_updater.js`
- **Lighthouse report?** -> `lighthouse_report.html`, `lighthouse_report.js`
- **SEO report?** -> `seo_report.html`, `seo_report.js`
- **AEO report?** -> `aeo_report.html`, `aeo_report.js`
- **QA Scan?** -> `qa_report.html`, `qa_report.js`
- **Deep Cleaner?** -> `popup.html`, `popup.js`, `manifest.json`
- **Icones PNG a partir do SVG?** -> `create_icons.py`, `icon.svg`, `icons/*`

---

## ESTRUTURA GERAL

```text
Digital Detective v2.1/
  manifest.json
  popup.html
  popup.js
  content.js
  background.js

  report_utils.js
  report_viewer.html
  report_viewer.js
  template_ds.html

  ds_extractor.html
  ds_extractor.js
  blueprinter.html
  blueprinter.js
  match_analysis.html
  match_analysis.js
  script_match.html
  script_match.js
  static_builder.html
  static_builder.js
  quick_updater.html
  quick_updater.js
  lighthouse_report.html
  lighthouse_report.js
  seo_report.html
  seo_report.js
  aeo_report.html
  aeo_report.js
  qa_report.html
  qa_report.js

  create_icons.py
  icon.svg
  icons/icon16.png
  icons/icon48.png
  icons/icon128.png

  README.md
  CLAUDE.md
  function_index.md
  .claude/settings.local.json
```

---

## CORE DA EXTENSAO

### manifest.json
**Funcao:** configuracao MV3, permissoes, popup, service worker e paginas expostas.

**Pontos principais:**
- `name` e `version` alinhados em `2.1.0`
- permissao `cookies` habilitada para listagem e remocao de cookies via popup
- `background.service_worker` -> `background.js`
- `action.default_popup` -> `popup.html`
- `content_scripts` -> injeta `content.js` em `http/https`
- `host_permissions` -> `http://*/*`, `https://*/*`, `file://*/*`
- `web_accessible_resources` -> expoe relatorios e ferramentas dedicadas, incluindo `qa_report.html` e `qa_report.js`

### background.js
**Funcao:** service worker central para fetch, downloads, regras de bloqueio, abertura de relatorios e apoio ao QA Scan.

**Responsabilidades principais:**
- fetch resiliente e utilitarios para conteudo remoto
- persistencia de scripts bloqueados
- criacao e remocao de regras `declarativeNetRequest`
- abertura de relatorios em nova aba
- download de arquivos e assets
- probing remoto de assets para o QA Scan
- fetch de HTML e CSS para Match / Script Match / Static Builder

**Acoes atendidas via `chrome.runtime.onMessage`:**
- `event_tracker_inject` - linha 529
- `capture_tab` - linha 783
- `download_image` - linha 797
- `fetch_script_text` - linha 812
- `get_blocked_scripts` - linha 824
- `block_script` - linha 834
- `unblock_script` - linha 1043
- `open_report_viewer` - linha 1097
- `download_report` - linha 1113
- `download_asset` - linha 1128
- `qa_probe_assets` - linha 1141
- `fetch_page_for_match` - linha 1170
- `fetch_css_urls` - linha 1387

### popup.html
**Funcao:** UI principal da extensao.

**Estado atual do popup:**
- grid com **16 ferramentas**
- paineis inline para fluxos rapidos
- modal de ajuda
- footer visivel padronizado em `Digital Detective v2.1.0`

**Ferramentas expostas no grid:**
1. Screenshot
2. Color Picker
3. Element Picker
4. Component Blueprinter
5. DS Extractor
6. Match Analysis
7. SEO Analysis
8. AEO Analysis
9. Lighthouse Audit
10. QA Scan
11. Script Finder
12. Script Match
13. Event Tracker
14. Deep Cleaner
15. Static Builder
16. Quick Updater

### popup.js
**Funcao:** controlador do popup, valida entradas, injeta/coleta dados na aba ativa e abre paginas dedicadas.

**Blocos principais:**
- helpers de status e UX
- resize automatico do popup
- roteamento dos paineis
- orquestracao de screenshots
- execucao de DS, Blueprinter, Match, Lighthouse, SEO, AEO e QA
- carregamento, renderizacao e bloqueio de scripts
- polling do Event Tracker

**Funcoes-chave confirmadas no build atual:**
- `setShotStatus(...)` - linha 151
- `setScriptStatus(...)` - linha 181
- `setQaStatus(...)` - linha 247
- `setStaticBuilderStatus(...)` - linha 269
- `startEventPolling(tab)` - linha 347
- `renderEvents(events)` - linha 364
- `startScreenshot(mode)` - linha 425
- `runDsPageFromPopup()` - linha 484
- `runDsHtmlFromPopup()` - linha 498
- `runBlueprinterFromPopup()` - linha 523
- `startElementPicker()` - linha 552
- `startColorPicker()` - linha 580
- `startXpathPicker()` - linha 596
- `togglePanel(...)` - linha 660
- `validateMatchUrls()` - linha 831
- `validateScriptMatchUrls()` - linha 861
- `populateStaticBuilderPanel()` - linha 886
- `validateStaticBuilderUrl()` - linha 896
- `loadScripts()` - linha 1023
- `renderScripts(...)` - linha 1041
- `collectSeoSignals()` - linha 1132
- `collectAeoSignals()` - linha 1269

**Integracoes relevantes do popup:**
- `QA Scan` abre `qa_report.html?tabId=...&url=...&probe=...`
- `SEO` e `AEO` usam `chrome.scripting.executeScript(...)` para coletar sinais antes de abrir o relatorio
- `Script Finder` depende do par `content.js` + `background.js`
- `Deep Cleaner` usa `chrome.cookies.getAllCookieStores()`, `chrome.cookies.getAll()`, `chrome.cookies.remove()` e `chrome.scripting.executeScript(...)` diretamente no popup
- `Static Builder`, `Match Analysis`, `Script Match` e `Quick Updater` usam paginas dedicadas

### content.js
**Funcao:** engine injetada na pagina. Concentra captura visual, pickers, extracao de CSS/DS, coleta de scripts, event tracking e snapshot deterministico para QA.

**Blocos principais:**
- Picker / XPath
- Color Picker
- Event Tracker
- Screenshot
- Design System / CSS extraction
- Script discovery
- QA page scan
- listener central de mensagens

**Funcoes-chave confirmadas no build atual:**
- `captureVisibleScreenshot(options)` - linha 1140
- `captureFullPageScreenshot(options)` - linha 1162
- `captureComponentScreenshot(el, options)` - linha 1265
- `collectAllCss()` - linha 1402
- `detectScriptVendor(url, code)` - linha 1552
- `collectScripts()` - linha 1578
- `filterCssByRoot(allCss, root)` - linha 1859
- `generateReport(data)` - linha 2430
- `collectScopedMetrics(rootEl, scopedCss)` - linha 2950
- `generateScopedReport(opts)` - linha 3234
- `runScopedExtraction(rootEl)` - linha 3571
- `runScopedExtractionFromHtml(html)` - linha 3625

**Acoes atendidas no listener principal:**
- `collect_scripts` - linha 4092
- `qa_scan_page` - linha 4113
- `extract_ds_html` - linha 4130
- `extract_ds_scope` - linha 4144
- `toggle_picker` - linha 4150
- `toggle_picker_xpath` - linha 4156
- `start_color_picker` - linha 4167
- `event_tracker_toggle` - linha 4173
- `event_tracker_get` - linha 4186
- `collect_css` - linha 4191
- `collect_css_raw` - linha 4211
- `extract_ds` - linha 4228

**Nota importante:**
- `qa_scan_page` e o ponto de entrada do QA deterministico. Ele devolve `snapshot` da pagina e resultados do `safe interaction probe`, consumidos por `qa_report.js`.

---

## INFRA DE RELATORIOS

### report_utils.js
**Funcao:** utilitarios compartilhados de UI, colapso de secoes, download e preview.

**Responsabilidades principais:**
- aplicar design system visual de relatorios
- sincronizar setas de collapse
- gerar download HTML / Blob
- bind de botoes de salvar
- bind de modal de codigo
- download de preview em iframe

### report_viewer.html
**Funcao:** shell para renderizar relatorios temporarios salvos em storage.

### report_viewer.js
**Funcao:** carrega payload `dd_report_*`, injeta HTML salvo e reaplica os utilitarios compartilhados.

### template_ds.html
**Funcao:** template visual base do design system dos relatorios.

**Contem:**
- tokens CSS compartilhados
- secoes padrao de resultados
- script inline para collapse/expand

---

## FERRAMENTAS E PAGINAS DEDICADAS

### ds_extractor.html + ds_extractor.js
**Funcao:** fluxo dedicado para extrair Design System da pagina inteira ou de HTML colado.

**Fluxo base:**
- envia acao para `content.js`
- recebe HTML do relatorio
- abre no `report_viewer`

### blueprinter.html + blueprinter.js
**Funcao:** gera blueprint de componente a partir de `source URL + component HTML`.

**Capacidades centrais:**
- sanitizacao de HTML
- reescrita de assets/CSS
- coleta de CSS da aba
- download de assets
- preview desktop/mobile
- edicao de copy e CTA

### match_analysis.html + match_analysis.js
**Funcao:** compara duas paginas e calcula score ponderado por layout, estilo, estrutura e infraestrutura.

**Categorias analisadas:**
- fonts
- colors
- buttons
- hover
- layout
- navigation
- footer
- typography
- sections
- tech stack / infra

### script_match.html + script_match.js
**Funcao:** compara scripts entre duas URLs.

**Estrategia:**
1. match exato por URL normalizada
2. fallback soft match por filename

### static_builder.html + static_builder.js
**Funcao:** gera uma copia HTML estatica com CSS inline e URLs absolutos.

**Preserva:**
- estrutura HTML
- tags SEO
- links e assets reescritos para caminho absoluto

### quick_updater.html + quick_updater.js
**Funcao:** edicao rapida de HTML local com comparacao lado a lado e save do resultado atualizado.

**Capacidades centrais:**
- edicao de copy e propriedades visuais
- configuracao de `href` para qualquer elemento editavel
- toggles de link para `noindex`, `nofollow` e `target _blank`
- auto-aplicacao de `rel="noopener noreferrer"` quando `target _blank` estiver ativo

### lighthouse_report.html + lighthouse_report.js
**Funcao:** consome a API do PageSpeed Insights para renderizar score, metricas e auditorias desktop/mobile.

### seo_report.html + seo_report.js
**Funcao:** auditoria SEO em 5 pilares com score e recomendacoes priorizadas.

**Pilares:**
- Indexability
- On-Page SEO
- Content Quality
- Semantic SEO
- Media & Links

### aeo_report.html + aeo_report.js
**Funcao:** auditoria AEO (Answer Engine Optimization) focada em answer readiness e extractability.

**Pilares:**
- Eligibility
- Answerability
- Semantic clarity
- Citation / extraction readiness
- Coverage

### qa_report.html + qa_report.js
**Funcao:** executa e renderiza o QA Scan deterministico da aba de origem.

**Objetivos do QA Scan:**
- detectar assets quebrados
- detectar erros JS, `unhandledrejection` e `console.error`
- identificar formularios e links suspeitos
- rodar um pequeno `safe interaction probe`
- calcular score unico de saude da pagina

**Funcoes-chave confirmadas no build atual:**
- `setStatus(message, type)` - linha 30
- `sendToTab(tabId, payload)` - linha 110
- `ensureQaBridgeInMainWorld(tabId)` - linha 157
- `buildAssetProbeList(snapshot)` - linha 221
- `createAssetIndex(results)` - linha 240
- `probeAssetsWithProgress(assets)` - linha 249
- `collectFindings(snapshot, interactions, assetResults)` - linha 277
- `openReportSection(sectionId)` - linha 385
- `bindSummaryCards()` - linha 406
- `renderReport(snapshot, interactions, assetResults, findings)` - linha 439
- `runScan()` - linha 677

**Arquitetura do QA Scan:**
- `qa_report.js` instala uma bridge no `MAIN world` para ouvir erros reais da pagina
- `content.js` coleta snapshot estrutural e resultados do probe
- `background.js` faz probing remoto de assets via `qa_probe_assets`
- o relatorio consolida score, findings e navegacao por cards sticky

### Deep Cleaner (popup.html + popup.js + manifest.json)
**Funcao:** lista cookies do store atual do browser, permite filtro `Current Site Only`, selecao multipla, `Select All` na lista visivel e remocao em lote via `Deep Clean`, com opcao de limpar `localStorage` do site ativo.

**Pontos principais:**
- requer permissao `cookies` no `manifest.json`
- resolve o `storeId` pelo tab ativo com `chrome.cookies.getAllCookieStores()`
- lista cookies do store atual com `chrome.cookies.getAll(...)`
- filtra por hostname do site atual sem limitar por path da pagina
- remove cookies selecionados com `chrome.cookies.remove(...)`
- limpa `localStorage` do tab ativo com `chrome.scripting.executeScript(...)`

---

## ARQUIVOS DE SUPORTE

### create_icons.py
**Funcao:** gera `icons/icon16.png`, `icon48.png`, `icon128.png`.

**Estrategia de fallback:**
1. CairoSVG
2. Pillow
3. geracao PNG em stdlib

### icon.svg
**Funcao:** fonte vetorial do icone da extensao.

### icons/*.png
**Funcao:** icones finais usados pelo Chrome.

### README.md
**Funcao:** overview do projeto, changelog, instalacao e uso.

### CLAUDE.md
**Funcao:** regras operacionais e contexto tecnico do projeto.

### .claude/settings.local.json
**Funcao:** permissoes/configuracao local do ambiente assistido.

### scripts `.ps1`
**Funcao:** utilitarios auxiliares para diagnostico e correcao de encoding/titulos/moedas/entidades.

---

## FLUXOS DE EXECUCAO

### 1) Fluxo principal do popup
```text
popup.html (botao/painel) -> popup.js
  -> sendToTab(...) para content.js
  -> ou chrome.runtime.sendMessage(...) para background.js
  -> ou abre pagina dedicada (chrome.runtime.getURL + chrome.tabs.create)
```

### 2) DS Extractor
```text
popup.js / ds_extractor.js -> content.js action: extract_ds | extract_ds_html
  -> collectAllCss + analise DS
  -> generateReport(...) ou generateScopedReport(...)
  -> background.js open_report_viewer
  -> report_viewer.html / report_viewer.js renderizam
```

### 3) Blueprinter
```text
popup.js -> blueprinter.html
  -> blueprinter.js sanitiza HTML + coleta CSS/assets
  -> renderBlueprint(...)
  -> preview desktop/mobile + download de assets
```

### 4) Screenshot
```text
popup.js startScreenshot(mode) -> content.js screenshot_start
  -> background.js capture_tab
  -> content.js compoe imagem final
  -> opcional: preview em nova aba / download
```

### 5) Match / Script Match / Static Builder
```text
report page JS -> background.js fetch_page_for_match / fetch_css_urls
  -> parsing e processamento local
  -> render do relatorio ou da pagina estatica
```

### 6) SEO / AEO
```text
popup.js -> chrome.scripting.executeScript(...) na aba ativa
  -> coleta de sinais renderizados
  -> grava dd_seo_data / dd_aeo_data em chrome.storage.local
  -> abre seo_report.html / aeo_report.html
  -> report JS consome storage, calcula score e renderiza
```

### 7) QA Scan
```text
popup.js -> qa_report.html?tabId=...&probe=...
  -> qa_report.js runScan()
  -> instala bridge de erro em MAIN world
  -> content.js action: qa_scan_page
  -> background.js action: qa_probe_assets
  -> qa_report.js consolida findings, score e secoes navegaveis
```

---

## ESTATISTICAS DO SCAN

- **Total de arquivos no projeto (recursivo):** 49
- **Arquivos textuais:** 45
- **Arquivos binarios:** 4
- **Linhas textuais totais:** 26.544
- **Funcoes declaradas (`function` / `async function` / `def`):** 752
- **Arquivos JS com maior densidade funcional:**
  - `content.js`: 147 funcoes
  - `match_analysis.js`: 93 funcoes
  - `popup.js`: 89 funcoes
  - `blueprinter.js`: 53 funcoes
  - `qa_report.js`: 34 funcoes

---

## NOTAS TECNICAS IMPORTANTES

- O projeto esta **alinhado em `v2.1.0`** em `manifest.json`, `README.md`, popup e superficies visiveis.
- O popup atual expoe **16 ferramentas**, nao 14.
- `QA Scan` e a principal adicao estrutural em relacao ao indice antigo de `v2.0.3`.
- `Deep Cleaner` adiciona uma nova superficie destrutiva; a UX usa confirmacao antes do `Deep Clean`.
- `host_permissions` ja incluem `file://*/*`, mas `content_scripts` continuam sendo injetados automaticamente apenas em `http/https`.
- O acoplamento principal do projeto continua sendo o contrato de mensagens `msg.action` entre `popup.js`, `content.js`, `background.js` e paginas dedicadas.
- Mudancas em nomes de acoes exigem revisao cruzada dos pontos emissores e consumidores.
- Este arquivo substitui a versao antiga do indice que estava com **defasagem de versao** e **problemas de encoding**.

---

**Versao do indice:** 2.0
**Data:** 2026-04-02
**Status:** atualizado para o build `2.1.0`


