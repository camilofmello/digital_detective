# fix_entities.ps1
# Replaces HTML entity strings in .js files with JS unicode escapes.
# HTML entities only work in innerHTML -- in textContent/document.title they show literally.
# Safe: unicode escapes like \u2014 work in ALL JS string contexts (innerHTML, textContent, title).
# Skips content.js which has intentional entity patterns in normalizeEncodingArtifacts().

$base = 'C:\Users\camil\OneDrive\Documentos\Profissional\OutSystems2026\Automations\Digital Detective v2.0'

# Only .js files, exclude content.js (has intentional entity regexes) and helper scripts
$files = Get-ChildItem -Path "$base\*" -Include '*.js' |
         Where-Object { $_.Name -notmatch '^(content|fix_|verify_|inspect_|find_|diagnose_)' }

# Each entry: [HTML entity, JS unicode escape or safe ASCII]
$replacements = @(
  @( '&mdash;',  '\u2014' ),   # em-dash    —
  @( '&ndash;',  '\u2013' ),   # en-dash    -
  @( '&hellip;', '\u2026' ),   # ellipsis   ...
  @( '&bull;',   '\u2022' ),   # bullet     *
  @( '&middot;', '\u00B7' ),   # middle dot
  @( '&lsquo;',  '\u2018' ),   # left single quote
  @( '&rsquo;',  '\u2019' ),   # right single quote
  @( '&ldquo;',  '\u201C' ),   # left double quote
  @( '&rdquo;',  '\u201D' ),   # right double quote
  @( '&copy;',   '\u00A9' ),   # copyright
  @( '&reg;',    '\u00AE' ),   # registered
  @( '&deg;',    '\u00B0' ),   # degree
  # Numeric entity emojis placed in JS strings by fix_encoding.ps1
  @( '&#x26A0;&#xFE0F;', '\u26A0\uFE0F' ),  # warning sign + variation selector
  @( '&#x26A0;', '\u26A0' ),
  @( '&#x2705;', '\u2705' ),
  @( '&#x274C;', '\u274C' ),
  @( '&#x2713;', '\u2713' ),
  @( '&#x25B2;', '\u25B2' ),
  @( '&#x25BC;', '\u25BC' ),
  @( '&#x1F6A8;', '\uD83D\uDEA8' ),
  @( '&#x1F53A;', '\uD83D\uDD3A' ),
  @( '&#x1F517;', '\uD83D\uDD17' ),
  @( '&#x1F4CA;', '\uD83D\uDCCA' ),
  @( '&#x1F534;', '\uD83D\uDD34' ),
  @( '&#x1F7E1;', '\uD83D\uDFE1' ),
  @( '&#x1F4A1;', '\uD83D\uDCA1' ),
  @( '&#x1F9E9;', '\uD83E\uDDE9' )
)

$totalFixed = 0

foreach ($file in $files) {
  $content = [System.IO.File]::ReadAllText($file.FullName, [System.Text.Encoding]::UTF8)
  $original = $content

  foreach ($pair in $replacements) {
    if ($content.Contains($pair[0])) {
      $count = ([regex]::Matches($content, [regex]::Escape($pair[0]))).Count
      $content = $content.Replace($pair[0], $pair[1])
      Write-Host "  -> $($file.Name): replaced $count x '$($pair[0])' with '$($pair[1])'"
    }
  }

  if ($content -ne $original) {
    [System.IO.File]::WriteAllText($file.FullName, $content, (New-Object System.Text.UTF8Encoding $false))
    $totalFixed++
    Write-Host "FIXED: $($file.Name)"
  }
}

Write-Host ""
Write-Host "Done. Files with at least 1 replacement: $totalFixed / $($files.Count)"
