$base = 'C:\Users\camil\OneDrive\Documentos\Profissional\OutSystems2026\Automations\Digital Detective v2.0'
$targets = @('blueprinter.js','content.js','outsystems_pricing_live.html','script_match.js')

foreach ($name in $targets) {
  $path = Join-Path $base $name
  $text = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)
  Write-Host "=== $name ==="
  $matches = [regex]::Matches($text, [char]0x00E2)
  $shown = @{}
  foreach ($m in $matches) {
    $pos = $m.Index
    $end = [Math]::Min($pos + 5, $text.Length)
    # Build key from 3 chars
    $key = ''
    for ($i = $pos; $i -lt $end; $i++) {
      $cp = [int]$text[$i]
      $key += "U+$($cp.ToString('X4')) "
    }
    if (-not $shown.ContainsKey($key)) {
      $shown[$key] = 0
      $ctx = $text.Substring([Math]::Max(0,$pos-10), [Math]::Min(30, $text.Length - [Math]::Max(0,$pos-10)))
      $ctx = $ctx -replace "`r|`n", ' '
      Write-Host "  Pattern: $key"
      Write-Host "  Context: [$ctx]"
    }
    $shown[$key]++
  }
  foreach ($k in $shown.Keys) { Write-Host "  Count for '$k': $($shown[$k])" }
  Write-Host ""
}
