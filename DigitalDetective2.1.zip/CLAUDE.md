﻿# CLAUDE.md - Digital Detective v2.1.0

## PermissÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes de OperaÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o

VocÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âª tem **100% de permissÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o** para realizar qualquer operaÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o dentro desta pasta sem pedir autorizaÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o:

- Ler qualquer arquivo
- Criar novos arquivos
- Editar arquivos existentes
- Sobrescrever arquivos
- Apagar arquivos
- Renomear ou mover arquivos

Nunca peÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§a confirmaÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o para operaÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes de leitura, escrita, ediÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o ou exclusÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o dentro deste diretÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio.

---

## Protocolo ObrigatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio de InÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â­cio de Tarefa

**Antes de qualquer implementaÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o, sempre:**

1. Ler `function_index.md` para mapear interdependÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âªncias, localizar as funÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes afetadas e entender o impacto da mudanÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§a em toda a arquitetura.
2. Identificar os arquivos que serÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o alterados e quais funÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes existentes podem ser reutilizadas.
3. Confirmar o entendimento antes de gerar cÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³digo, se houver ambiguidade.

---

## PrincÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â­pios de Qualidade de CÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³digo

### Modularidade
- Cada funcionalidade deve ser isolada em seu prÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³prio mÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³dulo (arquivo `.html` + `.js` dedicado).
- Novas ferramentas nunca devem embutir lÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³gica dentro de `popup.js` alÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©m do mÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â­nimo necessÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡rio (validaÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o de input + abertura de aba).
- LÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³gica de anÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡lise, scoring e renderizaÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o de relatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio fica exclusivamente no arquivo da ferramenta.

### Isolamento de MÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³dulos
- MÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³dulos de relatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio (ex: `script_match.js`, `seo_report.js`) nÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o dependem uns dos outros.
- UtilitÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡rios compartilhados ficam exclusivamente em `report_utils.js`.
- ComunicaÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o entre mÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³dulos ocorre apenas via `chrome.runtime.sendMessage` com aÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes nomeadas (`msg.action`).

### OtimizaÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o de FunÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes
- Antes de criar uma nova funÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o, verificar se jÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡ existe uma equivalente em `report_utils.js`, `content.js` ou no mÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³dulo alvo.
- FunÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes genÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©ricas reutilizÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡veis (helpers, formatadores, escape HTML) devem estar em `report_utils.js`.
- Evitar duplicaÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o de lÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³gica entre mÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³dulos.

### Retrocompatibilidade
- FunÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes existentes nÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o sÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o alteradas em sua assinatura sem necessidade explÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â­cita.
- Novas aÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes de mensagem (`msg.action`) sÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o sempre adicionadas, nunca renomeadas.
- O contrato `popup.js ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â content.js ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â background.js` deve permanecer estÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡vel.
- Nada ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â© removido sem instruÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o explÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â­cita do usuÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡rio.

---

## Regras de Desenvolvimento

1. Arquivos sempre entregues **completos** ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â nunca trechos, nunca parciais.
2. Retrocompatibilidade ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â© obrigatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³ria ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â nada ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â© removido sem instruÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o explÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â­cita.
3. FunÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes nÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o relacionadas ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â  alteraÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o permanecem **intactas**.
4. Em caso de erro, inserir `console.log` nos pontos-chave antes de tentar nova soluÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o.
5. SoluÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o mais simples e direta ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â© sempre preferÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â­vel.
6. VersÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o atual: **v2.1.0** ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â formato obrigatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio: `major.minor.patch` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â footer padrÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o: `Digital Detective v2.1.0 ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â· Developed by Camilo Mello`

---

## Regra Global de Encoding UTF-8 (OBRIGATORIA - nunca ignorar)

NUNCA usar caracteres nao-ASCII diretamente em arquivos HTML.
Sempre usar HTML entities para qualquer caracter especial no source code.

**Substituicoes obrigatorias em HTML:**
- em-dash -> `&mdash;`
- en-dash -> `&ndash;`
- reticencias -> `&hellip;`
- ponto central -> `&middot;`
- espaco fixo -> `&nbsp;`

**Regras estruturais:**
1. `<meta charset="UTF-8" />` deve ser o **PRIMEIRO elemento** dentro de `<head>` (antes do title, viewport, tudo)
2. Comentarios CSS e JS devem usar somente ASCII: `/* -- Header -- */` NUNCA `/* -- Header -- */` com chars especiais
3. O arquivo `.editorconfig` desta pasta enforce `charset = utf-8` + `end_of_line = lf`
4. Para reparar arquivos corrompidos: executar `fix_encoding.ps1` na raiz do projeto (faz replace global de todos os HTMLs)

**Como identificar corrupcao:** caracteres como `a-circunflexo + euro + aspas` = em-dash corrompido.
Cada vez que uma pagina exibe `ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬"` onde deveria aparecer um traco, o arquivo tem bytes UTF-8 double-encoded.

---

## Protocolo ObrigatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio de Encerramento de Tarefa

**ApÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³s toda implementaÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o concluÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â­da, sempre:**

1. Atualizar `function_index.md` para refletir:
   - Novas funÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes adicionadas (nome + linha atual no arquivo).
   - FunÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes alteradas (novo nÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âºmero de linha se moveu).
   - Novos arquivos criados (adicionÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡-los ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â  estrutura e ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â s seÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes correspondentes).
   - Atualizar estatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â­sticas (total de funÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes, linhas, arquivos).
2. Atualizar a seÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o `ÃƒÆ’Ã‚Â¢Ãƒâ€¦Ã‚Â¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã‚Â¯Ãƒâ€šÃ‚Â¸Ãƒâ€šÃ‚Â NOTAS TÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â°CNICAS IMPORTANTES` se houver algo novo a registrar.
3. Atualizar o campo `**VersÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o do ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â­ndice**` e `**Data**` no rodapÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â© do `function_index.md`.

---

## Projeto

**Digital Detective v2.1.0** ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â Chrome Extension (MV3) para inspeÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o, diagnÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³stico e anÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡lise de pÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡ginas web.

### Ferramentas do plugin
1. Color Picker
2. Screenshot
3. Element Picker
4. DS Extractor
5. Component Blueprinter
6. Match Analysis
7. Lighthouse Audit
8. SEO Analysis
9. AEO Analysis
10. Event Tracker
11. Script Finder
12. Script Match
13. Static Builder

### Arquivos principais
- `manifest.json` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â configuraÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â£o MV3, permissÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes, web_accessible_resources
- `popup.html` + `popup.js` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â UI principal, grid de ferramentas, painÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â©is
- `content.js` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â scripts injetados na pÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡gina ativa
- `background.js` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â service worker, fetch de pÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡ginas, bloqueio de scripts
- `report_utils.js` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â utilitÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¡rios compartilhados de relatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio (Save HTML)
- `static_builder.html` + `static_builder.js` &mdash; Static Builder (HTML estatico, CSS inline, URLs absolutas)
- `function_index.md` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â­ndice completo de funÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âµes, interdependÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Âªncias e fluxos
- `match_analysis.html` + `match_analysis.js` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â relatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio Match Analysis
- `script_match.html` + `script_match.js` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â relatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio Script Match
- `seo_report.html` + `seo_report.js` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â relatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio SEO
- `aeo_report.html` + `aeo_report.js` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â relatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio AEO
- `lighthouse_report.html` + `lighthouse_report.js` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â relatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio Lighthouse
- `blueprinter.html` + `blueprinter.js` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â relatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio Component Blueprinter
- `ds_extractor.html` + `ds_extractor.js` ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â relatÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â³rio DS Extractor

