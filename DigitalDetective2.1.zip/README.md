﻿# Digital Detective v2.1.0

Chrome extension (Manifest V3) for web intelligence, QA, and frontend diagnostics.

## Changelog

### v2.1.0 - 2026-04-20

**Version alignment and corrections**

- Updated extension versioning to `2.1.0` in `manifest.json` and visible plugin/report surfaces.
- Standardized footer and signature version text to `Digital Detective v2.1.0`.
- Updated project documentation paths/references from `Digital Detective v2.0` to `Digital Detective v2.1`.

### v2.0.17 - 2026-04-13

**Color Picker refactor**

- Rebuilt the Color Picker activation flow around a single page prompt: `click to activate magnifier`.
- The magnifier now opens only from that explicit page click.
- The selected HEX value is copied directly to the clipboard.
- Removed the misleading `Color picker cancelled` message from the active flow.

### v2.0.16 - 2026-04-13

**PDF export and Color Picker stabilization**

- Added `SAVE PDF` next to `SAVE HTML` across generated report surfaces.
- Expanded report sections for complete PDF output.
- Hardened Color Picker messaging and EyeDropper activation flow.
- Updated visible versioning across current plugin surfaces to `2.0.16`.

### v2.0.15 - 2026-04-02

**Quick Updater link editing**

- Added link editing to `Quick Updater` for editable elements, including `href`, `noindex`, `nofollow`, and `target _blank`.
- Empty `href` now removes link behavior; filled `href` applies link behavior in preview and saved HTML.
- Added automatic `rel="noopener noreferrer"` when `target _blank` is enabled.
- Kept documentation and visible versioning aligned at `2.0.15`.

### v2.0.14 - 2026-03-31

**Popup tool order refinement**

- Reordered the popup tool grid to match the current preferred workflow grouping.
- Kept documentation and visible versioning aligned at `2.0.14`.

### v2.0.13 - 2026-03-31

**Deep Cleaner local storage support**

- Renamed `Deep Cookie Cleaner` to `Deep Cleaner`.
- Added an optional `Clear Local Storage` toggle so `Deep Clean` can clear `localStorage` for the active site tab.
- Added `Select All` support for the currently visible cookie list.
- Standardized visible versioning to `2.0.13`.

### v2.0.12 - 2026-03-31

**Deep Cookie Cleaner**

- Added `Deep Cookie Cleaner` to inspect browser cookies from the current store, filter them to the active site, and remove selected entries in one pass.
- Added the `cookies` permission to support cookie listing and deletion.
- Updated the popup tool grid and help content to include the new cleaner.
- Standardized visible versioning to `2.0.12`.

### v2.0.11 - 2026-03-23

**QA Scan and documentation alignment**

- Added `QA Scan`, a deterministic page QA audit for broken assets, JavaScript/load errors, suspicious forms and links, and safe interaction smoke checks.
- Added `qa_report.html` and `qa_report.js`.
- Added sticky clickable summary cards in the QA report.
- Improved QA wording so sections explain checked, passed, fails, and result more clearly.
- Standardized visible versioning to `2.0.11`.
- Cleaned and aligned this `README.md` with the current build.

### v2.0.3 - 2026-03-10

**New Feature: Script Match**

- Added `Script Match` to compare two pages and identify common scripts, scripts missing from page B, and scripts exclusive to page B.
- Added a new `Script Match` button to the popup tool grid.
- Added a dedicated full report page via `script_match.html`.
- Implemented a two-pass matching strategy: exact URL match first, then soft match by filename.
- Added vendor/library detection for common third-party scripts.

### v2.0.2 - 2026-03-08

**Bug fixes and improvements**

- Fixed `Color Picker` user-activation timing for `EyeDropper.open()`.
- Simplified the `Color Picker` flow to reduce clicks.
- Fixed RGB/RGBA parsing fallback in the color conversion logic.
- Added `Open after capture` toggle to `Screenshot`.
- Added `Element XPath` mode to `Element Picker`.

## Overview

Digital Detective centralizes 16 tools in one plugin UI:

1. Screenshot
2. Color Picker
3. Element Picker
4. Component Blueprinter
5. DS Extractor
6. Match Analysis
7. SEO Analysis
8. AEO Analysis
9. Lighthouse Audit
10. QA Scan
11. Script Finder
12. Script Match
13. Event Tracker
14. Deep Cleaner
15. Static Builder
16. Quick Updater

The extension opens interactive panels from the popup and generates visual reports in new tabs.

## Main Features

- Unified popup with a tool grid and inline workflow panels.
- Tooltip descriptions on hover for each tool button.
- Full-page and scoped Design System reports.
- Component blueprint generation from pasted HTML.
- Side-by-side match analysis for two URLs.
- Lighthouse, SEO, and AEO audit reports.
- QA scan for assets, JS/load errors, forms, links, and safe click smoke tests.
- Event inspection for Segment/Rudderstack-style payloads.
- Script discovery, copy, block, and re-enable flow.
- Cookie inspection, current-site filtering, optional localStorage cleanup, and selected-cookie cleanup.
- Static page generation with CSS inlining and absolute URL rewriting.
- Local HTML updating with side-by-side comparison and save flow.

## Tech Stack

- Chrome Extension Manifest V3
- Vanilla JavaScript
- HTML + CSS
- Chrome APIs: `tabs`, `scripting`, `downloads`, `storage`, `cookies`, `declarativeNetRequest`

## Project Structure

```text
Digital Detective v2.1/
|-- manifest.json
|-- popup.html
|-- popup.js
|-- content.js
|-- background.js
|-- blueprinter.html
|-- blueprinter.js
|-- ds_extractor.html
|-- ds_extractor.js
|-- match_analysis.html
|-- match_analysis.js
|-- lighthouse_report.html
|-- lighthouse_report.js
|-- seo_report.html
|-- seo_report.js
|-- aeo_report.html
|-- aeo_report.js
|-- qa_report.html
|-- qa_report.js
|-- script_match.html
|-- script_match.js
|-- static_builder.html
|-- static_builder.js
|-- quick_updater.html
|-- quick_updater.js
|-- template_ds.html
|-- report_utils.js
|-- report_viewer.html
|-- report_viewer.js
`-- icons/
```

## Installation (Developer Mode)

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select this project folder: `Digital Detective v2.1`.
5. Pin the extension and open the popup.

## How To Use

1. Open any HTTP or HTTPS page.
2. Click the extension icon.
3. Hover a tool to see its description.
4. Click a tool button to run it directly or expand its panel.
5. Run the selected action.

## Reports

The extension can generate reports such as:

- `design_system_report.html`
- `design_system_report_scoped.html`
- `component-blueprint.html`
- `seo_report_*.html`
- `lighthouse_performance_*.html`
- `aeo_report_*.html`
- `qa_report.html`
- `*_Script_Match_Report_*.html`
- `template_ds.html`

Reports are generated on demand and can be saved locally via each report's `SAVE HTML` button.

## Permissions

From `manifest.json`:

- `activeTab`: run actions on the current tab.
- `scripting`: inject or execute scripts when needed.
- `downloads`: save generated files.
- `storage`: persist plugin settings and cached data.
- `cookies`: inspect and remove cookies from the current browser store.
- `tabs`: read the active tab URL and open report tabs.
- `declarativeNetRequest`: support script blocking and request rules.
- `declarativeNetRequestWithHostAccess`: support host-aware request rules.
- `host_permissions` (`http://*/*`, `https://*/*`, `file://*/*`): inspect web pages and local files when allowed.

## Development Notes

- Reload the extension in `chrome://extensions` after code changes.
- Keep files in UTF-8 and avoid mixed encodings.
- Keep UI and report standards consistent with the `2.1.0` build.
- Update versioning in code and visible plugin surfaces on every relevant release.

## Version

- Current: **v2.1.0**
- Version format: `major.minor.patch`
- Footer standard: `Digital Detective v2.1.0 - Developed by Camilo Mello`

## Author

Camilo Mello  
camilofmello@gmail.com




