function Chars([int[]]$codepoints) {
  return [System.String]::new(($codepoints | ForEach-Object { [char]$_ }))
}

$base = 'C:\Users\camil\OneDrive\Documentos\Profissional\OutSystems2026\Automations\Digital Detective v2.0'

# Fix currency symbols in outsystems_pricing_live.html only
$path = Join-Path $base 'outsystems_pricing_live.html'
$content = [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8)
$original = $content

# Euro U+20AC (E2 82 AC): 82->U+201A(CP1252 0x82), AC->U+00AC
$euroCorrupt = Chars @(0x00E2, 0x201A, 0x00AC)
$content = $content.Replace($euroCorrupt, '&euro;')

# Philippine peso U+20B1 (E2 82 B1): 82->U+201A, B1->U+00B1
$pesoCorrupt = Chars @(0x00E2, 0x201A, 0x00B1)
$content = $content.Replace($pesoCorrupt, '&#x20B1;')

# Indian rupee U+20B9 (E2 82 B9): 82->U+201A, B9->U+00B9
$rupeeCorrupt = Chars @(0x00E2, 0x201A, 0x00B9)
$content = $content.Replace($rupeeCorrupt, '&#x20B9;')

if ($content -ne $original) {
  [System.IO.File]::WriteAllText($path, $content, (New-Object System.Text.UTF8Encoding $false))
  Write-Host 'FIXED: outsystems_pricing_live.html'
} else {
  Write-Host 'No changes needed in outsystems_pricing_live.html'
}

Write-Host 'Done.'
