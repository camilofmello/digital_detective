# inspect_bytes.ps1
# Shows exact bytes and codepoints of a string containing corrupted characters

$base = 'C:\Users\camil\OneDrive\Documentos\Profissional\OutSystems2026\Automations\Digital Detective v2.0'

# Read seo_report.js raw bytes
$path = Join-Path $base 'seo_report.js'
$rawBytes = [System.IO.File]::ReadAllBytes($path)

# Also read as UTF-8 string
$utf8Text = [System.Text.Encoding]::UTF8.GetString($rawBytes)

Write-Host "=== File size: $($rawBytes.Length) bytes ==="
Write-Host ""

# Find "Critical Issues" in the file
$idx = $utf8Text.IndexOf('Critical Issues')
if ($idx -ge 0) {
  Write-Host "Found 'Critical Issues' at char index $idx"
  # Show 30 chars before it
  $start = [Math]::Max(0, $idx - 30)
  $snippet = $utf8Text.Substring($start, [Math]::Min(60, $utf8Text.Length - $start))
  Write-Host "Context: [$snippet]"
  Write-Host ""
  # Show codepoints of the 10 chars before "Critical"
  Write-Host "Codepoints of chars before 'Critical Issues':"
  $beforeStart = [Math]::Max(0, $idx - 10)
  for ($i = $beforeStart; $i -lt $idx; $i++) {
    $ch = $utf8Text[$i]
    $cp = [int]$ch
    Write-Host "  [$i] U+$($cp.ToString('X4')) '$ch'"
  }
}

Write-Host ""

# Find "document.title" line
$titleIdx = $utf8Text.IndexOf("document.title = 'SEO")
if ($titleIdx -ge 0) {
  Write-Host "Found document.title at char $titleIdx"
  $snippet2 = $utf8Text.Substring($titleIdx, [Math]::Min(80, $utf8Text.Length - $titleIdx))
  Write-Host "Content: [$snippet2]"
  Write-Host ""
  # Show codepoints of the full string
  $endIdx = $utf8Text.IndexOf("'", $titleIdx + 22)
  if ($endIdx -gt $titleIdx) {
    Write-Host "Codepoints in title string:"
    for ($i = $titleIdx; $i -le $endIdx + 5; $i++) {
      $ch = $utf8Text[$i]
      $cp = [int]$ch
      if ($cp -gt 127) {
        Write-Host "  [$i] U+$($cp.ToString('X4')) '$ch' <-- NON-ASCII"
      }
    }
  }
}

Write-Host ""

# Show what's around "â€" (em-dash corruption) in seo_report.js
$emDashIdx = $utf8Text.IndexOf([char]0x00E2)
if ($emDashIdx -ge 0) {
  Write-Host "Found U+00E2 (a-circumflex, first byte of corrupted em-dash) at $emDashIdx"
  $ctx = $utf8Text.Substring([Math]::Max(0,$emDashIdx-10), 25)
  Write-Host "Context: [$ctx]"
  Write-Host "Next 5 codepoints after U+00E2:"
  for ($i = $emDashIdx; $i -lt [Math]::Min($emDashIdx+5, $utf8Text.Length); $i++) {
    $ch = $utf8Text[$i]
    $cp = [int]$ch
    Write-Host "  [$i] U+$($cp.ToString('X4'))"
  }
}
