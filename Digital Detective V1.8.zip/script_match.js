(function () { 'use strict';

  /* ══════════════════════════════════════════════
     HELPERS
  ══════════════════════════════════════════════ */

  function esc(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function scoreClass(n) {
    if (n >= 75) return 'chip-ok';
    if (n >= 40) return 'chip-warn';
    return 'chip-bad';
  }

  function fmtDate() {
    var d = new Date();
    var mo = String(d.getMonth() + 1).padStart(2, '0');
    var dy = String(d.getDate()).padStart(2, '0');
    var yr = d.getFullYear();
    var hh = String(d.getHours()).padStart(2, '0');
    var mm = String(d.getMinutes()).padStart(2, '0');
    return mo + '/' + dy + '/' + yr + ' ' + hh + ':' + mm;
  }

  function shortHost(url) {
    try { return new URL(url).hostname.replace(/^www\./, ''); }
    catch (e) { return url; }
  }

  function buildFilename(urlA, urlB) {
    function slug(url) {
      try { return new URL(url).hostname.replace(/^www\./, '').replace(/[^a-zA-Z0-9.-]/g, '_'); }
      catch (e) { return 'site'; }
    }
    var d  = new Date();
    var mo = String(d.getMonth() + 1).padStart(2, '0');
    var dy = String(d.getDate()).padStart(2, '0');
    var yr = d.getFullYear();
    return slug(urlA) + '_X_' + slug(urlB) + '_Script_Match_Report_' + mo + '_' + dy + '_' + yr + '.html';
  }

  /* ══════════════════════════════════════════════
     VENDOR DETECTION
  ══════════════════════════════════════════════ */

  var VENDOR_RULES = [
    [/google-analytics\.com|googletagmanager\.com\/gtag|analytics\.js/, 'Google Analytics / GTM'],
    [/googletagmanager\.com\/gtm\.js/, 'Google Tag Manager'],
    [/connect\.facebook\.net|fbevents\.js/, 'Facebook Pixel'],
    [/js\.stripe\.com|stripe\.js/, 'Stripe'],
    [/cdn\.segment\.com|segment\.io/, 'Segment'],
    [/rudderlabs\.com|rudderanalytics/, 'Rudderstack'],
    [/cdn\.amplitude\.com|amplitude\.js/, 'Amplitude'],
    [/cdn\.mixpanel\.com|mixpanel\.js/, 'Mixpanel'],
    [/hotjar\.com|hjSetting/, 'Hotjar'],
    [/intercom\.io|intercomcdn\.com/, 'Intercom'],
    [/zendesk\.com|zopim\.com/, 'Zendesk'],
    [/freshworks\.com|freshdesk\.com/, 'Freshworks'],
    [/cdn\.hubspot\.com|hs-scripts\.com|hscta\.net/, 'HubSpot'],
    [/js\.hs-scripts\.com/, 'HubSpot'],
    [/drift\.com|js\.driftt\.com/, 'Drift'],
    [/cdn\.onesignal\.com/, 'OneSignal'],
    [/pusher\.com/, 'Pusher'],
    [/twilio\.com/, 'Twilio'],
    [/cloudflare\.com\/|cdnjs\.cloudflare\.com/, 'Cloudflare CDN'],
    [/unpkg\.com/, 'unpkg CDN'],
    [/jsdelivr\.net/, 'jsDelivr CDN'],
    [/ajax\.googleapis\.com/, 'Google APIs CDN'],
    [/jquery[.-](\d+\.?)+\.?(min\.)?js/, 'jQuery'],
    [/jquery\.min\.js|jquery\.js/, 'jQuery'],
    [/bootstrap[.-](\d+\.?)+\.(min\.)?js|bootstrap\.bundle/, 'Bootstrap'],
    [/react[.-](\d+\.?)+\.(min\.)?js|react\.production|react\.development/, 'React'],
    [/react-dom/, 'React DOM'],
    [/vue[.-](\d+\.?)+\.(min\.)?js|vue\.global|vue\.esm/, 'Vue.js'],
    [/angular[.-](\d+\.?)+\.(min\.)?js|@angular\/core/, 'Angular'],
    [/svelte[.-]/, 'Svelte'],
    [/next[.-](\d+\.?)+\.(min\.)?js|_next\/static/, 'Next.js'],
    [/nuxt[.-](\d+\.?)+|_nuxt\//, 'Nuxt.js'],
    [/lodash[.-](\d+\.?)+\.(min\.)?js|lodash\.min\.js/, 'Lodash'],
    [/axios[.-](\d+\.?)+\.(min\.)?js|axios\.min\.js/, 'Axios'],
    [/moment[.-](\d+\.?)+\.(min\.)?js|moment\.min\.js/, 'Moment.js'],
    [/chart[.-](\d+\.?)+\.(min\.)?js|chart\.umd\.js/, 'Chart.js'],
    [/d3[.-](\d+\.?)+\.(min\.)?js|d3\.min\.js/, 'D3.js'],
    [/three[.-](\d+\.?)+\.(min\.)?js|three\.min\.js/, 'Three.js'],
    [/gsap[.-](\d+\.?)+|TweenMax|TweenLite|greensock/, 'GSAP'],
    [/swiper[.-](\d+\.?)+\.(min\.)?js|swiper\.min\.js/, 'Swiper'],
    [/slick[.-](\d+\.?)+\.(min\.)?js|slick\.min\.js/, 'Slick'],
    [/owl\.carousel/, 'Owl Carousel'],
    [/sentry[.-]|sentry\.io/, 'Sentry'],
    [/rollbar[.-](\d+\.?)+|rollbar\.min\.js/, 'Rollbar'],
    [/datadog-rum|datadoghq\.com/, 'Datadog RUM'],
    [/newrelic\.com|newrelic\.js/, 'New Relic'],
    [/cookiebot\.com|cookielaw\.org/, 'Cookie Consent'],
    [/onetrust\.com/, 'OneTrust'],
    [/iubenda\.com/, 'Iubenda'],
    [/recaptcha|google\.com\/recaptcha/, 'reCAPTCHA'],
    [/matomo\.js|piwik\.js/, 'Matomo'],
    [/plausible\.io\/js/, 'Plausible Analytics'],
    [/fathom-events\.js|usefathom\.com/, 'Fathom Analytics'],
    [/clarity\.ms/, 'Microsoft Clarity'],
    [/livechat\.com|livechatinc\.com/, 'LiveChat'],
    [/crisp\.chat|crisp-website\.js/, 'Crisp'],
    [/tawk\.to|tawkto\.js/, 'Tawk.to'],
    [/outsystemscloud\.com|outsystems\.js|OutSystemsUIWeb/, 'OutSystems'],
    [/salesforce\.com|force\.com|pardot\.com/, 'Salesforce'],
    [/marketo\.net|marketo\.com/, 'Marketo'],
    [/eloqua\.com/, 'Oracle Eloqua'],
    [/heap\.io|heapanalytics\.com/, 'Heap'],
    [/fullstory\.com|fs\.js/, 'FullStory'],
    [/logrocket\.com/, 'LogRocket'],
    [/mouseflow\.com/, 'Mouseflow'],
    [/smartlook\.com/, 'Smartlook'],
    [/inspectlet\.com/, 'Inspectlet'],
    [/luckyorange\.com/, 'Lucky Orange'],
    [/paypal\.com\/sdk/, 'PayPal SDK'],
    [/adyen\.com/, 'Adyen'],
    [/braintreegateway\.com/, 'Braintree'],
    [/maps\.googleapis\.com|google\.com\/maps/, 'Google Maps'],
    [/youtube\.com\/iframe_api|youtube\.com\/player/, 'YouTube Player API'],
    [/vimeo\.com\/api\/player/, 'Vimeo Player API'],
    [/wistia\.com|wistia\.net/, 'Wistia'],
    [/jwplayer\.com|jwplatform\.com/, 'JW Player'],
    [/videojs\.com|video\.js/, 'Video.js'],
    [/cloudinary\.com/, 'Cloudinary'],
    [/imgix\.net/, 'Imgix'],
    [/optimizely\.com/, 'Optimizely'],
    [/launchdarkly\.com/, 'LaunchDarkly'],
    [/split\.io/, 'Split.io'],
    [/algolia\.net|algolia\.com/, 'Algolia'],
    [/elastic\.co|elasticsearch/, 'Elasticsearch'],
    [/getbootstrap\.com|maxcdn\.bootstrapcdn\.com/, 'Bootstrap CDN'],
    [/popper\.js|popper\.min\.js/, 'Popper.js'],
    [/fontawesome\.com|font-awesome/, 'Font Awesome'],
    [/material-ui|mui\.com/, 'MUI / Material UI'],
    [/tailwindcss\.com|tailwind\.js/, 'Tailwind'],
    [/shopify\.com\/s\/files|shopify\.js/, 'Shopify'],
    [/magento\.com|mage\//, 'Magento'],
    [/woocommerce\.js|woo-variation/, 'WooCommerce'],
    [/prebid\.js|prebid\.org/, 'Prebid.js'],
    [/doubleclick\.net|googlesyndication\.com/, 'Google Ads / DoubleClick'],
    [/adsense\.google\.com|adsbygoogle/, 'Google AdSense'],
    [/criteo\.com|criteo\.net/, 'Criteo'],
    [/taboola\.com/, 'Taboola'],
    [/outbrain\.com/, 'Outbrain'],
    [/linkedin\.com\/insight\.min\.js|linkedin-insight/, 'LinkedIn Insight'],
    [/twitter\.com\/widgets\.js|platform\.twitter\.com/, 'Twitter / X Widget'],
    [/instagram\.com\/embed\.js/, 'Instagram Embed'],
    [/tiktok\.com\/api\/open\/embed/, 'TikTok Embed'],
    [/pinterest\.com\/js\/pinit\.js/, 'Pinterest Widget'],
    [/app\.usercentrics\.eu/, 'Usercentrics'],
    [/trustarc\.com/, 'TrustArc'],
    [/cookieconsent\.js|cookieconsent\.min\.js/, 'Cookie Consent'],
    [/ab-tasty\.com|abtasty\.js/, 'AB Tasty'],
    [/vwo\.com|visualwebsiteoptimizer/, 'VWO'],
    [/kameleoon\.com/, 'Kameleoon'],
    [/crazy-egg\.com/, 'Crazy Egg']
  ];

  function detectVendor(url) {
    var u = String(url || '');
    for (var i = 0; i < VENDOR_RULES.length; i++) {
      if (VENDOR_RULES[i][0].test(u)) return VENDOR_RULES[i][1];
    }
    return '';
  }

  /* ══════════════════════════════════════════════
     SCRIPT EXTRACTION FROM HTML
  ══════════════════════════════════════════════ */

  function normalizeScriptUrl(src, baseUrl) {
    if (!src) return '';
    // Remove query string and hash for matching purposes
    try {
      var abs = new URL(src, baseUrl).href;
      return abs;
    } catch (e) {
      return src;
    }
  }

  function getMatchKey(url) {
    // Key used for cross-page matching: filename without version/hash/query
    // e.g. https://cdn.example.com/v3.1.2/jquery.min.js → jquery.min.js
    try {
      var path = new URL(url).pathname;
      var filename = path.split('/').slice(-1)[0] || '';
      // Strip common version patterns: .3.6.0. or -3.6.0- from filename
      filename = filename.replace(/[-.](\d+\.){1,4}\d+(\.min)?/g, '');
      // Strip hash suffixes: filename.abc123def.js
      filename = filename.replace(/\.[a-f0-9]{6,32}\.(js|mjs)$/, '.$2');
      // Normalise extension
      filename = filename.toLowerCase();
      if (!filename || filename === '.js' || filename === '.mjs') {
        // Fall back to full path without protocol + domain
        return new URL(url).pathname.toLowerCase();
      }
      return filename;
    } catch (e) {
      return String(url).split('/').slice(-1)[0].split('?')[0].toLowerCase();
    }
  }

  function extractScriptsFromHtml(html, baseUrl) {
    var doc;
    try { doc = new DOMParser().parseFromString(html, 'text/html'); }
    catch (e) { return []; }

    var list = [];
    var seen = {};

    doc.querySelectorAll('script[src]').forEach(function (scr) {
      var src = scr.getAttribute('src') || '';
      if (!src) return;
      var abs = normalizeScriptUrl(src, baseUrl);
      if (!abs) return;
      if (seen[abs]) return;
      seen[abs] = true;
      var vendor = detectVendor(abs);
      var filename = abs.split('/').slice(-1)[0].split('?')[0].split('#')[0] || abs;
      list.push({
        url: abs,
        name: vendor || filename || abs,
        vendor: vendor,
        filename: filename,
        matchKey: getMatchKey(abs)
      });
    });

    return list;
  }

  /* ══════════════════════════════════════════════
     SCRIPT COMPARISON
  ══════════════════════════════════════════════ */

  function compareScripts(scriptsA, scriptsB) {
    // Build lookup maps
    var exactA = {};
    var exactB = {};
    var keyA   = {};
    var keyB   = {};

    scriptsA.forEach(function (s) {
      exactA[s.url]      = s;
      keyA[s.matchKey]   = keyA[s.matchKey] || s;
    });
    scriptsB.forEach(function (s) {
      exactB[s.url]      = s;
      keyB[s.matchKey]   = keyB[s.matchKey] || s;
    });

    var common = [];
    var onlyA  = [];
    var onlyB  = [];

    var matchedBKeys = {};
    var matchedAUrls = {};

    // First pass: exact URL matches
    scriptsA.forEach(function (s) {
      if (exactB[s.url]) {
        common.push({ a: s, b: exactB[s.url], matchType: 'exact' });
        matchedAUrls[s.url]     = true;
        matchedBKeys[exactB[s.url].url] = true;
      }
    });

    // Second pass: soft matches by filename key (excluding already matched)
    scriptsA.forEach(function (s) {
      if (matchedAUrls[s.url]) return;
      var mk = s.matchKey;
      if (mk && keyB[mk] && !matchedBKeys[keyB[mk].url]) {
        common.push({ a: s, b: keyB[mk], matchType: 'soft' });
        matchedAUrls[s.url]         = true;
        matchedBKeys[keyB[mk].url]  = true;
      }
    });

    // Remaining: only in A
    scriptsA.forEach(function (s) {
      if (!matchedAUrls[s.url]) onlyA.push(s);
    });

    // Remaining: only in B
    scriptsB.forEach(function (s) {
      if (!matchedBKeys[s.url]) onlyB.push(s);
    });

    // Score: Jaccard (intersection / union)
    var union = scriptsA.length + scriptsB.length - common.length;
    var score = union > 0 ? Math.round(common.length / union * 100) : (scriptsA.length === 0 && scriptsB.length === 0 ? 100 : 0);

    return {
      common: common,
      onlyA:  onlyA,
      onlyB:  onlyB,
      score:  score,
      totalA: scriptsA.length,
      totalB: scriptsB.length
    };
  }

  /* ══════════════════════════════════════════════
     RENDER REPORT
  ══════════════════════════════════════════════ */

  function renderReport(urlA, urlB, result) {
    var score    = result.score;
    var common   = result.common;
    var onlyA    = result.onlyA;
    var onlyB    = result.onlyB;
    var totalA   = result.totalA;
    var totalB   = result.totalB;
    var sc       = scoreClass(score);
    var genTime  = fmtDate();

    /* ── Score card summary rows ── */
    function summaryRow(label, count, total, cls) {
      var pct  = total > 0 ? Math.round(count / total * 100) : 0;
      var barW = pct;
      return '<div class="sm-summary-row">' +
        '<div class="sm-summary-label">' + esc(label) + '</div>' +
        '<div class="sm-bar-wrap"><div class="sm-bar ' + cls + '" style="width:' + barW + '%"></div></div>' +
        '<div class="sm-summary-pct ' + cls + '">' + count + '</div>' +
      '</div>';
    }

    var totalUnion = totalA + totalB - common.length;

    var scoreCard =
      '<div class="sm-score-card">' +
        '<div class="sm-score-left">' +
          '<div class="sm-score-num ' + sc + '">' + score + '%</div>' +
          '<div class="sm-score-label">Script Match</div>' +
        '</div>' +
        '<div class="sm-summary">' +
          summaryRow('Scripts in Common', common.length, totalUnion || 1, scoreClass(common.length / Math.max(totalUnion, 1) * 100)) +
          summaryRow('Only in A (Control)', onlyA.length, totalUnion || 1, onlyA.length > 0 ? 'chip-warn' : 'chip-ok') +
          summaryRow('Only in B (New Page)', onlyB.length, totalUnion || 1, onlyB.length > 0 ? 'chip-warn' : 'chip-ok') +
          '<div class="sm-url-pair">' +
            '<div class="sm-url-pill"><span>A</span>' + esc(shortHost(urlA)) + ' (' + totalA + ' scripts)</div>' +
            '<div class="sm-url-pill"><span>B</span>' + esc(shortHost(urlB)) + ' (' + totalB + ' scripts)</div>' +
          '</div>' +
        '</div>' +
      '</div>';

    /* ── Block builder ── */
    function blockChip(count, type) {
      if (type === 'common') return '<span class="sm-chip chip-ok">' + count + ' matched</span>';
      if (type === 'onlyA')  return '<span class="sm-chip chip-warn">' + count + ' missing from B</span>';
      if (type === 'onlyB')  return '<span class="sm-chip chip-warn">' + count + ' extra in B</span>';
      return '<span class="sm-chip chip-neutral">' + count + '</span>';
    }

    /* ── Common scripts block ── */
    function renderCommonItem(entry) {
      var s     = entry.a;
      var sb    = entry.b;
      var soft  = entry.matchType === 'soft';
      var nameA = s.vendor || s.filename || s.url;
      var nameB = sb.vendor || sb.filename || sb.url;
      var displayName = s.vendor || (soft && sb.vendor) || s.filename;
      var matchNote = soft
        ? '<div class="sm-script-match-note">Soft match by filename (different URL/version)</div>'
        : '';
      return '<div class="sm-script-item">' +
        '<div class="sm-script-icon icon-ok">check_circle</div>' +
        '<div class="sm-script-info">' +
          '<div class="sm-script-name">' + esc(displayName) + '</div>' +
          '<div class="sm-script-url">A: ' + esc(s.url) + '</div>' +
          (soft ? '<div class="sm-script-url">B: ' + esc(sb.url) + '</div>' : '') +
          matchNote +
        '</div>' +
        '<span class="sm-script-badge badge-both">Both</span>' +
      '</div>';
    }

    /* ── Only A / Only B item ── */
    function renderSingleItem(s, badge, icon, iconCls) {
      var name = s.vendor || s.filename || s.url;
      return '<div class="sm-script-item">' +
        '<div class="sm-script-icon ' + iconCls + '">' + icon + '</div>' +
        '<div class="sm-script-info">' +
          '<div class="sm-script-name">' + esc(name) + '</div>' +
          '<div class="sm-script-url">' + esc(s.url) + '</div>' +
        '</div>' +
        '<span class="sm-script-badge ' + badge + '">' + (badge === 'badge-a' ? 'A only' : 'B only') + '</span>' +
      '</div>';
    }

    function buildBlock(id, title, chipHtml, bodyHtml, collapsed) {
      return '<div class="sm-block' + (collapsed ? ' sm-collapsed' : '') + '" id="' + id + '">' +
        '<div class="sm-block-head">' +
          '<div class="sm-block-title">' + title + '</div>' +
          '<div class="sm-block-actions">' +
            chipHtml +
            '<button class="sm-collapse-btn" type="button">&#9650;</button>' +
          '</div>' +
        '</div>' +
        '<div class="sm-block-body">' + bodyHtml + '</div>' +
      '</div>';
    }

    /* Common block */
    var commonBody = common.length
      ? common.map(renderCommonItem).join('')
      : '<div class="sm-empty-note">No common scripts found between the two pages.</div>';
    var commonBlock = buildBlock('sm-block-common', 'Common Scripts', blockChip(common.length, 'common'), commonBody, false);

    /* Only A block */
    var onlyABody = onlyA.length
      ? onlyA.map(function (s) { return renderSingleItem(s, 'badge-a', 'warning', 'icon-warn'); }).join('')
      : '<div class="sm-empty-note">All scripts from A are also present in B.</div>';
    var onlyABlock = buildBlock('sm-block-onlya', 'Missing from B (Only in A — Control)', blockChip(onlyA.length, 'onlyA'), onlyABody, onlyA.length === 0);

    /* Only B block */
    var onlyBBody = onlyB.length
      ? onlyB.map(function (s) { return renderSingleItem(s, 'badge-b', 'info', 'icon-bad'); }).join('')
      : '<div class="sm-empty-note">No extra scripts found in B.</div>';
    var onlyBBlock = buildBlock('sm-block-onlyb', 'Extra in B (Not in A — New Page)', blockChip(onlyB.length, 'onlyB'), onlyBBody, onlyB.length === 0);

    /* ── Full page HTML ── */
    var html =
      '<div class="sm-page">' +
        '<div class="sm-header">' +
          '<div class="sm-header-left">' +
            '<span class="sm-logo">keyboard_command_key</span>' +
            '<div class="sm-title-wrap">' +
              '<div class="sm-title">Script Match</div>' +
              '<a class="sm-url-link" href="' + esc(urlA) + '" target="_blank" rel="noopener">A: ' + esc(urlA) + '</a>' +
              '<a class="sm-url-link" href="' + esc(urlB) + '" target="_blank" rel="noopener">B: ' + esc(urlB) + '</a>' +
              '<div class="sm-gen-time">Generated ' + genTime + '</div>' +
            '</div>' +
          '</div>' +
          '<div class="sm-header-btns">' +
            '<button class="sm-save-btn" id="sm-save-btn" type="button">Save Report</button>' +
          '</div>' +
        '</div>' +
        scoreCard +
        commonBlock +
        onlyABlock +
        onlyBBlock +
        '<div class="sm-footer">Digital Detective &nbsp;&middot;&nbsp; Script Match Report &nbsp;&middot;&nbsp; Developed by Camilo Mello</div>' +
      '</div>';

    /* ── Inject into DOM ── */
    var root    = document.getElementById('sm-root');
    var loading = document.getElementById('sm-loading');
    if (loading) loading.style.display = 'none';
    if (root) {
      root.innerHTML = html;
      root.style.display = '';
    }

    /* ── Collapse buttons ── */
    root.querySelectorAll('.sm-collapse-btn').forEach(function (btn) {
      var block = btn.closest('.sm-block');
      if (block) btn.textContent = block.classList.contains('sm-collapsed') ? '\u25BC' : '\u25B2';
      btn.addEventListener('click', function () {
        var blockEl   = btn.closest('.sm-block');
        if (!blockEl) return;
        var collapsed = blockEl.classList.toggle('sm-collapsed');
        btn.textContent = collapsed ? '\u25BC' : '\u25B2';
      });
    });

    /* ── Save button ── */
    var saveBtn = root.querySelector('#sm-save-btn');
    if (saveBtn && window.DDReportUtils) {
      window.DDReportUtils.bindSaveButton(saveBtn, buildFilename(urlA, urlB));
    }
  }

  /* ══════════════════════════════════════════════
     STATUS
  ══════════════════════════════════════════════ */

  function setStatus(msg, isError) {
    var el = document.getElementById('sm-status-text');
    if (el) el.textContent = msg;
    if (isError) {
      var spinner = document.querySelector('.sm-spinner');
      if (spinner) spinner.style.display = 'none';
    }
  }

  /* ══════════════════════════════════════════════
     MAIN
  ══════════════════════════════════════════════ */

  function run() {
    var params;
    try { params = new URLSearchParams(window.location.search); }
    catch (e) { params = { get: function () { return ''; } }; }

    var urlA = (params.get('urlA') || '').trim();
    var urlB = (params.get('urlB') || '').trim();

    if (!urlA || !urlB) {
      setStatus('Missing URLs. Close this tab and try again from the popup.', true);
      return;
    }

    setStatus('Fetching Control Page (A)...');

    chrome.runtime.sendMessage({ action: 'fetch_page_for_match', url: urlA }, function (respA) {
      if (!respA || !respA.ok || !respA.html) {
        setStatus('Failed to fetch URL A. Check the URL and try again.', true);
        return;
      }
      var htmlA = respA.html;
      setStatus('Fetching New Page (B)...');

      chrome.runtime.sendMessage({ action: 'fetch_page_for_match', url: urlB }, function (respB) {
        if (!respB || !respB.ok || !respB.html) {
          setStatus('Failed to fetch URL B. Check the URL and try again.', true);
          return;
        }
        var htmlB = respB.html;
        setStatus('Comparing scripts...');

        var scriptsA = extractScriptsFromHtml(htmlA, urlA);
        var scriptsB = extractScriptsFromHtml(htmlB, urlB);

        var result = compareScripts(scriptsA, scriptsB);
        renderReport(urlA, urlB, result);
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }

})();
